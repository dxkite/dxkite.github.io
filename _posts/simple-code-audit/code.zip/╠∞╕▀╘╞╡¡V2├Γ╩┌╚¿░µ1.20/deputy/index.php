<?php
require_once('common.php');
C('webtitle','副站长管理后台');
C('pageid','deputy');
include_once 'common.head.php';
?>
<div class="animated fadeInRight">
        <div class="row  border-bottom white-bg dashboard-header">
            <div class="col-sm-12">
                <div class="p-xs">
                                <div class="pull-left m-r-md">
                                    <i class="fa fa-globe text-navy mid-icon"></i>
                                </div>
                                <h2>欢迎来到<?=C('webname')?></h2>
                                <span>你可以自由选择你感兴趣的功能。</span>
                            </div>

                <div class="ibox-content">
                    <div id="vertical-timeline" class="vertical-container dark-timeline">
                        <div class="vertical-timeline-block">
                                        <div class="vertical-timeline-icon navy-bg">
                                            <i class="fa fa-briefcase"></i>
                                        </div>

                                        <div class="vertical-timeline-content">
                                            <h2>每日公告</h2>
                                            <p><?=C('web_control_gg')?>
                                            </p>
                                            <a href="#" class="btn btn-sm btn-primary"> 更多信息</a>
                                            <span class="vertical-date">
                                         <br>
                                        <small><?=date('m月d日')?></small>
                                    </span>
                                        </div>
                        </div>
						<?php if($isdomain=='1'){ ?>
						<div class="vertical-timeline-block">
                                        <div class="vertical-timeline-icon blue-bg">
                                            <i class="fa fa-file-text"></i>
                                        </div>

                                        <div class="vertical-timeline-content">
                                            <h2>分站公告</h2>
                                            <p><?=C('web_separate_gg')?></p>
                                            <a href="#" class="btn btn-sm btn-success"> 下载文档 </a>
                                            <span class="vertical-date">
                                         <br>
                                        <small><?=date('m月d日')?></small>
                                    </span>
                                        </div>
                                    </div>
						<?php } ?>
							</div>
                </div>
            </div>

        </div>
		<div class="wrapper wrapper-content">
            <div class="row">

		<div class="col-sm-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <span class="label label-success pull-right">百分之十</span>
                        <h5>用户</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins"><?=get_count('users',"uid")?></h1>
                        <div class="stat-percent font-bold text-success"><?php
$a=get_count('users',"uid")
;$b=10;
$c=$a*$b/100;
echo $c."%";
?> <i class="fa fa-bolt"></i>
                        </div>
                        <small>总用户</small>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <span class="label label-info pull-right">百分之十</span>
                        <h5>QQ</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins"><?=get_count('qqs',"uid")?></h1>
                        <div class="stat-percent font-bold text-info"><?php
$a=get_count('qqs',"uid")
;$b=10;
$c=$a*$b/100;
echo $c."%";
?> <i class="fa fa-level-up"></i>
                        </div>
                        <small>总QQ</small>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <span class="label label-primary pull-right">今天</span>
                        <h5>访客</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins"><?=C('number')?></h1>
                        <div class="stat-percent font-bold text-navy">100% <i class="fa fa-level-up"></i>
                        </div>
                        <small>新访客</small>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <span class="label label-danger pull-right">最近一个月</span>
                        <h5>活跃用户</h5>
                    </div>
                    <div class="ibox-content">
                        <h1 class="no-margins"><?php
$a=get_count('users',"uid")
;$b=90;
$c=$a*$b/100;
echo $c;
?></h1>
                        <div class="stat-percent font-bold text-danger"><?php
$a=get_count('users',"uid")
;$b=90;
$c=$a*$b/100;
echo $c."%";
?> <i class="fa fa-level-down"></i>
                        </div>
                        <small>12月</small>
                    </div>
                </div>
			</div>
		</div>
	</div>
        <div class="wrapper wrapper-content">
            <div class="row">
                <div class="col-lg-4">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title"><a href="shop.php"><span
                                class="label label-warning pull-right">兑换</span></a>
                            <h5>余额排行榜</h5>
                        </div>
                        <div class="ibox-content">
                            <ul class="list-group">
							<?php if($rows=$db->get_results("select * from {$prefix}users where 1 order by rmb desc limit 5")){ foreach($rows as $row){?>
							<?php $i=$i+1?>
                                <li class="list-group-item"><span class="badge badge-primary"><?=$row['rmb']?>元</span>
                                <span class="label label-success"><?=$i?></span>　用户名：<?=$row['user']?></li>
							<?php }}?>
								</ul>
                        </div>
                    </div>
                </div>
				                <div class="col-lg-4">
                    <div class="ibox-title">
                        <h5>最新注册的用户</h5>
                    </div>
                    <div class="ibox-content">
                        <div>
                            <div class="feed-activity-list">
                                
									<?php if($rows=$db->get_results("select * from {$prefix}users where 1 order by uid desc limit 5")){ foreach($rows as $row){?>
								    <div class="feed-element">
                                        <a class="pull-left">
                                            <img alt="image" class="img-circle"
                                                 src="//q1.qlogo.cn/g?b=qq&nk=<?=$row[qq]?>&s=40">
                                        </a>

                                        <div class="media-body">
                                            用户名： <strong><?=$row[user]?></strong>
                                            <br>
                                            <small class="text-muted"><?=$row[regtime]?></small>
                                        </div>
                                </div>
				<?php }}?>
									</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="ibox-title">
                        <h5>最新开启秒赞QQ</h5>
                    </div>
                    <div class="ibox-content">
                        <div>
                            <div class="feed-activity-list">
                                <?php if($rows=$db->get_results("select * from {$prefix}qqs where 1 order by qid desc limit 5")){ foreach($rows as $row){?>
								    <div class="feed-element">
                                        <a class="pull-left">
                                            <img alt="image" class="img-circle"
                                                 src="//q1.qlogo.cn/g?b=qq&nk=<?=$row[qq]?>&s=40">
                                        </a>

                                        <div class="media-body">
                                            QQ： <strong><?=$row[qq]?></strong>
                                            <br>
                                            <small class="text-muted"><?=$row[addtime]?></small>
                                        </div>
                                </div>
				<?php }}?>                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	  <?php
include_once 'common.foot.php';
?>