<?php
require_once('common.php');
//************************执行代码开始*************************

$uid=is_numeric($_GET['uid'])?$_GET['uid']:'0';


if($_GET['do']=='daili'){
	if($uid && $row=$db->get_row("select * from {$prefix}users where uid='$uid'")){
		if($row['active'] > 7){
	exit("<script language='javascript'>alert('禁止对管理员进行修改！');window.location.href='ulist.php';</script>");
}
		if($row['daili']){
			$db->query("update {$prefix}users set daili=0 where uid='{$uid}'");
			echo "<script language='javascript'>alert('取消代理成功！');</script>";
		}else{
			$db->query("update {$prefix}users set daili=1 where uid='{$uid}'");
			echo "<script language='javascript'>alert('设为代理成功！');</script>";
		}
	}
	
}

$users=$db->get_results("select * from {$prefix}users order by uid desc limit 0,10");
//************************执行代码结束**************************
C('pageid','deputyuser');
C('webtitle','用户列表');
include_once 'common.head.php';
?>
<div class="animated fadeInRight">
        <div class="row  border-bottom white-bg dashboard-header">
		<div class="col-sm-12">
			<h3 class="page-header">用户列表</h3>
			<div class="table-responsive">
				<table class="table table-striped">
				<thead>
				<tr>
					<th>#UID</th>
					<th>用户名</th>
					<th>是否代理</th>
					<th>余额</th>
					<th>VIP信息</th>
					<th>配额</th>
					<th>邮箱</th>
					<th>手机</th>
					<th>注册时间</th>
					<th>注册IP</th>
					<th>最后登录</th>
					<th>操作</th>
				</tr>
				</thead>
				<tbody>
				<?php if($users){foreach($users as $user){ if($user['active']<7){?>
				<tr>
					<td><?=$user[uid]?></td>
					<td><?=$user[user]?><?php if($user['active']>7) echo '<font color="red">[管理员]</font>'; elseif($user['fuzhan']) echo '<font color="green">[副站长]</font>'; elseif($user['daili']) echo '<font color="blue">[代理]</font>';?></td>
					<td><a href="?do=daili&p=<?=$p?>&uid=<?=$user[uid]?>" onClick="if(!confirm('确认更改？')){return false;}" class="btn <?php if($user[daili]){echo'btn-danger';}else{echo'btn-success';}?>"><?php if($user[daili]){echo'取消';}else{echo'设为';}?></a></td>
					<td><button class="btn btn-default" style="width:60px;"><?=$user[rmb]?></button><a href="uset.php?xz=re&uid=<?=$user[uid]?>" class="btn btn-success">充值</a></td>
					<td><?php if(get_isvip($user[vip],$user[vipend])){ echo "<font color='green'>{$user[vipend]}</font>";}else{echo"<font color='gray'>不是VIP</font>";}?></td>
					<td><font color="green" size=4><?=get_count('qqs',"uid='$user[uid]'",'qid')?></font>/<?=$user[peie]?></td>
					<td><?=$user[mail]?></td>
					<td><?=$user[phone]?></td>
					<td><?=$user[regtime]?></td>
					<td><?=$user[regip]?>[<?=$user['city']?>]</td>
					<td><?=$user[lasttime]?></td>
					<td><a href="uset.php?xz=update&uid=<?=$user[uid]?>" class="btn btn-success">修改</a></td>
				</tr>
				<?php }}}?>
				</tbody>
				</table>
			</div>
			<? if($pagedo!='seach'){?>
			<div class="row" style="text-align:center;">
				<ul class="pagination pagination-lg">
					<li <?php if($p==1){echo'class="disabled"';}?>><a href="?p=1">首页</a></li>
					<li <?php if($prev==$p){echo'class="disabled"';}?>><a href="?p=<?=$prev?>">&laquo;</a></li>
					<?php for($i=$p;$i<=$pp;$i++){?>
					<li <?php if($i==$p){echo'class="active"';}?>><a href="?p=<?=$i?>"><?=$i?></a></li>
					<?php }?>
					<li <?php if($next==$p){echo'class="disabled"';}?>><a href="?p=<?=$next?>">&raquo;</a></li>
					<li <?php if($p==$pages){echo'class="disabled"';}?>><a href="?p=<?=$pages?>">末页</a></li>
				</ul>
			</div>
			
			<?php }?>
			</div>
</div></div>
	  <?php
include_once 'common.foot.php';
?>
