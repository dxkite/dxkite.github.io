<?php
require_once('includes/common.php');
if($_POST['do']=='login'){
	$user=safestr($_POST['user']);
	$pwd=safestr($_POST['pwd']);
	$ip=getip();
	if(!$user || !$pwd){
		exit("<script language='javascript'>alert('账号密码不能为空！');history.go(-1);</script>");
	}elseif(strlen($user) < 5){
		exit("<script language='javascript'>alert('用户名太短！');history.go(-1);</script>");
	}elseif(strlen($pwd) < 5){
		exit("<script language='javascript'>alert('密码太简单！');history.go(-1);</script>");
	}else{
		$pwd=md5(md5($pwd).md5('1340176819'));
			$where="user='$user' and pwd='$pwd'";
		if($row=$db->get_row("select uid,user from {$prefix}users where {$where} limit 1")){
			$sid=md5(uniqid().rand(1,1000));
			$now=date("Y-m-d H:i:s");
			$ip=getip();
			$db->query("update {$prefix}users set sid='$sid',lasttime='$now',lastip='$ip' where uid='{$row[uid]}'");
			setcookie("tgyd_sid",$sid,time()+3600*24*14,'/');
			exit("<script language='javascript'>alert('{$row[user]}，欢迎你回来!');window.location.href='/mgmt';</script>");
		}else{
			exit("<script language='javascript'>alert('账号或密码错误！');history.go(-1);</script>");
		}
	}
}
?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <title><?=C("webname")?> - 用户登录</title>
    
    <!--[if lt IE 8]>
    <meta http-equiv="refresh" content="0;ie.html" />
    <![endif]-->
    
	<link href="/style/user/css/bootstrap.min.css?v=3.4.0" rel="stylesheet">
    <link href="/style/user/font-awesome/css/font-awesome.css?v=4.3.0" rel="stylesheet">
    <link href="/style/user/css/animate.css" rel="stylesheet">
    <link href="/style/user/css/style.css?v=2.2.0" rel="stylesheet">
	
</head>
<body class="gray-bg">

    <div class="middle-box" align="center">

                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        账号登陆
                                    </div>
                                    <div class="panel-body">
            <h3><?=C("webname")?></h3>
           <form action="?" method="post" class="form-signin">
		   <input type="hidden" name="do" value="login">
			<div class="form-group">
                    <input type="text" class="form-control" name="user" placeholder="请输入用户账号" required="">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="pwd" placeholder="请输入用户密码" required="">
                </div>
                <button type="submit" class="btn btn-primary block full-width">登录到<?=C("webname")?></button>
            </form>
			<hr/>
			<a class="btn btn-success btn-rounded btn-block" href="/reg.php"><i class="fa fa-male"></i> 还没有账号? - 立即注册</a><a class="btn btn-info btn-rounded btn-block" href="/find.php"><i class="fa fa-mail-reply-all"></i> 密码忘记了? - 立即找回</a>
                                    </div>
                                </div>
        </div>
    <script src="/style/user/js/jquery.min.js?v=2.1.1"></script>
    <script src="/style/user/js/bootstrap.min.js?v=3.4.0"></script>
</body>

</html>