<?php
error_reporting(0);
	@header('Content-Type: text/html; charset=UTF-8');
	if(file_exists('install.lock')){
		exit('已经安装完成！如需重新安装，请删除install目录下的install.lock!');
	}
	$step=is_numeric($_GET['step'])?$_GET['step']:'1';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">

    <title>程序安装 - 天高云淡</title>

    <!-- Bootstrap core CSS -->
    <link href="/style/user/css/bootstrap.min.css" rel="stylesheet">
    <link href="/style/user/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="/style/user/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="/style/user/css/style.css" rel="stylesheet">
    <link href="/style/user/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body class="login-body">
<div class="container">
<?php if($step=='1'){?>
<form action="?step=2" class="form-sign" method="post">
<div class="form-signin">
<h2 class="form-signin-heading">installer</h2>
<div class="login-wrap">
		<p>天高云淡V2程序说明</p>
		<p>1.程序二次开发云淡风轻</p>
		<p>2.本程序禁止外泄 泄露可无理由取消授权</p>
		<p>3.龙魂QQ 1340176819</p>
		<button class="btn btn-lg btn-login btn-block" type="submit">我已阅读,并同意以上条款</button>
</div>
</div>
</form>
<?php }elseif($step=='2'){?>
<div class="form-signin">
<h2 class="form-signin-heading">installer</h2>
<div class="login-wrap">
		<form action="?step=3" class="form-sign" method="post">
		<label for="name">数据库地址:</label>
		<input type="text" class="form-control" name="DB_HOST" value="localhost">
		<label for="name">数据库端口:</label>
		<input type="text" class="form-control" name="DB_PORT" value="3306">
		<label for="name">数据库库名:</label>
		<input type="text" class="form-control" name="DB_NAME" placeholder="输入数据库库名">
		<label for="name">数据库用户名:</label>
		<input type="text" class="form-control" name="DB_USER" placeholder="输入数据库用户名">
		<label for="name">数据库密码:</label>
		<input type="password" class="form-control" name="DB_PWD" placeholder="输入数据库密码">
		<br><input type="submit" class="btn btn-primary btn-block" name="submit" value="确认，下一步">
		</form>
</div>
<?php }elseif($step=='3'){
	if($_POST['submit']){
		if(!$_POST['DB_HOST'] || !$_POST['DB_PORT'] || !$_POST['DB_NAME'] || !$_POST['DB_USER'] || !$_POST['DB_PWD']){
			echo'<script language=\'javascript\'>alert(\'所有项都不能为空\');history.go(-1);</script>';
		}else{
			if(!$con=mysql_connect($_POST['DB_HOST'].':'.$_POST['DB_PORT'],$_POST['DB_USER'],$_POST['DB_PWD'])){
				echo'<script language=\'javascript\'>alert("连接数据库失败，'.mysql_error().'");history.go(-1);</script>';
			}elseif(!mysql_select_db($_POST['DB_NAME'],$con)){
				echo'<script language=\'javascript\'>alert("选择的数据库不存在，'.mysql_error().'");history.go(-1);</script>';
			}else{
				mysql_query("set names utf8",$con);
				$data="<?php
return array(
	'DB_HOST'               =>  '{$_POST['DB_HOST']}',
    'DB_NAME'               =>  '{$_POST['DB_NAME']}',
    'DB_USER'               =>  '{$_POST['DB_USER']}',
    'DB_PWD'                =>  '{$_POST['DB_PWD']}',
    'DB_PORT'               =>  '{$_POST['DB_PORT']}',
    'DB_PREFIX'             =>  'tgyd_',
);";
				if(file_put_contents('../includes/db.php',$data)){
					$sqls=file_get_contents("install.sql");
					$explode = explode(";",$sqls);
					$num = count($explode);
					foreach($explode as $sql){
						if($sql=trim($sql)){
							mysql_query($sql);
						}
					}
					if(mysql_error()){
						echo'<script language=\'javascript\'>alert("导入数据表时错误，'.mysql_error().'");history.go(-1);</script>';
					}else{
						@file_put_contents('install.lock','');
				?>
<div class="form-signin">
<h2 class="form-signin-heading">installer</h2>
<div class="login-wrap">
		<p>网站安装成功</p>
		<p>共导入<?php echo $num;?>条数据</p>
		<p>1、管理员账号admin，密码admin，请尽快修改密码。</p>
		<p><a href="/index.php" class="btn btn-lg btn-login btn-block">网站首页</a></p>
</div>
</div>
				<?php
					}
				}else{
					echo'<script language=\'javascript\'>alert("保存数据库配置文件失败，请检查网站是否有写入权限！");history.go(-1);</script>';
				}
			}
		}
	}
}elseif($step=='4'){


?>


<?php }?>
</div>



    <!-- js placed at the end of the document so the pages load faster -->
    <script src="/style/user/js/jquery.js"></script>
    <script src="/style/user/js/bootstrap.min.js"></script>


  </body>
</html>