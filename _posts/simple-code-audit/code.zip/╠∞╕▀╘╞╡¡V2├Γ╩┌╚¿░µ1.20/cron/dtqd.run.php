<?php
/*
大厅签到 日/次
*/
include_once "conn.php";
$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$result = mysql_query("SELECT * FROM {$tableqz}qqs where qid='{$qid}' and isdtqd>0 and sidzt=0 limit 1");
if ($row = mysql_fetch_array($result)) {
    $uin = $row['qq'];
    $sid = $row['sid'];
    $skey = $row['skey'];
    $p_skey = $row['p_skey'];
    $p_skey2 = $row['p_skey2'];
    $do = $row['isshuo'];
    $now = date("Y-m-d-H:i:s");
    $next = date("Y-m-d H:i:s", time() + 60 * 24 * 60 - 10);
    @mysql_query("update {$tableqz}qqs set lastdtqd='$now',nextdtqd='$next' where qid='$qid'");
    include_once "qzone.class.php";
    $qzone = new qzone($uin, $sid, $skey, $p_skey, $p_skey2);
    $qzone->dtqd();
    //结果输出
    foreach ($qzone->msg as $result) {
        echo $result . '<br/>';
    }
	include_once "autoclass.php";
    exit('Ok!');
} else {
    exit('Qid Error!');
}

