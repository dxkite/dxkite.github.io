<?php
if($qzone->sidzt){
		if($row['isauto']){
		include_once "getskey.php";
		}
		@mysql_query("UPDATE {$tableqz}qqs SET sidzt='1',skeyzt='1' WHERE qid='{$qid}'");
	}
if($qzone->skeyzt){
		if($row['isauto']){
		include_once "getskey.php";
		}
		$sql="skeyzt='1'";
		@mysql_query("UPDATE {$tableqz}qqs SET {$sql} WHERE qid='{$qid}'");
}
?>