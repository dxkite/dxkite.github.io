<?php
/*
 *Author：消失的彩虹海 & 快乐是福 & 云上的影子 & 龙魂 && 天涯
*/
class qzone{
	public $msg;
	public function __construct($uin,$sid=null,$skey=null,$p_skey=null,$p_skey2=null){
		$this->uin=$uin;
		$this->sid=$sid;
		$this->skey=$skey;
		$this->p_skey=$p_skey;
		$this->p_skey2=$p_skey2;
		$this->gtk=$this->getGTK($skey);
		$this->gtk1=$this->getGTK($p_skey);
		$this->gtk2=$this->getGTK2($skey);
		$this->cookie='pt2gguin=o0'.$uin.'; uin=o0'.$uin.'; skey='.$skey.'; p_skey='.$p_skey.';';
		$this->cookie1='pt2gguin=o0'.$uin.'; uin=o0'.$uin.'; skey='.$skey.';';
		$this->cookie2='pt2gguin=o0'.$uin.'; uin=o0'.$uin.'; skey='.$skey.'; p_skey='.$p_skey2.'; p_uin=o0'.$uin.';';
	}
	function gift($uin, $con) {
        $url = "http://m.qzone.com/gift/giftweb?g_tk=".$this->gtk;
        $post = "action=3&itemid=108517&struin={$uin}&content=" . urlencode($con) . "&format=json&isprivate=0";
        $json = $this->get_curl($url, $post,1,$this->cookie2);
        $arr = json_decode($json, true);
        if (array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = $this->uin . " 送礼物成功！";
        } elseif ($arr['code'] == - 3000) {
            $this->skeyzt = 1;
            $this->msg[] = $this->uin . " 未登录";
        } elseif ($arr['code'] == - 10000) {
            $this->msg[] = $this->uin . " 收礼人设置了权限";
        } else {
            $this->msg[] = $this->uin . " 送礼物失败！";
        }
    }
    function rq($uin) {
		$url='http://g.cnc.qzone.qq.com/fcg-bin/cgi_emotion_list.fcg?uin='.$uin.'&loginUin=' . $this->uin . '&s=250195&num=3&g_tk='.$this->gtk;
        $json = $this->get_curl($url, 0,'http://user.qzone.qq.com/',$this->cookie);
        $arr = json_decode($json, true);
		$this->msg[] = $this->uin."为".$uin."刷人气成功";
    }
	function liuyan($uin,$con){
		$url = "http://m.qzone.com/msgb/fcg_add_msg?g_tk=".$this->gtk;
		$post = "res_uin={$uin}&format=json&content=".urlencode($con)."&opr_type=add_comment";
		$json=$this->get_curl($url,$post,1,$this->cookie2);
		$arr = json_decode($json, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]=$this->uin.' 为 '.$uin.' 刷留言成功[CP]';
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' 为 '.$uin.' 刷留言失败[CP]！原因:'.$arr['message'];
		}elseif($arr['code']==-4017){
			$this->msg[]=$this->uin.' 为 '.$uin.' 刷留言成功[CP]，留言内容将在你审核后展示';
		}else{
			$this->msg[]=$this->uin.' 为 '.$uin.' 刷留言失败[CP]！原因:'.$arr['message'];
		}
	}
	public function zyzan($uin) //主页赞
	{
		$randuin=rand(111111111,999999999);
		$url='http://w.cnc.qzone.qq.com/cgi-bin/likes/internal_dolike_app?g_tk='.$this->gtk;
		$post='qzreferrer=http%3A%2F%2Fuser.qzone.qq.com%2F'.$randuin.'&appid=7030&face=0&fupdate=1&from=1&query_count=200&format=json&opuin='.$this->uin.'&unikey=http%3A%2F%2Fuser.qzone.qq.com%2F'.$randuin.'&curkey=http%3A%2F%2Fuser.qzone.qq.com%2F'.$uin.'&zb_url=http%3A%2F%2Fi.gtimg.cn%2Fqzone%2Fspace_item%2Fpre%2F10%2F'.rand(10000,99999).'_1.gif';
		$json=$this->get_curl($url,$post,'http://user.qzone.qq.com/'.$uin,$this->cookie);
		$arr = json_decode($json, true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]=$this->uin.' 赞 '.$uin.' 主页成功[PC]';
		}elseif($arr[code]==-3000){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' 赞 '.$uin.' 主页失败[PC]！原因:'.$arr['message'];
		}elseif(array_key_exists('code',$arr)){
			$this->msg[]=$this->uin.' 赞 '.$uin.' 主页失败[PC]！原因:'.$arr['message'];
		}else{
			$this->msg[]=$this->uin.' 赞 '.$uin.' 主页失败[PC]！请10秒后再试';
		}
	}
	public function quantu(){
		if($shuos=$this->getnew()){
			foreach($shuos as $shuo){
				$albumid='';$lloc='';
				if($shuo['original']){
					$albumid=$shuo['original']['cell_pic']['albumid'];
					$lloc=$shuo['original']['cell_pic']['picdata'][0]['lloc'];
				}
				if($shuo['pic']){
					$albumid=$shuo['pic']['albumid'];
					$lloc=$shuo['pic']['picdata'][0]['lloc'];
				}
				if(!empty($albumid)) {
					$touin=$shuo['userinfo']['user']['uin'];
					$hms=$this->quantu_do($touin,$albumid,$lloc);
					if($this->skeyzt) break;
				}
			}
		}
	}
	public function quantu_do($touin,$albumid,$lloc){
		$url="http://app.photo.qq.com/cgi-bin/app/cgi_annotate_face?g_tk=".$this->gtk;
		$post="format=json&uin={$this->uin}&hostUin=$touin&faUin={$this->uin}&faceid=&oper=0&albumid=$albumid&lloc=$lloc&facerect=10_10_50_50&extdata=&inCharset=GBK&outCharset=GBK&source=qzone&plat=qzone&facefrom=moodfloat&faceuin={$this->uin}&writeuin={$this->uin}&facealbumpage=quanren&qzreferrer=http://user.qzone.qq.com/$uin/infocenter?via=toolbar";
		$json=$this->get_curl($url,$post,'http://user.qzone.qq.com/'.$uin.'/infocenter?via=toolbar',$this->cookie);
		$json=mb_convert_encoding($json, "UTF-8", "gb2312");
		$arr=json_decode($json,true);
		if(!array_key_exists('code',$arr)){
			$this->msg[]="圈{$touin}的图{$albumid}失败，原因：获取结果失败！";
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]="圈{$touin}的图{$albumid}失败，原因：SKEY已失效！";
		}elseif($arr['code']==0){
			$this->msg[]="圈{$touin}的图{$albumid}成功";
		}else{
			$this->msg[]="圈{$touin}的图{$albumid}失败，原因：".$arr['message'];
		}
	}
	public function getll(){
		$url='http://m.qzone.com/list?g_tk='.$this->gtk.'&res_attach=&format=json&list_type=msg&action=0&res_uin='.$this->uin.'&count=20';
		$get=$this->get_curl($url,0,1,$this->cookie2);
		$arr = json_decode($get,true);
		if($arr['data']['vFeeds'])
			return $arr['data']['vFeeds'];
		else
			$this->msg[]='没有留言！';
	}
	public function getliuyan(){
		$ua='Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0';
		$url='http://m.qzone.qq.com/cgi-bin/new/get_msgb?uin='.$this->uin.'&hostUin='.$this->uin.'&start=0&s=0.935081'.time().'&format=json&num=20&inCharset=utf-8&outCharset=utf-8&g_tk='.$this->gtk1;
		$json=$this->get_curl($url,0,'http://user.qzone.qq.com/',$this->cookie,0,$ua);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='获取留言列表成功！';
			return $arr['data']['commentList'];
		}else{
			$this->msg[]='获取留言列表失败！';
		}
	}
	public function PCdelll($id,$uin){
		$url = "http://m.qzone.qq.com/cgi-bin/new/del_msgb?g_tk=".$this->gtk1;
		$post="qzreferrer=http%3A%2F%2Fctc.qzs.qq.com%2Fqzone%2Fmsgboard%2Fmsgbcanvas.html%23page%3D1&hostUin=".$this->uin."&idList=".$id."&uinList=".$uin."&format=json&iNotice=1&inCharset=utf-8&outCharset=utf-8&ref=qzone&json=1&g_tk=".$this->gtk;
		$data = $this->get_curl($url,$post,'http://ctc.qzs.qq.com/qzone/msgboard/msgbcanvas.html',$this->cookie);
		$arr=json_decode($data,true);
		if($arr){
			if(array_key_exists('code',$arr) && $arr['code']==0){
				$this->msg[]= '删除 '.$uin.' 留言成功！';
			}elseif($arr['code']==-3000){
				$this->skeyzt=1;
				$this->msg[]='删除 '.$uin.' 留言失败！原因:'.$arr['message'];
			}elseif(array_key_exists('code',$arr)){
				$this->msg[]= '删除 '.$uin.' 留言失败！'.$arr['message'];
			}
		}else{
			$this->msg[]=  "未知错误，删除失败！";
		}
	}
	public function cpdelll($id,$uin){
		$url = 'http://m.qzone.com/operation/operation_add?g_tk='.$this->gtk;
		$post='opr_type=delugc&res_type=334&res_id='.$id.'&real_del=0&res_uin='.$this->uin.'&format=json';
		$data = $this->get_curl($url,$post,1,$this->cookie2);
		$arr=json_decode($data,true);
		if($arr){
			if(array_key_exists('code',$arr) && $arr['code']==0){
				$this->msg[]='删除 '.$uin.' 留言成功！';
			}elseif($arr['code']==-3000){
				$this->skeyzt=1;
				$this->msg[]='删除 '.$uin.' 留言失败！原因:'.$arr['message'];
			}else{
				$this->msg[]='删除 '.$uin.' 留言失败！原因:'.$arr['message'];
			}
		}else{
			$this->msg[]='未知错误，删除失败！可能留言已删尽';
		}
	}
	public function delll($do=0){
		if($do){
			if($liuyans=$this->getliuyan()){
				foreach($liuyans as $row) {
					$cellid=$row['id'];
					$uin=$row['uin'];
					if($cellid){
						$this->PCdelll($cellid,$uin);
					}
				}
			}
		}else{
			if($liuyans=$this->getll()){
				foreach($liuyans as $row) {
					$cellid=$row['id']['cellid'];
					$uin=$row['userinfo']['user']['uin'];
					if($cellid){
						$this->cpdelll($cellid,$uin);
					}
				}
			}
		}
	}
	public function pczhuanfa($con, $touin, $tid) //电脑端说说转发
	{
		$url = 'http://user.qzone.qq.com/q/taotao/cgi-bin/emotion_cgi_forward_v6?g_tk=' . $this->gtk1;
		$ua = 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36';
		$post = "tid={$tid}&t1_source=1&t1_uin={$touin}&signin=0&con={$con}&with_cmt=0&fwdToWeibo=0&forward_source=2&code_version=1&format=json&out_charset=UTF-8&hostuin=" . $this->uin . "&qzreferrer=http://user.qzone.qq.com/" . $this->uin . "/infocenter";
		$json = $this->get_curl($url, $post, "http://user.qzone.qq.com/" . $this->uin . "/infocenter", $this->cookie , $ua);
		if ($json) {
			$arr = json_decode($json, true);

			if ($arr[code] == 0) {
				$this->shuotid = $arr[tid];
				$this->msg[] = $this->uin . '转发' . $touin . '说说成功[PC]';
			}
			else if ($arr[code] == -3000) {
				$this->skeyzt = 1;
				$this->msg[] = $this->uin . '转发' . $touin . '说说失败[PC]！原因:' . $arr[message];
			}
			else {
				$this->msg[] = $this->uin . '转发' . $touin . '说说失败[PC]！原因' . $json;
			}
		}
		else {
			$this->msg[] = $this->uin . '获取转发' . $touin . '说说结果失败[PC]';
		}
	}
	public function cpzhuanfa($con, $touin, $tid) //手机触屏端说说转发
	{
		$url = 'http://m.qzone.com/operation/operation_add?g_tk=' . $this->gtk;
		$ua = 'Mozilla/5.0 (Linux; Android 4.1.2; Coolpad 5890 Build/JRO03L) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/35.0.1916.138 Mobile Safari/537.36 baidubrowser/6.3.13.0 (Baidu; P1 4.1.2)';
		$post = 'res_id=' . $tid . '&res_uin=' . $touin . '&format=json&reason=' . urlencode($con) . '&res_type=311&opr_type=forward&operate=1';
		$json = $this->get_curl($url, $post, 1 , $this->cookie2 , 0,$ua);
		if ($json) {
			$arr = json_decode($json, true);
			if ($arr['code'] == 0) {
				$this->msg[] = $this->uin . '转发' . $touin . '说说成功[CP]';
			}
			else if ($arr[code] == -3000) {
				$this->sidzt = 1;
				$this->msg[] = $this->uin . '转发' . $touin . '说说失败[CP]！原因:' . $arr['message'];
			}
			else {
				$this->msg[] = $this->uin . '转发' . $touin . '说说失败[CP]！原因:' . $arr['message'];
			}
		}
		else {
			$this->msg[] = $this->uin . '获取转发' . $touin . '说说结果失败[CP]';
		}
	}
	public function zhuanfa($do=1,$uins=array(),$con=null){
		if ($shuos = $this->getnew()) {
            //print_r($shuos);
            foreach ($shuos as $shuo) {
                $uin = $shuo['userinfo']['user']['uin'];
                if (stripos('z' . $uins, $uin)) {
                    $cellid = $shuo['id']['cellid'];
                    if ($do) {
                        $this->pczhuanfa($con, $uin, $cellid);
                        if ($this->skeyzt) break;
                    } else {
                        $this->cpzhuanfa($con, $uin, $cellid);
                        if ($this->sidzt) break;
                    }
                }
            }
        }
	}
	public function cpqd($content = "签到", $sealid = "12899") //触屏版空间签到
	{
		$url = 'http://m.qzone.com/mood/publish_signin?g_tk=' . $this->gtk;
		$post = 'opr_type=publish_signin&res_uin=' . $this->uin . '&content=' . $content . '&lat=0&lon=0&lbsid=&seal_id=' . $sealid . '&seal_proxy=&is_winphone=0&source_name=&format=json&sid=' . $this->sid;
		$json = $this->get_curl($url, $post, 0, $this->cookie2);
		$arr = json_decode($json, true);
		if (@array_key_exists('code', $arr) && ($arr['code'] == 0)) {
			$this->msg[] = $this->uin . '签到成功[CP]';
		}
		else if ($arr['code'] == -11210) {
			$this->msg[] = $this->uin . '签到失败[CP]！原因:' . $arr['message'];
		}
		else {
			$this->msg[] = $this->uin . '签到失败[CP]！原因:' . $arr['message'];
		}
	}
	public function pcqd($content = "", $sealid = "12899") //电脑版空间签到
	{
		$url = 'http://snsapp.qzone.qq.com/cgi-bin/signin/checkin_cgi_publish?g_tk=' . $this->gtk;
		$post = 'qzreferrer=http%3A%2F%2Fctc.qzs.qq.com%2Fqzone%2Fapp%2Fcheckin_v4%2Fhtml%2Fcheckin.html&plattype=1&hostuin='.$this->uin.'&seal_proxy=&ttype=1&termtype=1&content='.$content.'&seal_id='.$sealid.'&uin='.$this->uin.'&time_for_qq_tips='.time().'&paramstr=1';
		$get = $this->get_curl($url, $post, 'http://user.qzone.qq.com/'.$this->uin.'/311', $this->cookie);
		preg_match('/callback\((.*?)\)\; <\/script>/is', $get, $json);
		if ($json = $json[1]) {
			$arr = json_decode($json, true);
			$arr[feedinfo] = '';

			if ($arr[code] == 0) {
				$this->msg[] = $this->uin . '签到成功[PC]';
			}
			else if ($arr[code] == -3000) {
				$this->skeyzt = 1;
				$this->msg[] = $this->uin . '签到失败[PC]！原因:' . $arr[message].$this->cookie1;
			}
			else {
				$this->msg[] = $this->uin . '签到失败[PC]！原因' . $json;
			}
		}
		else {
			$this->msg[] = $this->uin . '获取签到结果失败[PC]';
		}
	}
	public function qiandao($do=0,$content='签到'){
		if($do){
			$this->pcqd($content);
		}else{
			$this->cpqd($content);
		}
	}


	public function cpshuo($content, $richval = "", $lon = "", $lat = "") //触屏说说
	{
		$url = 'http://m.qzone.com/mood/publish_mood?g_tk=' . $this->gtk;
		$post = "opr_type=publish_shuoshuo&res_uin=" . $this->uin . "&content={$content}&richval={$richval}&lat={$lat}&lon={$lon}&lbsid=&issyncweibo=0&is_winphone=2&format=json&source_name=&sid=".$this->sid;
		$json = $this->get_curl($url, $post, 1, $this->cookie2);
		$json = json_decode($json, true);
		if (@array_key_exists('code', $json) && ($json[code] == 0)) {
			$this->msg[] = $this->uin . '发布说说成功[CP]';
		}
		else {
			$this->msg[] = $this->uin . '发布说说失败[CP]，原因：' . $json[message];
		}
	}
	public function pcshuo($content, $richval = 0) //电脑端说说
	{
		$url='http://taotao.qzone.qq.com/cgi-bin/emotion_cgi_publish_v6?g_tk='.$this->gtk1;
		$post = 'syn_tweet_verson=1&paramstr=1&pic_template=';

		if($richval){
			$post.="&richtype=1&richval=".$this->uin.",{$richval}&special_url=&subrichtype=1&pic_bo=uAE6AQAAAAABAKU!%09uAE6AQAAAAABAKU!";
		}else{
			$post.="&richtype=&richval=&special_url=";
		}

		$post.="&subrichtype=&con={$content}&feedversion=1&ver=1&ugc_right=1&to_tweet=0&to_sign=0&hostuin=".$this->uin."&code_version=1&format=json&qzreferrer=http%3A%2F%2Fuser.qzone.qq.com%2F".$this->uin."%2F311";
		$ua = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0";
		$json=$this->get_curl($url,$post,'http://user.qzone.qq.com/'.$this->uin.'/311',$this->cookie);

		if ($json) {
			$arr = json_decode($json, true);
			$arr[feedinfo] = '';

			if ($arr[code] == 0) {
				$this->msg[] = $this->uin . '发布说说成功[PC]';
			}
			else if ($arr[code] == -3000) {
				$this->skeyzt = 1;
				$this->msg[] = '发布说说失败[PC]！原因:' . $arr[message];
			}
			else if ($arr[code] == -10045) {
				$this->msg[] = $this->uin . '发布说说失败[PC]！原因:' . $arr[message];
			}
			else {
				$this->msg[] = $this->uin . '发布说说失败[PC]！原因' . $json;
			}
		}
		else {
			$this->msg[] = $this->uin . '获取发布说说结果失败[PC]';
		}
	}
		public function shuo($do=0,$content,$image=null){
		$richval = null;
		if(!empty($image)){
			if($pic=$this->get_curl($image)){
				$richval = $this->uploadimg($pic);
			}
		}else{
			$richval=$image;
		}
		if($do){
			$this->pcshuo($content,$richval);
		}else{
			$this->cpshuo($content,$richval);
		}
	}

	public function pcdel($cellid,$appid) //电脑端说说删除
	{
		$url = 'http://user.qzone.qq.com/q/taotao/cgi-bin/emotion_cgi_delete_v6?g_tk=' . $this->gtk1;
		$post = 'hostuin=' . $this->uin . '&tid=' . $cellid . '&t1_source=1&code_version=1&format=json&qzreferrer=http://user.qzone.qq.com/' . $this->uin . '/'.$appid;
		$json = $this->get_curl($url, $post, 0, $this->cookie);

		if ($json) {
			$arr = json_decode($json, true);
			if (@array_key_exists('code', $arr) && ($arr['code'] == 0)) {
				$this->msg[] = '删除说说' . $cellid . '成功[PC]';
			}
			else if ($arr[code] == -3000) {
				$this->skeyzt = 1;
				$this->msg[] = '删除说说' . $this->touin . '失败[PC]！原因' . $arr[message];
			}
			else {
				$this->msg[] = '删除说说' . $this->touin . '失败[PC]！原因' . $json;
			}
		}
		else {
			$this->msg[] = $this->uin . '获取删除结果失败[PC]';
		}
	}
	public function cpdel($cellid, $appid) {
        $url = "http://m.qzone.com/operation/operation_add?g_tk=" . $this->gtk;
        $post = "opr_type=delugc&res_type={$appid}&res_id={$cellid}&real_del=0&res_uin=" . $this->uin . "&format=json";
        $ua = "Mozilla/5.0 (Linux; U; Android 4.0.3; zh-CN; Lenovo A390t Build/IML74K) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 UCBrowser/9.8.9.457 U3/0.8.0 Mobile Safari/533.1";
        $json = $this->get_curl($url, $post, 1, $this->cookie2, 0, $ua);
        $arr = json_decode($json, true);
        if (@array_key_exists('code', $arr) && $arr['code'] == 0) {
            $this->msg[] = '删除说说' . $cellid . '成功[CP]';
        } else {
            $this->msg[] = '删除说说' . $cellid . '失败[CP]！原因:' . $arr['message'];
        }
    }
	public function shuodel($do=0){
		if ($shuos = $this->getnew('my')) {
			//print_r($shuos);exit;
			foreach($shuos as $shuo){
				$appid = $shuo['comm']['appid'];
                $cellid = $shuo['id']['cellid'];
				if($do){
					$this->pcdel($cellid,$appid);
					if($this->skeyzt) break;
				}else{
					$this->cpdel($cellid,$appid);
				}
			}
		}
	}
	public function cpreply($content, $uin, $cellid, $type, $param)
	{
		$post='res_id='.$cellid.'&res_uin='.$uin.'&format=json&res_type='.$type.'&content='.urlencode($content).'&busi_param='.$param.'&opr_type=addcomment';
		$url = 'http://m.qzone.com/operation/publish_addcomment?g_tk=' . $this->gtk;
		$ua = 'Mozilla/5.0 (Linux; Android 4.1.2; Coolpad 5890 Build/JRO03L) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/35.0.1916.138 Mobile Safari/537.36 baidubrowser/6.3.13.0 (Baidu; P1 4.1.2)';
		$json = $this->get_curl($url, $post, 1, $this->cookie2, 0, $ua);
		if ($json) {
			$arr = json_decode($json, true);
			if (@array_key_exists('code', $arr) && ($arr['code'] == 0)) {
				$this->msg[] = '评论' . $uin . '的说说成功[CP]！';
			}
			else {
				$this->msg[] = '评论' . $uin . '的说说失败[CP]！原因:' . $arr['message'];
			}
		}
		else {
			$this->msg[] = '获取评论' . $uin . '的说说结果失败[CP]！';
		}
	}
	public function pcreply($content,$uin,$cellid,$from,$richval=0){
		$post='topicId='.$uin.'_'.$cellid.'__'.$from.'&feedsType=100&inCharset=utf-8&outCharset=utf-8&plat=qzone&source=ic&hostUin='.$uin.'&isSignIn=&platformid=52&uin='.$this->uin.'&format=json&ref=feeds&content='.urlencode($content).'&richval=&richtype=&private=0&paramstr=1&qzreferrer=http://user.qzone.qq.com/'.$this->uin;
		$url='http://user.qzone.qq.com/q/taotao/cgi-bin/emotion_cgi_re_feeds?g_tk='.$this->gtk1;
		$json=$this->get_curl($url,$post,'http://user.qzone.qq.com/'.$this->uin,$this->cookie);
		if($json){
			$arr=json_decode($json,true);
			$arr['data']['feeds']='';
			if(@array_key_exists('code',$arr) && $arr['code']==0){
				$this->msg[]='评论 '.$uin.' 的说说成功[PC]';
			}elseif($arr['code']==-3000){
				$this->sidzt=1;
				$this->msg[]='评论 '.$uin.' 的说说失败[PC]！原因:SID已失效，请更新SID';
			}elseif($arr['code']==-3001){
				$this->msg[]='评论 '.$uin.' 的说说失败[PC]！原因:需要验证码';
			}elseif(@array_key_exists('message',$arr)){
				$this->msg[]='评论 '.$uin.' 的说说失败[PC]！原因:'.$arr['message'];
			}else{
				$this->msg[]='评论 '.$uin.' 的说说失败[PC]！原因'.$json;
			}
		}else{
			$this->msg[]='获取评论结果失败[PC]';
		}
	}
	public function reply($do=0,$content='',$richval=null){
		global $getss;
		if(preg_match("/\[随机\]/",$content) || $content==''){
			$str = @file_get_contents('sji.db');
			$a = explode('|',$str);
			$isrand=1;
		}else $isrand=0;
		if($shuos=$this->getnew($getss)){
			foreach($shuos as $shuo){
					$appid=$shuo['comm']['appid'];
					$typeid=$shuo['comm']['feedstype'];
					$curkey=urlencode($shuo['comm']['curlikekey']);
					$uinkey=urlencode($shuo['comm']['orglikekey']);
					$uin=$shuo['userinfo']['user']['uin'];
					$from=$shuo['userinfo']['user']['from'];
					$cellid=$shuo['id']['cellid'];
					if($isrand==1)$content=$a[array_rand($a,1)];
					if($do){
						$this->pcreply($content,$uin,$cellid,$from,$richval);

						if($this->skeyzt) break;
					}else{
						$param=$this->array_str($shuo['operation']['busi_param']);
						$this->cpreply($content,$uin,$cellid,$appid,$param);
					}
			}
		}
	}
	public function cplike($uin, $type, $uinkey, $curkey) //触屏点赞
	{
		$post = 'opr_type=like&action=0&res_uin=' . $uin . '&res_type=311&uin_key=' . $uinkey . '&cur_key=' . $curkey . '&format=json';
		$url = 'http://wap.m.qzone.com/praise/like?g_tk=' . $this->gtk;
		$ua = 'Mozilla/5.0 (Linux; Android 4.1.2; Coolpad 5890 Build/JRO03L) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/35.0.1916.138 Mobile Safari/537.36 baidubrowser/6.3.13.0 (Baidu; P1 4.1.2)';
		$json = $this->get_curl($url, $post, 1, $this->cookie2, 0, $ua);

		if ($json) {
			$arr = json_decode($json, true);
			if (@array_key_exists('code', $arr) && ($arr['code'] == 0)) {
				$this->msg[] = '赞' . $uin . '的说说成功[CP]';
			}
			else if ($arr[code] == -3000) {
				$this->sidzt = 1;
				$this->msg[] = '赞' . $uin . '的说说失败[CP]！原因:' . $arr['message'];
			}
			else if ($arr['code'] == -11210) {
				$this->msg[] = '赞' . $uin . '的说说失败[CP]！原因:' . $arr['message'];
			}
			else {
				$this->msg[] = '赞' . $uin . '的说说失败[CP]！原因:' . $arr['message'];
			}
		}
		else {
			$this->msg[] = '获取赞' . $uin . '的说说结果失败[CP]！';
		}
	}
	public function pclike($uin,$curkey,$uinkey,$from,$appid,$typeid,$abstime,$fid){
		$post='qzreferrer=http%3A%2F%2Fuser.qzone.qq.com%2F'.$this->uin.'&opuin='.$this->uin.'&unikey='.$uinkey.'&curkey='.$curkey.'&from='.$from.'&appid='.$appid.'&typeid='.$typeid.'&abstime='.$abstime.'&fid='.$fid.'&active=0&fupdate=1';
		$url='http://w.cnc.qzone.qq.com/cgi-bin/likes/internal_dolike_app?g_tk='.$this->gtk;
		$ua='Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.69 Safari/537.36 QQBrowser/9.1.4060.400';
		$get=$this->get_curl($url,$post,'http://user.qzone.qq.com/'.$this->uin,$this->cookie,0,$ua);
		preg_match('/callback\((.*?)\)\;/is',$get,$json);
		if($json=$json[1]){
			$arr=json_decode($json,true);
			if($arr['message']=='succ' || $arr['msg']=='succ'){
				$this->msg[]='赞 '.$uin.' 的说说成功[PC]';
			}elseif($arr['code']==-3000){
				$this->skeyzt=1;
				$this->msg[]='赞 '.$uin.' 的说说失败[PC]！原因:SID已失效，请更新SID';
			}elseif(@array_key_exists('message',$arr)){
				$this->msg[]='赞 '.$uin.' 的说说失败[PC]！原因:'.$arr['message'];
			}else{
				$this->msg[]='赞 '.$uin.' 的说说失败[PC]！原因:'.$json;
			}
		}else{
			$this->msg[]='获取赞'.$uin.'的说说结果失败[PC]';
		}
	}
	public function pclike2($uin,$curkey,$uinkey,$from,$appid,$typeid,$abstime,$fid){
        $post = 'qzreferrer=http://user.qzone.qq.com/' . $this->uin . '&opuin=' . $this->uin . '&unikey=' . $uinkey . '&curkey=' . $curkey . '&from=' . $from . '&appid=' . $appid . '&typeid=' . $typeid . '&abstime=' . $abstime . '&fid=' . $fid . '&active=0&fupdate=1';
        $url = 'http://w.qzone.qq.com/cgi-bin/likes/internal_dolike_app?g_tk=' . $this->gtk1;
        $get = $this->get_curl($url, $post, 'http://user.qzone.qq.com/' . $this->uin, $this->cookie);
        preg_match('/callback\((.*?)\)\;/is', $get, $json);
        if ($json = $json[1]) {
            $arr = json_decode($json, true);
			//$this->msg[] =$arr;
            if ($arr['message'] == 'succ' || $arr['msg'] == 'succ') {
                $this->msg[] = '赞 ' . $uin . ' 的说说成功[PC]';
            } elseif ($arr['code'] == - 3000) {
                $this->skeyzt = 1;
                $this->msg[] = '赞 ' . $uin . ' 的说说失败[PC]！原因:SKEY已失效，请更新SKEY';
            } elseif (@array_key_exists('message', $arr)) {
                $this->msg[] = '赞 ' . $uin . ' 的说说失败[PC]！原因:' . $arr['message'];
            } else {
                $this->msg[] = '赞 ' . $uin . ' 的说说失败[PC]！原因:' . $json;
            }
        } else {
            $this->msg[] = $uin . ' 获取赞结果失败[PC]';
        }
    }
	public function newpclike($type = 0, $qq_list)
	{
		$randserver=array('s1','s2','s5','s6','s7','s8','s11','s12');
		$url = 'http://ic2.'.$randserver[rand(0,7)].'.qzone.qq.com/cgi-bin/feeds/feeds3_html_more?format=json&begintime=' . time() . '&count=20&uin=' . $this->uin . '&g_tk=' . $this->gtk;
		$json = $this->get_curl($url, 0, 'http://user.qzone.qq.com/'.$this->uin, $this->cookie);
		$arr = json_decode($json, true);
		if ($arr[code] == -3000) {
			$this->skeyzt = 1;
			$this->msg[] = $this->uin . '获取说说列表失败，原因:SKEY过期！[NEWPC]';
		}
		else {
			$this->msg[] = $this->uin . '获取说说列表成功[NEWPC]';
			$json = str_replace(array('\x22', '\x3C', '\/'), array('"', '<', '/'), $json);

			if (preg_match_all('/data\-unikey=\"([0-9A-Za-z\.\-\_\/\:]+)\" data\-curkey=\"([0-9A-Za-z\.\-\_\/\:]+\/([0-9A-Za-z]+))\" data\-clicklog=\"like\" href=\"javascript\:\;\"><i class=\"ui\-icon icon\-praise\"><\/i>赞/iUs', $json, $arr)) {
				//print($json);
				foreach ($arr[1] as $k => $row) {
                    preg_match('/\/(\d+)\//', $row, $narr);
                    $touin = $narr[1];
                    if ($type == 1) { // 白名单
                        if (in_array($narr[1], array($qq_list))) {
							$key = $arr[2][$k];
							$fid = $arr[3][$k];
							if ($row != $key) $type = 5;
							$this->pclike($touin,$key, $row, 1, '311', $type, time(), $fid);
                    if ($this->skeyzt) break;
                        }else{
						$this->msg[]="{$narr[1]}的说说不在白名单内已跳过";
						}
                    } elseif ($type == 2) { // 黑名单
                        if (!in_array($narr[1], array($qq_list))) {
                    $key = $arr[2][$k];
                    $fid = $arr[3][$k];
                    if ($row != $key) $type = 5;
					$this->pclike($touin,$key, $row, 1, '311', $type, time(), $fid);
                    if ($this->skeyzt) break;
                        }else{
						$this->msg[]="{$narr[1]}的说说在黑名单内已跳过";
						}
					}else{
			$this->msg[]="没有要赞的说说";
			}
		}
	}
		}
	}
	public function like($do=1,$type = 0, $qq_list){
		global $getss;
		if ($do=='1' && $type!='0') {
			$this->newpclike($type,$qq_list);
		}else{
		if($shuos=$this->getnew($getss)){
			foreach($shuos as $shuo){
				$like=$shuo['like']['isliked'];
					$appid=$shuo['comm']['appid'];
					$typeid=$shuo['comm']['feedstype'];
					$curkey=urlencode($shuo['comm']['curlikekey']);
					$uinkey=urlencode($shuo['comm']['orglikekey']);
					$uin=$shuo['userinfo']['user']['uin'];
					$from=$shuo['userinfo']['user']['from'];
					$abstime=$shuo['comm']['time'];
					$cellid=$shuo['id']['cellid'];
					if($do=='1'){
						$this->pclike($uin,$curkey,$uinkey,$from,$appid,$typeid,$abstime,$cellid);
						if($this->skeyzt) break;
					}elseif($do=='2'){
						$this->pclike2($uin,$curkey,$uinkey,$from,$appid,$typeid,$abstime,$cellid);
					}else{
						$this->cplike($uin,$appid,$uinkey,$curkey);
						if($this->sidzt) break;
					}
			}
		}
	}
	}



	public function getnew($do=''){
		$ua='Mozilla/5.0 (Linux; U; Android 4.0.3; zh-CN; Lenovo A390t Build/IML74K) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 UCBrowser/9.8.9.457 U3/0.8.0 Mobile Safari/533.1';
		if($do=='my'){
			$url="http://m.qzone.com/list?g_tk=".$this->gtk."&res_attach=att%3D10&format=json&list_type=shuoshuo&action=0&res_uin=".$this->uin."&count=20&sid=".$this->sid;
		}else{
			$url="http://m.qzone.com/get_feeds?g_tk=".$this->gtk."&res_type=0&res_attach=&refresh_type=2&format=json&sid=".$this->sid;
		}
		$json = $this->get_curl($url, 0, 1, $this->cookie2, 0, $ua);
		$arr=json_decode($json,true);
		if ($do=='my' and !array_key_exists('vFeeds', $arr['data']) and $arr['code'] == 0) {
            $this->msg[]='暂时没有要赞的说说哦！';
			return false;
        }
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='获取说说列表成功！[PC]';
			if(isset($arr['data']['vFeeds']))
				return $arr['data']['vFeeds'];
			else
				return $arr['data']['feeds']['vFeeds'];
		}elseif(strpos($arr['message'],'务器繁忙')){
			$this->msg[]='获取最新说说失败！原因:'.$arr['message'];
			return false;
		}elseif(strpos($arr['message'],'登录')){
			$this->sidzt=1;
			$this->msg[]='获取最新说说失败！原因:'.$arr['message'];
			return false;
		}else{
			$this->msg[]='获取最新说说失败！原因:'.$arr['message'];
			return false;
		}	
	}

	public function flower(){ //花藤浇花 消失彩虹海
		$url = 'http://flower.qzone.qq.com/fcg-bin/cgi_plant?g_tk='.$this->gtk;
		$post = 'fl=1&fupdate=1&act=rain&uin=' . $this->uin . '&newflower=1&outCharset=utf%2D8&g%5Ftk=' . $this->gtk . '&format=json';
		$json = $this->get_curl($url,$post,$url,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='浇水成功！';
		}elseif($arr['code']==-6002){
			$this->msg[]='今天浇过水啦！';
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='浇水失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='浇水失败！'.$arr['message'];
		}

		$post = 'fl=1&fupdate=1&act=love&uin=' . $this->uin . '&newflower=1&outCharset=utf%2D8&g%5Ftk=' . $this->gtk . '&format=json';
		$json=$this->get_curl($url,$post,$url,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='修剪成功！';
		}elseif($arr['code']==-6002){
			$this->msg[]='今天修剪过啦！';
		}elseif($arr['code']==-6007){
			$this->msg[]='您的爱心值今天已达到上限！';
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='修剪失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='修剪失败！'.$arr['message'];
		}

		$post = 'fl=1&fupdate=1&act=sun&uin=' . $this->uin . '&newflower=1&outCharset=utf%2D8&g%5Ftk=' . $this->gtk . '&format=json';
		$json=$this->get_curl($url,$post,$url,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='光照成功！';
		}elseif($arr['code']==-6002){
			$this->msg[]='今天日照过啦！';
		}elseif($arr['code']==-6007){
			$this->msg[]='您的阳光值今天已达到上限！';
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='光照失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='光照失败！'.$arr['message'];
		}

		$post = 'fl=1&fupdate=1&act=nutri&uin='.$this->uin.'&newflower=1&outCharset=utf%2D8&g%5Ftk='.$this->gtk.'&format=json';
		$json=$this->get_curl($url,$post,$url,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='施肥成功！';
		}elseif($arr['code']==-6005){
			$this->msg[]='暂不能施肥！';
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='施肥失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='施肥失败！'.$arr['message'];
		}

		$url = 'http://flower.qzone.qq.com/cgi-bin/cgi_pickup_oldfruit?g_tk='.$this->gtk;
		$post = 'mode=1&g%5Ftk='.$this->gtk.'&outCharset=utf%2D8&fupdate=1&format=json';
		$json=$this->get_curl($url,$post,$url,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='兑换神奇肥料成功！';
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='兑换神奇肥料失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='兑换神奇肥料失败！'.$arr['message'];
		}

		$url = 'http://flower.qzone.qq.com/cgi-bin/fg_get_giftpkg?g_tk='.$this->gtk;
		$post = 'outCharset=utf-8&format=json';
		$json=$this->get_curl($url,$post,'http://ctc.qzs.qq.com/qzone/client/photo/swf/RareFlower/FlowerVineLite.swf',$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			if($arr['data']['vDailyGiftpkg'][0]['caption']){
				$this->msg[]=$arr['data']['vDailyGiftpkg'][0]['caption'].':'.$arr['data']['vDailyGiftpkg'][0]['content'];
				$giftpkgid=$arr['data']['vDailyGiftpkg'][0]['id'];
				$granttime=$arr['data']['vDailyGiftpkg'][0]['granttime'];
				$url = 'http://flower.qzone.qq.com/cgi-bin/fg_use_giftpkg?g_tk='.$this->gtk;
				$post = 'giftpkgid='.$giftpkgid.'&outCharset=utf%2D8&granttime='.$granttime.'&format=json';
				$this->get_curl($url,$post,'http://ctc.qzs.qq.com/qzone/client/photo/swf/RareFlower/FlowerVineLite.swf',$this->cookie);
			}else
				$this->msg[]='领取每日登录礼包成功！';
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='领取每日登录礼包失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='领取每日登录礼包失败！'.$arr['message'];
		}
	}
	public function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			if($referer==1){
				curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
			}else{
				curl_setopt($ch, CURLOPT_REFERER, $referer);
			}
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);
		}
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		//$ret=mb_convert_encoding($ret, "UTF-8", "UTF-8");
		return $ret;
	}
	private function getGTK($skey){
        $len = strlen($skey);
        $hash = 5381;
        for($i = 0; $i < $len; $i++){
            $hash += ($hash << 5) + ord($skey[$i]);
        }
        return $hash & 0x7fffffff;//计算g_tk
    }
	private function getGTK2($skey){
		$salt = 5381;
		$md5key = 'tencentQQVIP123443safde&!%^%1282';
		$hash = array();
		$hash[] = ($salt << 5);
		$len = strlen($skey);
		for($i = 0; $i < $len; $i ++)
		{
			$ASCIICode = mb_convert_encoding($skey[$i], 'UTF-32BE', 'UTF-8');
			$ASCIICode = hexdec(bin2hex($ASCIICode));
			$hash[] = (($salt << 5) + $ASCIICode);
			$salt = $ASCIICode;
		}
		$md5str = md5(implode($hash) . $md5key);
		return $md5str;
	}
	public function is_comment($uin,$arrs){
        if($arrs){
	    	foreach($arrs as $arr){
    	   		if($arr['user']['uin'] == $uin){
        			return false;
            		break;
        		}
    		}
        	return true; 
        }else{
        	return true; 
        }
	}
	public function array_str($array){
    	$str='';
        if($array[-100]){
	        $array100=explode(' ',trim($array[-100]));
    	    $new100=implode('+',$array100);
            $array[-100]=$new100;
        }
 		foreach($array as $k=>$v){
            if($k!='-100'){
	    		$str=$str.$k.'='.$v.'&';
            }
 		}
        $str=urlencode($str.'-100=').$array[-100].'+';
        $str=str_replace(':','%3A',$str);
    	return $str;
    }
	public function uploadimg($image, $image_size = array())
	{
		$url = 'http://up.qzone.com/cgi-bin/upload/cgi_upload_pic_v2';
		$post = 'picture=' . urlencode(base64_encode($image)) . '&base64=1&hd_height=' . $image_size[1] . '&hd_width=' . $image_size[0] . '&hd_quality=90&output_type=json&preupload=1&charset=utf-8&output_charset=utf-8&logintype=skey&Exif_CameraMaker=&Exif_CameraModel=&Exif_Time=&uin=' . $this->uin . '&skey=' . $this->skey;
		$data=preg_replace("/\s/","",$this->get_curl($url,$post,1,$this->cookie2,0,1));
		preg_match('/_Callback\((.*)\);/', $data, $arr);
		$data = json_decode($arr[1], true);
		if ($data && array_key_exists("filemd5", $data)) {
			$this->msg[] = '图片上传成功！';
			$post = 'output_type=json&preupload=2&md5=' . $data['filemd5'] . '&filelen=' . $data['filelen'] . '&batchid=' . time() . rand(100000, 999999) . '&currnum=0&uploadNum=1&uploadtime=' . time() . '&uploadtype=1&upload_hd=0&albumtype=7&big_style=1&op_src=15003&charset=utf-8&output_charset=utf-8&uin=' . $this->uin . '&skey=' . $this->skey . '&logintype=skey&refer=shuoshuo';
			$img=preg_replace("/\s/","",$this->get_curl($url,$post,1,$this->cookie2,0,1));
			preg_match('/_Callback\(\[(.*)\]\);/', $img, $arr);
			$data = json_decode($arr[1], true);
			if ($data && array_key_exists("picinfo", $data)) {
				if ($data[picinfo][albumid] != '') {
					$this->msg[] = '图片信息获取成功！';
					return '' . $data["picinfo"]["albumid"] . ',' . $data["picinfo"]["lloc"] . ',' . $data["picinfo"]["sloc"] . ',' . $data["picinfo"]["type"] . ',' . $data["picinfo"]["height"] . ',' . $data["picinfo"]["width"] . ',,,';
				}
				else {
					$this->msg[] = '图片信息获取失败！';
					return NULL;
				}
			}
			else {
				$this->msg[] = '图片信息获取失败！';
				return NULL;
			}
		}
		else {
			$this->msg[] = '图片上传失败！原因：' . $data['msg'];
			return NULL;
		}
	}
	public function pcblqd() {
        $url = "http://buluo.qq.com/cgi-bin/bar/card/bar_list_by_page?neednum=40&startnum=0";
        $json = $this->get_curl($url, 0, "http://buluo.qq.com/p/index.html", $this->cookie1);
		$json=$this->getSubstr($json.'123456','{"retcode":0,"result":','}123456');
		if($json=='{"followbarnum":0,"followbars":[],"isend":1}'){
		$this->msg[] = $this->uin .'部落签到失败!，用户没有关注过部落<BR>';
		}else{
		$arr = json_decode($json);
		foreach($arr->followbars as $followbars){
		$this->blqd($followbars->bid);
		}
		}
    }
	public function blqd($buluo) {
        $url = "http://buluo.qq.com/cgi-bin/bar/user/sign";
		$ua='Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36';
		$rf="http://buluo.qq.com/p/barindex.html?bid=".$buluo;
        $post = "&bid=" . $buluo . "&r=".time()."&bkn=" . $this->gtk."";
        $json = $this->get_curl($url, $post, $rf, $this->cookie1,0,$ua);
		$arr = json_decode($json, true);
		$this->msg[] = $this->uin .'部落签到成功!';
    }
    public function qunwenwenqd() {
		$url = 'http://qun.qzone.qq.com/cgi-bin/get_group_list?groupcount=4&count=4&format=json&callbackFun=_GetGroupPortal&uin='.$this->uin.'&g_tk='.$this->gtk.'&ua=Mozilla%2F5.0%20(Windows%20NT%206.1%3B%20WOW64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F31.0.1650.63%20Safari%2F537.36';
		$data = $this->get_curl($url,0,'http://qun.qzone.qq.com/group',$this->cookie);
		preg_match('/_GetGroupPortal_Callback\((.*?)\)\;/is',$data,$json);
		$arr = json_decode($json[1],true);
		if(@array_key_exists('code',$arr) && $arr['code']==0) {
			foreach($arr['data']['group'] as $row){
				$url='http://wenwen.qq.com/wapi/qun/red-dot?groupUin='.$row['groupid'].'&orig=254&_='.time().'1573';
				$data = $this->get_curl($url,0,'http://wenwen.qq.com/mobile/found/?groupUin='.$row['groupid'],$this->cookie,1,0,1);
				$addcookie='';
				preg_match_all('/Set-Cookie:(.*);/iU',$data,$matchs);
				foreach ($matchs[1] as $val) {
					$addcookie.=$val.'; ';
				}
				$url = 'http://wenwen.qq.com/submit/qun/signin?_='.time().'7583&groupUin='.$row['groupid'];
				$post = 'groupUin='.$row['groupid'].'&questionNum=0&answerNum=0&orig=254';
				$data = $this->get_curl($url,$post,'http://wenwen.qq.com/mobile/found/?groupUin='.$row['groupid'],$this->cookie.$addcookie);
				$arr=json_decode($data,true);
				if($arr['resultCode']==1) {
					$this->msg[] = $this->uin .'在群号为'. $row['groupid'].'群问问签到成功![PC]';
				} elseif(array_key_exists('resultCode',$arr) && $arr['resultCode']==0) {
					$this->msg[] = $this->uin .'今天已经在群号为'.$row['groupid'].'群问问签到过了![PC]';
				} elseif($arr['resultCode']==-1) {
					$this->skeyzt=1;
					$this->msg[] = $row['groupid'].' 群问问签到失败！原因：SKEY失效！';
					break;
				} elseif($arr['resultCode']==-2) {
					$this->msg[] = $this->uin .'今天在群号为'. $row['groupid'].'的群问问签到时间未到![PC]';
				} else {
					$this->msg[] = $row['groupid'].' 群问问签到失败！原因：'.$arr['msg'];
				}
			}
		} elseif($arr['code']==-3000) {
			$this->skeyzt=1;
			$this->msg[]='群问问签到失败！原因：SKEY已失效。';
		} else {
			$this->msg[]='群问问签到失败！原因：'.$arr['message'];
		}
	}
    public function pcqunqd($qun) {
        $url = "http://qiandao.qun.qq.com/cgi-bin/sign";
		$ua='Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0';
		$rf="http://qiandao.qun.qq.com/cgi-bin/sign";
        $post = "&gc=" . $qun . "&is_sign=0&from=1&bkn=" . $this->gtk."";
        $json = $this->get_curl($url, $post, $rf, $this->cookie,0,$ua);
		$arr = json_decode($json, true);
		if($arr[ec]==0)
		$this->msg[] = $this->uin .'在群号为'. $qun.'签到成功!您已累计签到'.$arr[conti_count].'天,签到排名为'.$arr[rank].'名,今天已有'.$arr[today_count].'人签到!'.'<BR>';
		else
		$this->msg[] = $this->uin .'在群号为'. $qun.'签到失败，原因：'.$arr[em].'<BR>';
    }
    public function qunqd(){
		$url = 'http://qun.qzone.qq.com/cgi-bin/get_group_list?groupcount=4&count=4&format=json&callbackFun=_GetGroupPortal&uin='.$this->uin.'&g_tk='.$this->gtk.'&ua=Mozilla%2F5.0%20(Windows%20NT%206.1%3B%20WOW64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F31.0.1650.63%20Safari%2F537.36';
		$url2 = 'http://qiandao.qun.qq.com/cgi-bin/sign';
		$data = $this->get_curl($url,0,'http://qun.qzone.qq.com/group',$this->cookie);
		preg_match('/_GetGroupPortal_Callback\((.*?)\)\;/is',$data,$json);
		$arr = json_decode($json[1],true);
		//print_r($arr);exit;
		if(@array_key_exists('code',$arr) && $arr['code']==0) {
			foreach($arr['data']['group'] as $row){
				$post = 'gc='.$row['groupid'].'&is_sign=0&from=1&bkn='.$this->gtk;
				$data = $this->get_curl($url2,$post,'http://qiandao.qun.qq.com/index.html?groupUin='.$row['groupid'].'&appID=100729587',$this->cookie);
				$arr=json_decode($data,true);
				if(array_key_exists('ec',$arr) && $arr['ec']==0) {
					if(array_key_exists('name_list',$arr))
						$this->msg[] = '群：'.$row['groupid'].' 签到成功！累计签到'.$arr['conti_count'].'天,签到排名为'.$arr['rank'].'名.';
					elseif(array_key_exists('conti_count',$arr))
						$this->msg[] = '群：'.$row['groupid'].' 今天已签到！累计签到'.$arr['conti_count'].'天,签到排名为'.$arr['rank'].'名.';
					else
						$this->msg[] = '群：'.$row['groupid'].'签到失败！原因：'.$data;
				} elseif($arr['ec']==1) {
					$this->skeyzt=1;
					$this->msg[] = '群：'.$row['groupid'].'签到失败！原因：SKEY失效！';
				} else {
					$this->msg[] = '群：'.$row['groupid'].'签到失败！原因：'.$data;
				}
			}
		} elseif($arr['code']==-3000) {
			$this->skeyzt=1;
			$this->msg[]='群签到失败！原因：SKEY已失效。';
		} else {
			$this->msg[]='群签到失败！原因：'.$arr['message'];
		}
	}
	public function fzqd(){
		$url='http://x.pet.qq.com/vip_platform?cmd=set_sign_info&format=json&_='.time().'9008';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('result',$arr) && $arr['result']==0){
			$this->msg[]=$this->uin.' 粉钻签到成功！';
		}elseif($arr['result']==-101){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' 粉钻签到失败！SKEY已失效';
		}else{
			$this->msg[]=$this->uin.' 粉钻签到失败！'.$arr['msg'];
		}
	}
	public function hlwqd(){
		$url='http://pay.video.qq.com/fcgi-bin/sign?low_login=1&uin='.$this->uin.'&otype=json&_t=2&g_tk='.$this->gtk2.'&_='.time().'8906';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		preg_match('/QZOutputJson=(.*?)\;/is',$data,$json);
		$arr = json_decode($json[1], true);
		$arr = $arr['result'];
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]=$this->uin.' 好莱坞会员签到成功！';
		}elseif($arr['code']==-11){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' 好莱坞会员签到失败！SKEY已失效';
		}elseif($arr['code']==500){
			$this->msg[]=$this->uin.' 你不是好莱坞会员，无法签到';
		}else{
			$this->msg[]=$this->uin.' 好莱坞会员签到失败！'.$arr['msg'];
		}
	}
	public function dldqd(){
		$url = 'http://fight.pet.qq.com/cgi-bin/petpk?cmd=award&op=1&type=0';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$data = mb_convert_encoding($data, "UTF-8", "GB2312");
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]=$arr['ContinueLogin'].' + '.$arr['DailyAward'];
		}elseif($arr['ret']==-1){
			$this->msg[]=$arr['ContinueLogin'];
			$this->msg[]=$arr['DailyAward'];
		}elseif($arr['result']==-5){
			$this->skeyzt=1;
			$this->msg[]='大乐斗领礼包失败！SKEY已失效';
		}else{
			$this->msg[]='大乐斗领礼包失败！'.$arr['msg'];
		}
	}
    public function scqd() {
        $url = "http://ebook.3g.qq.com/user/v3/normalLevel/sign?sid=" . $this->sid . "&g_ut=2";
        $hms=$this->get_curl($url);
        $this->msg[] = "书城签到成功~[3G]";
    }
    public function gcw() //挂QQ宠物
    {
        $url = 'http://qqpet.wapsns.3g.qq.com/qqpet/fcgi-bin/phone_pet?petid=0&cmd=1&g_f=16&B_UID=' . $this->uin . '&sid=' . $this->sid;
        $this->get_curl($url);
        $this->msg[] = $this->uin . '挂QQ宠物成功~[3G]';
    }
    public function cqqd() //超Q签到
    {
		$url = 'http://mq.qq.com/index_userSignIn.shtml?r=0.'.time().'2899';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('iRet',$arr) && $arr['iRet']==0){
			$this->msg[]='超级ＱＱ签到成功！';
		}elseif($arr['iRet']==-10){
			$this->skeyzt=1;
			$this->msg[]='超级ＱＱ签到失败！SKEY已失效';
		}elseif($arr['iRet']==-11){
			$this->msg[]='超级ＱＱ已签到！';
		}else{
			$this->msg[]='超级ＱＱ签到失败！'.$data;
		}
		$url = 'http://mq.qq.com/activity/badgepk10_qiandao.shtml?r=0.'.time().'2796';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$data = mb_convert_encoding($data, "UTF-8", "GB2312"); 
		if(strpos($data,'签到成功')!==false){
			$this->msg[]='勋章馆签到成功！';
		}elseif(strpos($data,'感谢参与')!==false){
			$this->msg[]='勋章馆今天已签到！';
		}elseif(strpos($data,'领取失败')!==false){
			$this->msg[]='勋章馆签到失败！';
		}
    }
	public function wyqd() //微云签到
    {
		$data = $this->get_curl('http://web2.cgi.weiyun.com/weiyun_activity.fcg?cmd%20=17004&g_tk='.$this->gtk.'&data=%7B%22req_header%22%3A%7B%22cmd%22%3A17004%2C%22appid%22%3A30013%2C%22version%22%3A2%2C%22major_version%22%3A2%7D%2C%22req_body%22%3A%7B%22ReqMsg_body%22%3A%7B%22weiyun.WeiyunDailySignInMsgReq_body%22%3A%7B%7D%7D%7D%7D&format=json',0,'http://www.weiyun.com/',$this->cookie);
		$json = json_decode($data, true);
		$arr = $json['rsp_header'];
		if(array_key_exists('retcode',$arr) && $arr['retcode']==0){
			$this->msg[]='微云签到成功！空间增加 '.$json['rsp_body']['RspMsg_body']['weiyun.WeiyunDailySignInMsgRsp_body']['add_point'].'MB';
		}elseif($arr['retcode']==190051){
			$this->skeyzt=1;
			$this->msg[]='微云签到失败！SKEY已失效';
		}elseif(array_key_exists('retcode',$arr)){
			$this->msg[]='微云签到失败！'.$arr['retmsg'];
		}else{
			$this->msg[]='微云签到失败！'.$data;
		}
    }
	public function ncqd() //农场签到 
    {
		$this->get_curl('http://mcapp.z.qq.com/nc/cgi-bin/wap_farm_index?sid=' . $this->sid . '&g_ut=1');
        $this->get_curl('http://mcapp.z.qq.com/nc/cgi-bin/wap_farm_index?sid=' . $this->sid . '&g_ut=1&signin=1');
        $this->get_curl('http://mcapp.z.qq.com/nc/cgi-bin/wap_farm_freegift_recv?sid=' . $this->sid . '&g_ut=1&fg_recv=1');
		$this->get_curl('http://mcapp.z.qq.com/mc/cgi-bin/wap_pasture_index?sid=' . $this->sid . '&uin=' . $this->uin . '&g_ut=2&source=qzone');
        $this->get_curl('http://mcapp.z.qq.com/mc/cgi-bin/wap_pasture_index?sid=' . $this->sid . '&uin=' . $this->uin . '&g_ut=1&signin=1&yellow=1&optflag=2&pid=0&v=1');
        $this->msg[] = $this->uin . '牧场签到成功~[3G]';
        $this->msg[] = $this->uin . '农场签到成功~[3G]';
    }
    public function pcgamevipqd() //PC蓝钻签到
    {
        $data = $this->get_curl('http://app.gamevip.qq.com/cgi-bin/gamevip_sign/GameVip_SignIn?g_tk=' . $this->gtk . '&_=' . time() , 0, 'http://gamevip.qq.com/sign_pop/sign_pop_v2.html?ADTAG=GW.XSY.TOP.SIGN&refer=', $this->cookie,0,'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36');
        $arr = json_decode($data, true);
        if ($arr['FirstSignIn'] == 1) $this->msg[] = $this->uin . ' 蓝钻签到成功！[PC]您目前有' . $arr[LotteryTime0] . '抽奖机会和' . $arr[SignScore] . '积分！';
        elseif ($arr['FirstSignIn'] == 0) $this->msg[] = $this->uin . ' 您今天已经签到过了！[PC]您目前有' . $arr[LotteryTime0] . '抽奖机会和' . $arr[SignScore] . '积分！';
        elseif ($arr['result'] == 1000005) $this->msg[] = $this->uin . ' 您还没有登录！[PC]';
        else $this->msg[] = $this->uin . ' 蓝钻签到签到失败！[PC]' . $arr['resultstr'];
		$this->get_curl('http://mz.3g.qq.com/compaign/sign/signresult.jsp?fm=1&sid=' . $this->sid);
		$this->msg[] = $this->uin . '蓝钻签到成功~[3G]';
    }
	public function vipqd()
	{
		$url='http://vipfunc.qq.com/act/client_oz.php?action=client&g_tk='.$this->gtk2;
		$data=$this->get_curl($url,0,$url,$this->cookie);
		if($data=='{ret:0}')
			$this->msg[] = $this->uin.' 会员面板签到成功！';
		else
			$this->msg[] = $this->uin.' 会员面板签到失败！'.$json;

		//$url='http://vipfunc.qq.com/growtask/sign.php?cb=vipsign.signCb&action=daysign&actId=16&fotmat=json&t='.time().'141&g_tk='.$this->gtk2;
		//$data=$this->get_curl($url,0,$url,$this->cookie);
		$data=$this->get_curl("http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=23314&format=json&g_tk=" . $this->gtk2 ."&cachetime=".time(),0,'http://vip.qq.com/',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 会员网页版签到成功！';
		elseif($arr['ret']==10601)
			$this->msg[] = $this->uin.' 会员网页版今天已经签到！';
		elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 会员网页版签到失败！SKEY过期';
		}elseif($arr['ret']==20101)
			$this->msg[] = $this->uin.' 会员网页版签到失败！不是QQ会员！';
		else
			$this->msg[] = $this->uin.' 会员网页版签到失败！'.$arr['msg'];

		$data=$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?actid=52002&rand=0.27489888'.time().'&g_tk='.$this->gtk2.'&format=json',0,'http://vip.qq.com/',$this->cookie);
		//$data=$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?actid=23868&rand=0.387115'.time().'&g_tk='.$this->gtk2.'&sid='.$this->sid.'&format=json',0,'http://vip.qq.com/',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 会员手机端签到成功！';
		elseif($arr['ret']==10601)
			$this->msg[] = $this->uin.' 会员手机端今天已经签到！';
		elseif($arr['ret']==10002){
			$this->sidzt=1;
			$this->msg[] = $this->uin.' 会员手机端签到失败！SKEY过期';
		}else
			$this->msg[] = $this->uin.' 会员手机端签到失败！'.$arr['msg'];

		$data=$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=54963&isLoadUserInfo=1&format=json&g_tk='.$this->gtk2,0,'http://vip.qq.com/',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 会员积分签到成功！';
		elseif($arr['ret']==10601)
			$this->msg[] = $this->uin.' 会员积分今天已经签到！';
		elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 会员积分签到失败！SKEY过期';
		}else
			$this->msg[] = $this->uin.' 会员积分签到失败！'.$arr['msg'];

		$data=$this->get_curl('http://iyouxi.vip.qq.com/ams2.02.php?actid=23074&g_tk_type=1sid=&rand=0.8656469448520889&format=json&g_tk='.$this->gtk2,0,'http://vip.qq.com/',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 会员积分2签到成功！';
		elseif($arr['ret']==10601)
			$this->msg[] = $this->uin.' 会员积分2今天已经签到！';
		elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 会员积分2签到失败！SKEY过期';
		}else
			$this->msg[] = $this->uin.' 会员积分2签到失败！'.$arr['msg'];

		$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=27754&g_tk='.$this->gtk2.'&pvsrc=undefined&ozid=509656&vipid=MA20131223091753081&format=json&_='.time(),0,'http://vip.qq.com/',$this->cookie);//超级会员每月成长值
		$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?_c=page&actid=27755&g_tk='.$this->gtk2.'&pvsrc=undefined&ozid=509656&vipid=MA20131223091753081&format=json&_='.time(),0,'http://vip.qq.com/',$this->cookie);//超级会员每月积分
		$this->get_curl('http://iyouxi.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=22249&_c=page&format=json&_='.time(),0,'http://vip.qq.com/',$this->cookie);//每周薪水积分
		$this->get_curl("http://iyouxi.vip.qq.com/jsonp.php?_c=page&actid=5474&isLoadUserInfo=1&format=json&g_tk=".$this->gtk2."&_=".time(),0,0,$this->cookie);
	}
	public function lzqd(){
		$url='http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_feedback_send_lottery.fcg?activeid=110&rnd='.time().'157&g_tk='.$this->gtk.'&uin='.$this->uin.'&hostUin=0&format=json&inCharset=UTF-8&outCharset=UTF-8&notice=0&platform=activity&needNewCode=1';
		$data = $this->get_curl($url,0,'http://y.qq.com/vip/fuliwo/index.html',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			if($arr['data']['alreadysend']==1)
				$this->msg[]='您今天已经签到过了！';
			else
				$this->msg[]='绿钻签到成功！';
		}elseif($arr['code']==-200017){
			$this->msg[]='你不是绿钻无法签到！';
		}else{
			$this->msg[]='绿钻签到失败！';
		}

		$url='http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_get_present.fcg?activeid=73&rnd='.time().'029&g_tk='.$this->gtk.'&uin='.$this->uin.'&hostUin=0&format=json&inCharset=GB2312&outCharset=gb2312&notice=0&platform=activity&needNewCode=1';
		$data = $this->get_curl($url,0,'http://y.qq.com/vip/Installment_lv8/index.html',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='绿钻签到2成功！';
		}elseif($arr['code']==-200006){
			$this->msg[]='绿钻签到2今天已签到！';
		}else{
			$this->msg[]='绿钻签到2失败！';
		}

		$url='http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_get_present.fcg?activeid=128&rnd='.time().'029&g_tk='.$this->gtk.'&uin='.$this->uin.'&hostUin=0&format=json&inCharset=GB2312&outCharset=gb2312&notice=0&platform=activity&needNewCode=1';
		$data = $this->get_curl($url,0,'http://y.qq.com/vip/Installment_lv8/index.html',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='绿钻签到3成功！';
		}elseif($arr['code']==-200006){
			$this->msg[]='绿钻签到3今天已签到！';
		}elseif($arr['code']==200004){
			$this->msg[]='你不是绿钻无法签到！';
		}else{
			$this->msg[]='绿钻签到3失败！';
		}

		$url='http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_get_present.fcg?activeid=130&rnd='.time().'029&g_tk='.$this->gtk.'&uin='.$this->uin.'&hostUin=0&format=json&inCharset=GB2312&outCharset=gb2312&notice=0&platform=activity&needNewCode=1';
		$data = $this->get_curl($url,0,'http://y.qq.com/vip/Installment_lv8/index.html',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='绿钻签到4成功！';
		}elseif($arr['code']==-200006){
			$this->msg[]='绿钻签到4今天已签到！';
		}elseif($arr['code']==200004){
			$this->msg[]='你不是绿钻无法签到！';
		}else{
			$this->msg[]='绿钻签到4失败！';
		}

		$url='http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_get_present.fcg?activeid=138&rnd='.time().'029&g_tk='.$this->gtk.'&uin='.$this->uin.'&hostUin=0&format=json&inCharset=GB2312&outCharset=gb2312&notice=0&platform=activity&needNewCode=1';
		$data = $this->get_curl($url,0,'http://y.qq.com/vip/Installment_lv8/index.html',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='绿钻签到5成功！';
		}elseif($arr['code']==-200006){
			$this->msg[]='绿钻签到5今天已签到！';
		}elseif($arr['code']==200004){
			$this->msg[]='你不是绿钻无法签到！';
		}else{
			$this->msg[]='绿钻签到5失败！';
		}

		$url='http://share.music.qq.com/fcgi-bin/dmrp_activity/fcg_dmrp_draw_lottery.fcg?activeid=159&rnd='.time().'482&g_tk='.$this->gtk.'&uin='.$this->uin.'&hostUin=0&format=json&inCharset=UTF-8&outCharset=UTF-8&notice=0&platform=activity&needNewCode=1';
		$data = $this->get_curl($url,0,'http://y.qq.com/vip/fuliwo/index.html',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='绿钻抽奖成功！';
		}elseif($arr['code']==200008){
			$this->msg[]=$this->uin.'您没有抽奖机会！';
		}else{
			$this->msg[]=$this->uin.'绿钻抽奖失败！';
		}
		
	}
	public function jfqd(){
		$url = 'http://hydra.qzone.qq.com/cgi-bin/gift/gift_checkin?g_tk='.$this->gtk;
		$post = 'appid=50&type=7&cb=1&qzreferrer=http%3A%2F%2Fappimg2.qq.com%2Frewards%2Fhtml%2Fsignin_box.html';
		$data = $this->get_curl($url,$post,'http://imgcache.qq.com/qzone/v5/toolpages/fp_utf8.html',$this->cookie1);
		$data = $this->getSubstr($data,',"msg":"','"}');
		if($data=='今天已经签到了'){
		$this->msg[]=$this->uin.'今天已经QQ欢乐积分签到过了';
		}else{
		$this->msg[]=$this->uin.'QQ欢乐积分签到成功';	
		}
		
	}
	
	public function dtqd(){
				$url = 'http://social.minigame.qq.com/cgi-bin/social/welcome_panel_operate?format=json&cmd=2&uin='.$this->uin.'&DomainID=207&g_tk='.$this->gtk;
		$data = $this->get_curl($url,0,'http://minigame.qq.com/appdir/social/cloudHall/src/index/welcome.html',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('result',$arr) && $arr['result']==0) {
			if($arr['do_ret']==11)
				$this->msg[]=$this->uin.' 游戏大厅今天已签到！';
			else
				$this->msg[]=$this->uin.' 游戏大厅签到成功！';
		}elseif($arr['result']==1000005){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' 游戏大厅签到失败！SKEY已失效。';
		}else{
			$this->msg[]=$this->uin.' 游戏大厅签到失败！'.$arr['resultstr'];
		}
	}
	
	public function qqllqqd(){
		$url='http://iyouxi.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=64788&_='.time().'8906';
		$data = $this->get_curl($url,0,'http://tq.qq.com/qbrcenter/index.html',$this->cookie1,0,"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.69 Safari/537.36 QQBrowser/9.1.4060.400");
		$this->msg[]=$this->uin.'QQ浏览器签到成功 [PC]';
	}
	
	public function qzoneqd(){
		$url = 'http://vip.qzone.qq.com/fcg-bin/v2/fcg_mobile_vip_site_checkin?t=0.89457'.time().'&g_tk='.$this->gtk.'&qzonetoken=423659183';
		$post = 'uin='.$this->uin.'&format=json';
		$referer='http://h5.qzone.qq.com/vipinfo/index?plg_nld=1&source=qqmail&plg_auth=1&plg_uin=1&_wv=3&plg_dev=1&plg_nld=1&aid=jh&_bid=368&plg_usr=1&plg_vkey=1&pt_qzone_sig=1';
		$data = $this->get_curl($url,$post,$referer,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='黄钻签到成功！';
		}elseif(array_key_exists('code',$arr) && $arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='黄钻签到失败！SKEY已失效';
		}elseif(array_key_exists('code',$arr)){
			$this->msg[]='黄钻签到失败！'.$arr['message'];
		}else{
			$this->msg[]='黄钻签到失败！'.$data;
		}

		$url = 'http://activity.qzone.qq.com/fcg-bin/fcg_qzact_count?g_tk='.$this->gtk.'&format=json&actid=101&uin='.$this->uin.'&_='.time().'3333';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$data = mb_convert_encoding($data, "UTF-8", "GB2312");
		$arr = json_decode($data, true);
		$count = $arr['data']['rule']['1001']['count'][1]['left'];
		while($count>0) {
			$url = 'http://activity.qzone.qq.com/fcg-bin/fcg_qzact_lottery?g_tk='.$this->gtk;
			$post = 'actid=101&ruleid=1001&format=json&uin='.$this->uin.'&g_tk='.$this->gtk.'&qzreferrer=http%3A%2F%2Fqzs.qq.com%2Fqzone%2Fqzact%2Fact%2Fhkhd%2Findex.html';
			$referer='http://qzs.qq.com/qzone/qzact/act/hkhd/index.html';
			$data = $this->get_curl($url,$post,$referer,$this->cookie);
			$arr = json_decode($data, true);
			if(array_key_exists('code',$arr) && $arr['code']==0){
				$this->msg[]='黄钻抽奖成功！';
			}elseif($arr['code']==-3000){
				$this->skeyzt=1;
				$this->msg[]='黄钻抽奖失败！SKEY已失效';
			}elseif($arr['code']==-5004){
				$this->msg[]='黄钻抽奖失败！抽奖机会已用完';
			}elseif(array_key_exists('code',$arr)){
				$this->msg[]='黄钻抽奖失败！'.$arr['message'];
			}else{
				$this->msg[]='黄钻抽奖失败！'.$data;
			}
		}
	}
	public function pqd(){
		$url="http://iyouxi.vip.qq.com/ams3.0.php?g_tk=".$this->gtk2."&pvsrc=102&ozid=511022&vipid=&actid=32961&sid=".$this->sid."&format=json".time()."8777&cache=3654";
		$data = $this->get_curl($url,0,'http://youxi.vip.qq.com/m/wallet/activeday/index.html?_wv=3&pvsrc=102',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='钱包签到成功！';
		}elseif($arr['ret']==37206){
			$this->msg[]='钱包签到失败！你没有绑定银行卡';
		}elseif($arr['ret']==10601){
			$this->msg[]='你今天已钱包签到！';
		}else{
			$this->msg[]='钱包签到失败！'.$arr['msg'];
		}	
	}
	public function qqqlqd(){
		$url="http://sweet.snsapp.qq.com/v2/cgi-bin/sweet_signlove_get?cmd=0&startts=1442937600&endts=1446825600&opuin=".$this->uin."&uin=".$this->uin."&plat=1&g_tk=".$this->gtk;
		$data = $this->get_curl($url,0,'http://sweet.snsapp.qq.com/v2/cgi-bin/sweet_index?openid=0000000000000000000000000418BFC3&openkey=3B60E7F24D47E0C5D2470D345D5AC402&pf=qzone&pfkey=d2f25f6dae3b7513965ed28bef4ba584&app_appbitmap=0&appid=100622432',$this->cookie);
		$arr = json_decode($data, true);
		if($arr['code']==0){
		$this->msg[]='QQ情侣签到成功！';
		}elseif($arr['code']==-1){
			$this->skeyzt=1;
		$this->msg[]='QQ情侣失败！SKEY已失效';
		}else{
			$this->msg[]='QQ情侣签到失败！'.$arr['msg'];
		//}
		}
	}
	public function yyqd(){
		$url="http://appact.qzone.qq.com/appstore_activity_dailysign?action=level&act=5084&g_tk=".$this->gtk."&callback=_Callback&uin=".$this->uin."&_=".time();
		$data = $this->get_curl($url,0,'http://appstore.qzone.qq.com/cgi-bin/qzapps/qz_appstore_home_v5?uin='.$this->uin.'&pfid=2&qz_ver=8&appcanvas=0&qz_style=1&params=&entertime='.time().'&canvastype=','pt2gguin=o'.$this->uin.'; uin=o'.$this->uin.'; skey='.$this->skey.'; ptisp=ctc; p_skey='.$this->p_skey.';');
		$arr = json_decode($data, true);
		if($arr['code']==0){
		$this->msg[]='应用签到成功！';
		}elseif($arr['code']==-1){
			$this->skeyzt=1;
		$this->msg[]='应用签到失败！SKEY已失效';
		}else{
			$this->msg[]='应用签到失败！'.$arr['msg'];
		//}
		}
	}
	public function slqd(){//Author:龙魂 3366签到
		$url = 'http://fcg.3366.com/fcg-bin/growinfo/mgp_growinfo_signin?&_r=1443348237197&sCSRFToken=2067215453';
		$data = $this->get_curl($url,0,'http://www.3366.com/',$this->cookie);
		$data = mb_convert_encoding($data, "UTF-8", "GB2312");
		preg_match('/gGrowInfoSignInResult = (.*?);/is',$data,$json);
		$arr = json_decode($json[1], true);
		if(array_key_exists('result',$arr) && $arr['result']==0){
			$this->msg[]='3366签到成功！';
		}elseif($arr['result']==16001){
			$this->msg[]='3366今天已签到！';
		}elseif($arr['result']==10002){
			$this->skeyzt=1;
			$this->msg[]='3366签到失败！SKEY已失效';
		}elseif(array_key_exists('result',$arr)){
			$this->msg[]='3366签到失败！'.$arr['resultstr'];
		}else{
			$this->msg[]='3366签到失败！'.$data;
		}
	}
	public function gjqd(){
		$url='http://c.pc.qq.com/fcgi-bin/signin?format=json&mood_id=129&checkin_date='.date("Y-m-d").'&remark=%E6%88%91%E5%B0%B1%E6%98%AF%E6%9D%A5%E7%AD%BE%E5%88%B0%E7%9A%84';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$data = mb_convert_encoding($data, "UTF-8", "GB2312");
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']=='suc'){
			if($arr['result']==2)
				$this->msg[]='QQ管家今天已签到！';
			else
				$this->msg[]='QQ管家签到成功！';
		}elseif(strpos($arr['ret'],'登录失败')!==false){
			$this->skeyzt=1;
			$this->msg[]='QQ管家签到失败！SKEY已失效';
		}elseif(array_key_exists('ret',$arr)){
			$this->msg[]='QQ管家签到失败！'.$arr['ret'];
		}else{
			$this->msg[]='QQ管家签到失败！'.$data;
		}
	}
    public function is_zan() {
        $ch = curl_init('http://ish.z.qq.com/infocenter_v2.jsp?B_UID=' . $this->uin . '&sid=' . $this->sid . '&g_ut=1');
        curl_setopt($ch, CURLOPT_USERAGENT, "MQQBrowser WAP (Nokia/MIDP2.0)");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $contents = curl_exec($ch);
        curl_close($ch);
        preg_match_all('@<a href="http://blog(\d)0.z.qq.com/like/like_action.jsp(.*)">赞\(\d{1,}\)</a>@Ui', $contents, $url_array);
        $n = count($url_array['2']);
        for ($i = 0; $i < $n; $i++) {
            $url = "http://blog" . $url_array['1'][$i] . "0.z.qq.com/like/like_action.jsp" . $url_array['2'][$i];
            $ch = curl_init(html_entity_decode($url));
            curl_setopt($ch, CURLOPT_USERAGENT, "MQQBrowser WAP (Nokia/MIDP2.0)");
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_NOBODY, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 0);
            curl_exec($ch);
            curl_close($ch);
        }
    }
	public function getSubstr($str, $leftStr, $rightStr){
		$left = strpos($str, $leftStr);
		//echo '左边:'.$left;
		$right = strpos($str, $rightStr,$left);
		//echo '<br>右边:'.$right;
		if($left < 0 or $right < $left) return '';
		return substr($str, $left + strlen($leftStr), $right-$left-strlen($leftStr));
	}
	public function get_qqnick($uin){
    if($data=file_get_contents("http://users.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg?get_nick=1&uins=".$uin)){
		$data=str_replace(array('portraitCallBack(',')'),array('',''),$data);
		$data=mb_convert_encoding($data, "UTF-8", "GBK");
		$row=json_decode($data,true);;
		return $row[$uin][6];
	}
}
}