<?php
/*
�Զ�����Pskey&Skey ����ļ�
Original Author:��ʧ�Ĳʺ纣 && ���� && ����
*/
header("Content-Type: text/html; charset=UTF-8");
function login_sig(){
	$url="http://xui.ptlogin2.qq.com/cgi-bin/xlogin?proxy_url=http%3A//qzs.qq.com/qzone/v6/portal/proxy.html&daid=5&pt_qzone_sig=1&hide_title_bar=1&low_login=0&qlogin_auto_login=1&no_verifyimg=1&link_target=blank&appid=549000912&style=22&target=self&s_url=http%3A//qzs.qq.com/qzone/v5/loginsucc.html?para=izone&pt_qr_app=�ֻ�QQ�ռ�&pt_qr_link=http%3A//z.qzone.com/download.html&self_regurl=http%3A//qzs.qq.com/qzone/v6/reg/index.html&pt_qr_help_link=http%3A//z.qzone.com/download.html";
	$ret = get_curl($url,0,1,0,1);
	preg_match('/pt_login_sig=(.*?);/',$ret,$skey);
	return $skey[1];
}
function checkvc($uin){
	$url='http://check.ptlogin2.qq.com/check?regmaster=&pt_tea=1&pt_vcode=1&uin='.$uin.'&appid=549000912&js_ver=10132&js_type=1&login_sig=&u1=http%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&r=0.397176'.time();
	$data=get_curl($url);
	if(preg_match('/ptui_checkVC'."\(".'\'(.*?)\''."\)".';/', $data, $arr)){
		$r=explode('\',\'',$arr[1]);
		if($r[0]==0){
			return array('0',$r[1],$r[3]);
		}else{
			return array('1');
		}
	}else{
		return array('2');
	}
}
function getsid($url, $do = 0){
	$do++;
	if ($ret = get_curl($url)) {
		$ret = preg_replace('/([\x80-\xff]*)/i','',$ret);
		if (preg_match('/sid=(.{24})&/iU', $ret, $sid)) {
			return $sid[1];
		} else {
			if ($do < 5) {
				return getsid($url, $do);
			} else {
				return;
			}
		}
	} else {
		return;
	}
}
function qqlogin($uin,$p,$vcode,$pt_verifysession){
	$v1=0;
	$url='http://ptlogin2.qq.com/login?u='.$uin.'&verifycode='.$vcode.'&pt_vcode_v1='.$v1.'&pt_verifysession_v1='.$pt_verifysession.'&p='.$p.'&pt_randsalt=0&u1=http%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=2-10-'.time().'7584&js_ver=10133&js_type=1&login_sig='.login_sig().'&pt_uistyle=32&aid=549000912&daid=5&pt_qzone_sig=0&';
	$sidurl = 'http://ptlogin2.qzone.com/login?verifycode='.$vcode.'&u='.$uin.'&p='.$p.'&pt_randsalt=0&ptlang=2052&low_login_enable=0&u1=http%3A%2F%2Fsqq2.3g.qq.com%2Fhtml5%2Fsqq2vip%2Findex.jsp&from_ui=1&fp=loginerroralert&device=2&aid=549000912&pt_ttype=1&daid=147&pt_3rd_aid=0&ptredirect=1&h=1&g=1&pt_uistyle=9&pt_vcode_v1='.$v1.'&pt_verifysession_v1='.$pt_verifysession.'&';
	$ret = get_curl($url,0,0,0,1);
	$sidret = get_curl($sidurl,0,0,0,1,"'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0");
	if(preg_match("/ptuiCB\('(.*?)'\);/", $ret, $arr) && preg_match("/ptuiCB\('(.*?)'\);/", $sidret, $sidarr)){
		$r=explode("','",str_replace("', '","','",$arr[1]));
		$sr=explode("','",str_replace("', '","','",$sidarr[1]));
		if($r[0]==0){
			preg_match('/skey=@(.{9});/',$ret,$skey);
			$data=get_curl($r[2],0,0,0,1);
			if($data) {
				preg_match("/p_skey=(.*?);/", $data, $matchs);
				$p_skey = $matchs[1];
			}
			$data=get_curl($sr[2],0,0,0,1,"'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0");
			if($data) {
				preg_match("/p_skey=(.*?);/", $data, $matchs);
				$p_skey2 = $matchs[1];
			}
			if($p_skey && $p_skey2 && $skey){
				$array['skey']='@'.$skey[1];
				$array['p_skey']=$p_skey;
				$array['p_skey2']=$p_skey2;
			}
			return $array;
		}elseif($r[0]==4){
			return 4;
		}elseif($r[0]==3){
			return 3;
		}elseif($r[0]==19){
			return 19;
		}else{
			return 0;
		}
	}else{
		return 0;
	}
}
function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			if($referer==1){
				curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
			}else{
				curl_setopt($ch, CURLOPT_REFERER, $referer);
			}
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);
		}
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		//$ret=mb_convert_encoding($ret, "UTF-8", "UTF-8");
		return $ret;
}
$mysql=require("../includes/db.php");
$dbhost=$mysql['DB_HOST'].':'.$mysql['DB_PORT'];
$dbuser=$mysql['DB_USER'];
$dbpassword=$mysql['DB_PWD'];
$dbmysql=$mysql['DB_NAME'];
if($con = mysql_connect($dbhost,$dbuser,$dbpassword)){
	mysql_select_db($dbmysql, $con);
}else{
	exit('���ݿ�����ʧ�ܣ�');
}
mysql_query("set names utf8"); 
$domain = $_SERVER['HTTP_HOST'];
$results=mysql_query("select * from tgyd_separate where urls='$domain' limit 1");
if($separate = mysql_fetch_array($results)){
$tableqz = $separate['prefix']."_";
$endtime = $separate['endtime'];
$now = date("Y-m-d");
if ($endtime <= $now) exit("��վ�Ѿ����ڣ�");
$isdomain = 1;
}else{
$tableqz=$mysql['DB_PREFIX'];
}
$result=mysql_query("select * from {$tableqz}qqs where skeyzt='1' or sidzt='1' limit 10");
while($row=mysql_fetch_array($result)){
$uin=$row['qq'];
$pwd=$row['pwd'];
$time=date("Y-m-d H:i:s");
$check=checkvc($uin);
if($check[0]==0){
	$vcode=$check[1];
	$p=get_curl('http://qqapp.aliapp.com/?uin='.$uin.'&pwd='.strtoupper($pwd).'&vcode='.strtoupper($vcode));
	if($P=''){exit($p);}
	$arr=qqlogin($uin,$p,$vcode,$check[2]);
	if($arr==3){
		@mysql_query("UPDATE {$tableqz}qqs SET gxmsg='QQ�������',lastauto='$time' WHERE qq='".$uin."'");
	}elseif(is_array($arr)){
		$skey=$arr['skey'];
		$p_skey=$arr['p_skey'];
		$p_skey2=$arr['p_skey2'];
		@mysql_query("UPDATE {$tableqz}qqs SET skey='$skey',p_skey='$p_skey',p_skey2='$p_skey2',skeyzt='0',sidzt='0',lastauto='$time' WHERE qq='".$uin."'");
		echo $uin.'ok!<br/>';
	}elseif($arr==19){
		@mysql_query("UPDATE {$tableqz}qqs SET gxmsg='�����ʺ���ʱ�޷���¼���뵽 http://aq.qq.com/007 �ָ�����ʹ��',lastauto='$time' WHERE qq='".$uin."'");
	}else{
		@mysql_query("UPDATE {$tableqz}qqs SET gxmsg='����ʧ��,δ֪����',lastauto='$time' WHERE qq='".$uin."'");
	}
}else{
	@mysql_query("UPDATE {$tableqz}qqs SET gxmsg='����ʧ��,��Ҫ��֤��',lastauto='$time' WHERE qq='".$uin."'");
}
}
echo 'ok';
?>