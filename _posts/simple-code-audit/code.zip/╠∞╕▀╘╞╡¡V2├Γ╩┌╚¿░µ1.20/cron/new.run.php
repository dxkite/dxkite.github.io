<?php
//秒赞 秒评 转发 圈图/按照频率计算
include_once "conn.php";
$qid=is_numeric($_GET['qid'])?$_GET['qid']:exit('No Qid!');
$result = mysql_query("SELECT * FROM {$tableqz}qqs where qid='{$qid}' and (iszan>0 or isreply>0 or iszf >0 or isqt >0) and sidzt=0 limit 1");
if($row=mysql_fetch_array($result)){
	$uin=$row['qq'];
	$sid=$row['sid'];
	$skey=$row['skey'];
	$p_skey=$row['p_skey'];
	$type=$row['istype'];
	$zanlist=$row['zanlist'];
	$p_skey=$row['p_skey'];
	$p_skey2=$row['p_skey2'];
	$now=date("Y-m-d-H:i:s");
	$next=date("Y-m-d H:i:s",time()+60*$row['zanrate']-10);
	$sql='';
	if($row['iszan']) $sql.="lastzan='$now',";
	if($row['isreply']) $sql.="lastreply='$now',";
	if($row['iszf']) $sql.="lastzf='$now',";
	if($row['isqt']) $sql.="lastqt='$now',";
	@mysql_query("update {$tableqz}qqs set {$sql}nextzan='$next' where qid='$qid'");
	include_once "qzone.class.php";
	$qzone=new qzone($uin,$sid,$skey,$p_skey,$p_skey2);
			if($row['iszan']){
				$like=$shuo['like']['isliked'];
				if($like==0){
					if($row['iszan']==2){
						$qzone->like(1,$type, $zanlist);
					}elseif($row['iszan']==3){
						$qzone->like(2,$type, $zanlist);
					}else{
						$qzone->like(0,$type, $zanlist);
					}
				}
			}
			if($row['iszf']){
					if($row['iszf'] == 1){
						$qzone->zhuanfa(1,$row['zfok'],get_con($row['zfcon']));
					}else{
						$qzone->zhuanfa(0,$row['zfok'],get_con($row['zfcon']));
					}
			}
			if($row['isreply']){
					if($row['isreply']==2){
						$richval=0;
						$qzone->reply('pc',get_con($row['replycon']),$richval);
					}else{
						$qzone->reply(0,get_con($row['replycon']),$uin,$cellid,$appid,$param);
					}
				}
			if($row['isqt']){
				$qzone->quantu();
			}
	//结果输出
foreach($qzone->msg as $result){
	echo $result.'<br/>';
}
$qzone->skeyzt=1;
include_once "autoclass.php";
	exit('Ok!');
}else{
	exit('请检查是否开启了本功能或状态是否失效');
}
