<?php
//互刷类四合一/不限时
include_once "conn.php";
$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$result = mysql_query("SELECT * FROM {$tableqz}qqs where qid='{$qid}' and (iszyzan>0 or islw>0 or isly>0 or isrq>0) and sidzt=0 limit 1");
if ($row = mysql_fetch_array($result)) {
    $uin = $row['qq'];
    $sid = $row['sid'];
    $skey = $row['skey'];
    $p_skey = $row['p_skey'];
    $p_skey2 = $row['p_skey2'];
    $now = date("Y-m-d-H:i:s");
    $next = date("Y-m-d H:i:s", time() + 60 * 60 * 8 - 10);
    include_once "qzone.class.php";
    $result = mysql_query("SELECT * FROM {$tableqz}qqs where sidzt=0 order by rand()");
    while ($qq = mysql_fetch_array($result)) {
        $qid = $qq['qid'];
        $con = get_con();
        $qzone = new qzone($qq['qq'], $qq['sid'], $qq['skey'], $qq['p_skey'], $qq['p_skey2']);
        if ($row['iszyzan']) {
            $sql.= "lastzyzan='$now',";
            $qzone->zyzan($uin);
        }
        if ($row['isly']) {
            $sql.= "lastly='$now',";
            $qzone->liuyan($uin, $con);
        }
        if ($row['isrq']) {
            $sql.= "lastrq='$now',";
            $qzone->rq($uin, $con);
        }
        if ($row['islw']) {
            $sql.= "lastlw='$now',";
            $qzone->gift($uin, $con);
        }
    }
    @mysql_query("update {$tableqz}qqs set {$sql}nextzyzan='$next' where qid='$qid'");
    foreach ($qzone->msg as $result) {
        echo $result . '<br/>';
    }
	include_once "autoclass.php";
    exit('Ok!');
} else {
    exit('Qid Error!');
}

