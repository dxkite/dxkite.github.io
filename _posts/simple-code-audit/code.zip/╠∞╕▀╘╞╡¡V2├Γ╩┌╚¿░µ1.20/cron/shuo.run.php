<?php
//空间自动发说说/按频率计算
include_once "conn.php";
$qid = is_numeric($_GET['qid']) ? $_GET['qid'] : exit('No Qid!');
$result = mysql_query("SELECT * FROM {$tableqz}qqs where qid='{$qid}' and isshuo>0 and sidzt=0 limit 1");
if ($row = mysql_fetch_array($result)) {
	$uid = $row['uid'];
	$result2 = mysql_query("SELECT * FROM {$tableqz}users where uid='{$uid}' limit 1");
	$result2 = mysql_fetch_array($result2);
    $uin = $row['qq'];
    $sid = $row['sid'];
    $skey = $row['skey'];
    $p_skey = $row['p_skey'];
    $p_skey2 = $row['p_skey2'];
    $do = $row['isshuo'];
    $now = date("Y-m-d-H:i:s");
    $next = date("Y-m-d H:i:s", time() + 60 * $row['shuorate'] * 60 - 10);
    @mysql_query("update {$tableqz}qqs set lastshuo='$now',nextshuo='$next' where qid='$qid'");
	$gg = $row['shuogg'];
	if(get_isvip($result2[vip],$result2[vipend])){ $con = get_con($row['shuoshuo'].$gg);}else{$con = get_con($row['shuoshuo'].C('shuogg'));}
    $pic = $row['shuopic'];
    if ($pic == '[图片]') {
        $row = file('../other/pic.txt');
        shuffle($row);
        $pic = $row[0];
        $type = 0;
    } else {
        $type = stripos('z' . urlencode($pic), 'http') ? 0 : 1;
    }
    $pic = trim($pic);
    include_once "qzone.class.php";
    $qzone = new qzone($uin, $sid, $skey, $p_skey, $p_skey2);
    if ($do == 2) {
        $qzone->shuo('pc', $con, $pic);
    } else {
        $qzone->shuo(0, $con, $pic);
    }
	//结果输出
foreach($qzone->msg as $result){
	echo $result.'<br/>';
}
include_once "autoclass.php";
    exit('Ok!');
} else {
    exit('Qid Error!');
}

