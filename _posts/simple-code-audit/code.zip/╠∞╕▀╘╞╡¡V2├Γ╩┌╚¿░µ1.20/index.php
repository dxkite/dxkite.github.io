<?php
require_once('includes/common.php');
number(C('number'));
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=C('webname')?> - <?=C('webkey')?></title>
	<meta name="keywords" content="再续秒赞,HTK系统,稳定高效,安全快速,全天自动操作,最稳定的云任务系统">
	<meta name="description" content="QQ网络红人推广必备工具,QQ空间人气王,QQ全能助手,再续秒赞QQ助手让您早日成为QQ达人">   
    <link href="http://iqiy.wx.jaeapp.com/index/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="http://iqiy.wx.jaeapp.com/index/css/flexslider.css" rel="stylesheet" >
    <link href="http://iqiy.wx.jaeapp.com/index/css/styles.css" rel="stylesheet">
    <link href="http://iqiy.wx.jaeapp.com/index/css/queries.css" rel="stylesheet">
    <link href="http://iqiy.wx.jaeapp.com/index/css/animate.css" rel="stylesheet">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
      </head>
      <body id="top">
        <header id="home">
          <nav>
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 col-xs-8 col-xs-offset-2">
                  <nav class="pull">
                    <ul class="top-nav">
                      <li><a href="#intro">新功能展示 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
                      <li><a href="#features">系统体验 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
                      <li><a href="#responsive">微语 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
                      <li><a href="#portfolio">功能介绍 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
                      <li><a href="#contact">系统信息 <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </nav>
          <section class="hero" id="hero">
            <div class="container">
              <div class="row">
                <div class="col-md-12 text-right navicon">
                  <a id="nav-toggle" class="nav_slide_button" href="#"><span></span></a>
                </div>
              </div>
              <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center inner">
                  <h1 class="animated fadeInDown">TGYDS - V2<font color="#F00078"><?=C('webname')?></font></h1> 
                </div>
				<div class="col-md-6 col-md-offset-3 text-center">
				<p class="animated fadeInUp delay-1s"></p>
                </div>
				<div class="col-md-6 col-md-offset-3 text-center">
				<p class="animated fadeInUp delay-05s">梦起航心飞扬 天高V2非比寻常 打造全网最实效的秒赞网. <em>V2</em></p>
				<a href="#" class="down-arrow-btn">V2</a>
                </div>
              </div>
              <div class="row">
			  <div class="col-md-6 col-md-offset-3 text-center">
				<p class="animated fadeInUp delay-05s">全新界面,响应式设计 唯一的不同 就是处处不同. <em>TIANGAO</em></p>
                </div>
                <div class="col-md-6 col-md-offset-3 text-center">
				<?php if(C('loginuid')){?>
							<a href="/mgmt" class="learn-more-btn">欢迎您的回来,<?=$userrow[user]?></a>
				            <?php }else{?>
				            <a href="/login.php" class="learn-more-btn">登陆</a>
							<a href="/reg.php" class="learn-more-btn">注册</a>
				            <?php }?>
                </div>
              </div>
            </div>
          </section>
        </header>
        <section class="intro text-center section-padding" id="intro">
          <div class="container">
            <div class="row">
              <div class="col-md-8 col-md-offset-2 wp1">
                <h1 class="arrow">HTK2.21简体化系统</h1>
                <p>一直以来 <a href="/">HTK系统</a>. 都带给人们一种与众不同的体验：看似简单，用起来却引人入胜,不断创新,不断改进. 在原版进行整改. 代码体积完美精简. 完美对系统优化 减小差异, 全新分站系统,一键无限搭建分站 在分站的基础进行整改 与主站差异更小 为这种绝妙体验赋予了全新的维度。HTK系统 不仅是界面变更，它还帮你变得更有效率，更富创造力，为你开启一片更广阔的天地。.</p>
              </div>
            </div>
          </div>
        </section>
        <section class="features text-center section-padding" id="features">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <h1 class="arrow">一个广阔的空间，任你尽情挥洒大创意</h1>
                <div class="features-wrapper">
                  <div class="col-md-4 wp2">
                    <div class="icon">
                      <i class="fa fa-laptop shadow"></i>
                    </div>
                    <h2>人性化设计</h2>
                    <p>为了达到客户的人性化要求的极致的体验 <a href="/">HTK系统</a>特意加入了模式选择 云系统选择 内容图片选择等等 网站的界面都使用了响应式模板的设计 让平板 手机 电脑客户端 都能在线访问我们的网站.</p>
                  </div>
                  <div class="col-md-4 wp2 delay-05s">
                    <div class="icon">
                      <i class="fa fa-code shadow"></i>
                    </div>
                    <h2>系统开发</h2>
                    <p><a href="/">HTK系统</a>是通过php集成开发的系统,通过api客户端返回信息到系统中 由系统操纵全局 达到分布式云端系统,内置QQ多功能系统 任何功能都有介绍,只需10分钟可让您了如指撑的使用本系统 以便快速上手 .</p>
                  </div>
                  <div class="col-md-4 wp2 delay-1s">
                    <div class="icon">
                      <i class="fa fa-heart shadow"></i>
                    </div>
                    <h2>创意方向</h2>
                    <p>专注于创造更具沟通力的“QQ云助手”，通过传统或创新接触点，实现与目标人群互动。希望通过我们，您能够进一步了解我们的理念与作品，为进一步合作打下基础。通过我们的内容创意和品牌管理，加强您的品牌实力。.</p>
                  </div>
                  <div class="clearfix"></div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="text-center" id="responsive">
          <div class="container-fluid nopadding responsive-services">
            <!--<div class="wrapper">
              <div class="iphone">
                <div class="wp3"></div>
              </div>
              <div class="fluid-white"></div>
            </div> -->
            <div class="wrapper">
              
                
                  <div id="servicesSlider">
                    <ul class="slides">
                      <li>
                        <h1 class="arrow">奔驰过无数个QQ,踩踏过无数个好友</h1>
                        <p>我们追求的是稳定与时效事物的最高境界，即使不用手指也能够瞬间操作！主打稳定时效功能,消除臃肿活血化瘀. </p>
                        <p>为了科技改变生活的那一点点感动，我不停挑战自己，激情创业。有人说我太理想不现实，也有人说我有梦想敢追求;我是范典 我为你而生. </p>
                        <p>有目标的人生才有方向有规划的人生才更精彩 - <?=C('webname')?>为你而生.</p>
                      </li>
                      <li>
                        <h1 class="arrow">更多免费,实用功能 实力运营 技术领先</h1>
                        <p>本站功能一键开启，无需安装软件，电脑、平板、手机全部一站式通用无需安装任何额外软件，注册登陆后添加QQ即可运行，您可以随时登陆本站设置. </p>
                        <p>智能提醒服务 QQ过期后邮件自动推送，使用专业的发信平台，保证邮件的送达率，让您秒赞24小时正常运行一切由我们来操作. </p>
                        <p>分布式管理 高配置服务器采用分布式监控系统的运行，24小时不间断稳定不宕机，服务器秒级切换更改随心，离线托管完美使用体验.</p>
                      </li>
                    </ul>
                  </div>
                
              
            </div>
          </div>
        </section>
        <section class="swag text-center">
          <div class="container">
            <div class="row">
              <div class="col-md-8 col-md-offset-2">
                <h1>stems from a hobby<span>but <em>design</em> 'aint one</span></h1>
                <a href="#portfolio" class="down-arrow-btn"><i class="fa fa-chevron-down"></i></a>
              </div>
            </div>
          </div>
        </section>
        <section class="portfolio text-center section-padding" id="portfolio">
          <div class="container">
            <div class="row">
              <div id="portfolioSlider">
                <ul class="slides">
                  <li>
                    <div class="col-md-4 wp4">
                      <div class="overlay-effect effects clearfix">
                        <div class="img">
                          <img src="http://iqiy.wx.jaeapp.com/index/img/portfolio-01.jpg" alt="Portfolio Item">
                          <div class="overlay">
                            <a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
                            <a class="close-overlay hidden">x</a>
                          </div>
                        </div>
                      </div>
                      <h2>各项签到</h2>
                      <p>更有QQ会员 绿钻 蓝钻 QQ群等签到新增QQ管家 好莱坞 QQ部落 黄钻 空间 大乐斗 等等签到功能让您每天全自动领取签到奖励和积分 QQ等级迅速提升.</p>
                    </div>
                    <div class="col-md-4 wp4 delay-05s">
                      <div class="overlay-effect effects clearfix">
                        <div class="img">
                          <img src="http://iqiy.wx.jaeapp.com/index/img/portfolio-02.jpg" alt="Portfolio Item">
                          <div class="overlay">
                            <a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
                            <a class="close-overlay hidden">x</a>
                          </div>
                        </div>
                      </div>
                      <h2>其他功能</h2>
                      <p>本系统带有QQ空间音乐查询 在线拉圈圈赞99+ 好友测赞 一测便知 单项好友测试 抓出无视你的好友 领取图书VIP会员 免费使用7天 等等更多免费功能.</p>
                    </div>
                    <div class="col-md-4 wp4 delay-1s">
                      <div class="overlay-effect effects clearfix">
                        <div class="img">
                          <img src="http://iqiy.wx.jaeapp.com/index/img/portfolio-03.jpg" alt="Portfolio Item">
                          <div class="overlay">
                            <a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
                            <a class="close-overlay hidden">x</a>
                          </div>
                        </div>
                      </div>
                      <h2>主要功能</h2>
                      <p>系统自带的主要核心功能 离线云点赞 评论 在线转发 24h不断发表说说 还可以说说圈图片 让空间不再孤单 迅速成为QQ达人 空间全能达人 赶紧加入我们吧！.</p>
                    </div>
                  </li>
                  <li>
                    <div class="col-md-4 wp4">
                      <div class="overlay-effect effects clearfix">
                        <div class="img">
                          <img src="http://iqiy.wx.jaeapp.com/index/img/portfolio-01.jpg" alt="Portfolio Item">
                          <div class="overlay">
                            <a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
                            <a class="close-overlay hidden">x</a>
                          </div>
                        </div>
                      </div>
                      <h2>QQ群功能</h2>
                      <p>我们的系统目前已开发出QQ群全套功能,带有QQ群部落签到 QQ群签到 QQ群问问签到 终端api服务器 更稳定 对协议各种程度的更新 不同程度的优化后 稳定高效.</p>
                    </div>
                    <div class="col-md-4 wp4 delay-05s">
                      <div class="overlay-effect effects clearfix">
                        <div class="img">
                          <img src="http://iqiy.wx.jaeapp.com/index/img/portfolio-02.jpg" alt="Portfolio Item">
                          <div class="overlay">
                            <a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
                            <a class="close-overlay hidden">x</a>
                          </div>
                        </div>
                      </div>
                      <h2>互刷功能</h2>
                      <p>目前本站有互刷人气 互刷空间主页赞 互刷空间礼物 互刷空间留言 4大互刷系统 使用站内的用户和您实现互动 互刷指使用我的号给站内用户刷 然后用户刷给我们 实现互刷.</p>
                    </div>
                    <div class="col-md-4 wp4 delay-1s">
                      <div class="overlay-effect effects clearfix">
                        <div class="img">
                          <img src="http://iqiy.wx.jaeapp.com/index/img/portfolio-03.jpg" alt="Portfolio Item">
                          <div class="overlay">
                            <a href="#" class="expand"><i class="fa fa-search"></i><br>View More</a>
                            <a class="close-overlay hidden">x</a>
                          </div>
                        </div>
                      </div>
                      <h2>高效率系统</h2>
                      <p>本系统内带HTK系统 QQ全能助手 全新的系统 极致 让你体验不一样的感觉,犹如风拂过您的身旁 我们来自于爱好 源于2015 <?=C('webname')?>为你而生.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
        <div class="ignite-cta text-center">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <a href="#" class="ignite-btn">开启无限可能</a>
              </div>
            </div>
          </div>
        </div>
        <section class="subscribe text-center">
          <div class="container">
            <h1><i class="fa fa-paper-plane"></i><span>Music appreciation</span></h1>
        <script language="JavaScript" type="text/javascript"> 
		tips = new Array(10); 
		tips[0] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=30953009&auto=1&height=66"></iframe>'; 
		tips[1] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=5243349&auto=1&height=66"></iframe>'; 
		tips[2] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=186016&auto=1&height=66"></iframe>'; 
		tips[3] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=5239544&auto=1&height=66"></iframe>'; 
		tips[4] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=31673137&auto=1&height=66"></iframe>'; 
		tips[5] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=32548830&auto=1&height=66"></iframe>'; 
		tips[6] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=32548830&auto=1&height=66"></iframe>'; 
		tips[7] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=28219176&auto=1&height=66"></iframe>'; 
		tips[8] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=28219175&auto=1&height=66"></iframe>'; 
		tips[9] = '<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="http://music.163.com/outchain/player?type=2&id=32619118&auto=1&height=66"></iframe>'; 
		index = Math.floor(Math.random() * tips.length); 
		document.write(tips[index]); 
		</script> 
          </div>
        </section>
        <section class="dark-bg text-center section-padding contact-wrap" id="contact">
          <a href="#top" class="up-btn"><i class="fa fa-chevron-up"></i></a>
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <h1 class="arrow">运行详细</h1>
              </div>
            </div>
            <div class="row contact-details">
              <div class="col-md-4">
                <div class="light-box box-hover">
                  <h2><i class="fa fa-map-marker"></i><span>time</span></h2>
                  <p>
				  <?php
				  $showtime = date("Y年m月d日H时i分s秒"); 
				  echo $showtime; 
				  ?>
				  </p>
                </div>
              </div>
              <div class="col-md-4">
                <div class="light-box box-hover">
                  <h2><i class="fa fa-mobile"></i><span>statistical</span></h2>
                  <p>用户:<?=get_count('users',"uid")?> QQ:<?=get_count('qqs',"uid")?></p>
                </div>
              </div>
              <div class="col-md-4">
                <div class="light-box box-hover">
                  <h2><i class="fa fa-paper-plane"></i><span>system</span></h2>
                  <p><a href="#">代理:<?=get_count('users',"daili=1")?> 副站长:<?=get_count('users',"fuzhan=1")?></a></p>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <ul class="social-buttons">
                  <li><a href="#" class="social-btn"><i class="fa fa-dribbble"></i></a></li>
                  <li><a href="#" class="social-btn"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#" class="social-btn"><i class="fa fa-envelope"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
        </section>
        <footer>
          <div class="container">
            <div class="row">
              <div class="col-md-6">
                <ul class="legals">
                  <li><a href="#">Die工作室秒赞</a></li>
                  <li><a href="#"><?=C('webname')?></a></li>
                </ul>
              </div>
              <div class="col-md-6 credit">
                <p>天高云淡v2 &amp; HTK1.0 by <a href="#"><?=C('webname')?></a> - <a href="/" target="_blank" title="Die工作室">Die工作室</a></p>
              </div>
            </div>
          </div>
        </footer>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="http://iqiy.wx.jaeapp.com/index/js/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="http://iqiy.wx.jaeapp.com/index/js/waypoints.min.js"></script>
        <script src="http://iqiy.wx.jaeapp.com/index/js/bootstrap.min.js"></script>
        <script src="http://iqiy.wx.jaeapp.com/index/js/scripts.js"></script>
        <script src="http://iqiy.wx.jaeapp.com/index/js/jquery.flexslider.js"></script>
        <script src="http://iqiy.wx.jaeapp.com/index/js/modernizr.js"></script>
      </body>
    </html>