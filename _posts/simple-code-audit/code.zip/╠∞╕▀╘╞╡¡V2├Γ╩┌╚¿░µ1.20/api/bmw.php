<?php
/*
 * 卡宝马在线核心代码 Author:云影 Contact-QQ:8711973
 */
function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept:application/json";
		$httpheader[] = "Accept-Encoding:gzip,deflate,sdch";
		$httpheader[] = "Accept-Language:zh-CN,zh;q=0.8";
		$httpheader[] = "Connection:close";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			if($referer==1){
				curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
			}else{
				curl_setopt($ch, CURLOPT_REFERER, $referer);
			}
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);
		}
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		//$ret=mb_convert_encoding($ret, "UTF-8", "UTF-8");
		return $ret;
	}
@header("Content-Type: text/html; charset=UTF-8");
$uin = $_GET['qq'];//QQ账号
$skey = $_GET['skey'];//SKEY
$qid = $_GET['qid'];//QID
$url = "http://openmobile.qq.com/oauth2.0/m_sdkauthorize";
$data = "uin={$uin}&app_id=101089751&response_type=token&sdkv=2.8&status_version=9&client_id=101089751&app_name=%E7%A4%BE%E4%BA%A4%E4%BA%92%E8%81%94&status_machine=iPad2%2C5&skey={$skey}&status_os=9.0.2&scope=get_user_info%2Cget_info%2Cget_simple_userinfo&openapi=&format=json&sdkp=i";
$UA = "TencentConnect SDK device = iPad Os = ios Version = 9.0.2";
$results = get_curl($url,$data,0,0,0,$UA);
$results = preg_match('/_Callback\((.*?)\)\;/is',$results,$json);
$json = $json[1];
$arr = json_decode($json,true);
$access_token = $arr['access_token'];
$openid  = $arr['openid'];
$url2 = "https://opensdk.mobile.qq.com/v3/openqq/getmsg?sdkappid=101089751&accesstoken={$access_token}&sdkapptoken=01696ced2b5f1094fe2f0310b284a28901&openid={$openid}&openappid=101089751&apn=1";
$data2 = '{
  "SyncFlag" : 0,
  "Cookie" : "08acf7e6b50510acf7e6b50518b48ea0d00b20cea7b5d409288a9696800530cf9f03388ae2d3f30540a3f5034881faae9e0f58b6a5b3b405"
}';
$results2 = get_curl($url2,$data2);
$json = json_decode($results2,true);
if($json['ActionStatus'] == "OK"){
exit("<script>alert('一键卡BMW宝马在线成功！');history.go(-1);</script>");
}else{
$error_msg = $json['ActionStatus'];
exit("<script>alert('$error_msg');history.go(-1);</script>");
}
