<?php
require_once('includes/common.php');
if($_POST['do']=='find'){
	session_start();
	$user=safestr($_POST['user']);
	$aqanswer=safestr($_POST['aqanswer']);
	$pwd=md5(md5(safestr($_POST['pwd'])).md5('1340176819'));
	$code=safestr($_POST['code']);
	if(!$code || strtolower($_SESSION['tgyd_code'])!=strtolower($code)){
		exit("<script language='javascript'>alert('验证码错误');history.go(-1);</script>");
	}elseif($db->get_row("select * from {$prefix}users where aqanswer='{$aqanswer}' and user='{$user}' limit 1")){
		if ($db->query("update {$prefix}users set pwd='{$pwd}' where user='{$user}'")) {
			exit("<script language='javascript'>alert('密码修改成功');window.location.href='find.php';</script>");
		}else{
			exit("<script language='javascript'>alert('密码修改失败,请联系网站客服');window.location.href='find.php';</script>");
		}
	}else{
	 exit("<script language='javascript'>alert('验证安全信息失败');window.location.href='find.php';</script>");
	}
}elseif($_POST['do']=='finds'){
$user=safestr($_POST['user']);
if($row=$db->get_row("select * from {$prefix}users where user='$user' limit 1")){
$aqproblem=$row[aqproblem];
		}else{
exit("<script language='javascript'>alert('该用户不存在');window.location.href='find.php';</script>");
}
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <title><?=C("webname")?> - 用户登录</title>
    
    <!--[if lt IE 8]>
    <meta http-equiv="refresh" content="0;ie.html" />
    <![endif]-->
    
	<link href="/style/user/css/bootstrap.min.css?v=3.4.0" rel="stylesheet">
    <link href="/style/user/font-awesome/css/font-awesome.css?v=4.3.0" rel="stylesheet">
    <link href="/style/user/css/animate.css" rel="stylesheet">
    <link href="/style/user/css/style.css?v=2.2.0" rel="stylesheet">
	
</head>
<body class="gray-bg">

    <div class="middle-box" align="center">

                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        账号登陆
                                    </div>
                                    <div class="panel-body">
            <h3><?=C("webname")?></h3>
           <form action="?" method="post" class="form-signin">
		   <input type="hidden" name="do" value="find">
		   <input type="hidden" name="user" value="<?=$user?>">
			<div class="form-group">
                    <input type="text" name="aqproblem" class="form-control" value="密保问题:<?=$aqproblem?>" readonly>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="pwd" placeholder="请输入新密码" required="">
                </div>
				<div class="form-group">
                    <input type="text" class="form-control" name="aqanswer" placeholder="请输入密保答案" required="">
                </div>
				<div class="form-group">
                    <input type="text" name="code" class="form-control" style="width: 210px;display:-webkit-inline-box;" placeholder="请输入5位验证码" required>&nbsp;
					<img title="点击刷新" src="/other/code.php" onclick="this.src='/other/code.php?'+Math.random();" class="img-rounded">
                </div>
				
                <button type="submit" class="btn btn-primary block full-width">验证密保</button>
            </form>
			<hr/>
			<a class="btn btn-success btn-rounded btn-block" href="/reg.php"><i class="fa fa-male"></i> 还没有账号? - 立即注册</a><a class="btn btn-info btn-rounded btn-block" href="/find.php"><i class="fa fa-mail-reply-all"></i> 密码忘记了? - 立即找回</a>
                                    </div>
                                </div>
        </div>
    <script src="/style/user/js/jquery.min.js?v=2.1.1"></script>
    <script src="/style/user/js/bootstrap.min.js?v=3.4.0"></script>
</body>

</html>
<?php
}
else{

?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <title><?=C("webname")?> - 密码找回</title>
    
    <!--[if lt IE 8]>
    <meta http-equiv="refresh" content="0;ie.html" />
    <![endif]-->
    
	<link href="/style/user/css/bootstrap.min.css?v=3.4.0" rel="stylesheet">
    <link href="/style/user/font-awesome/css/font-awesome.css?v=4.3.0" rel="stylesheet">
    <link href="/style/user/css/animate.css" rel="stylesheet">
    <link href="/style/user/css/style.css?v=2.2.0" rel="stylesheet">
	
</head>
<body class="gray-bg">

    <div class="middle-box" align="center">

                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        账号登陆
                                    </div>
                                    <div class="panel-body">
            <h3><?=C("webname")?></h3>
           <form action="?" method="post" class="form-signin">
<input type="hidden" name="do" value="finds">
			<div class="form-group">
                    <input type="text" class="form-control" name="user" placeholder="请输入用户账号" required="">
                </div>
                <button type="submit" class="btn btn-primary block full-width">确定</button>
            </form>
			<hr/>
			<a class="btn btn-success btn-rounded btn-block" href="/reg.php"><i class="fa fa-male"></i> 还没有账号? - 立即注册</a><a class="btn btn-info btn-rounded btn-block" href="/find.php"><i class="fa fa-mail-reply-all"></i> 密码忘记了? - 立即找回</a>
                                    </div>
                                </div>
        </div>
    <script src="/style/user/js/jquery.min.js?v=2.1.1"></script>
    <script src="/style/user/js/bootstrap.min.js?v=3.4.0"></script>
</body>

</html>
<?php } ?>