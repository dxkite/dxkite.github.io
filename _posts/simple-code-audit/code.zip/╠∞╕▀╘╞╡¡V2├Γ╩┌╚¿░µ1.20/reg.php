<?php
require_once('includes/common.php');
if($_POST['do']=='reg'){
	session_start();
	$user=safestr($_POST['user']);
	$qq=safestr($_POST['qq']);
	$pwd=safestr($_POST['pwd']);
	$code=safestr($_POST['code']);
	$ip=getip();
	if(strlen($user) < 5){
		exit("<script language='javascript'>alert('用户名太短');history.go(-1);</script>");
	}elseif(!$code || strtolower($_SESSION['tgyd_code'])!=strtolower($code)){
		exit("<script language='javascript'>alert('验证码错误');history.go(-1);</script>");
	}elseif(strlen($pwd) < 5){
		exit("<script language='javascript'>alert('密码太简单！');history.go(-1);</script>");
	}elseif($db->get_row("select uid from {$prefix}users where qq='{$qq}' limit 1")){
		exit("<script language='javascript'>alert('此QQ已经注册过');history.go(-1);</script>");
	}elseif($db->get_row("select uid from {$prefix}users where user='{$user}' limit 1")){
		exit("<script language='javascript'>alert('用户名已存在！');history.go(-1);</script>");
	}else{
		$_SESSION['tgyd_code'] =md5(rand(100,500).time());
		$sid=md5(uniqid().rand(1,1000));
		$pwd=md5(md5($pwd).md5('1340176819'));
		$now=date("Y-m-d H:i:s");
		$city=get_ip_city($ip);
		$active=1;
		$peie=C('regpeie');
		$rmb=C('regrmb');
		if ($db->query("insert into  {$prefix}users (user,pwd,sid,active,peie,rmb,qq,city,regip,lastip,regtime,lasttime,aqproblem,aqanswer,yq) values ('$user','$pwd','$sid','$active','$peie','$rmb','$qq','$city','$ip','$ip','$now','$now','','','0')")) {
			exit("<script language='javascript'>alert('注册成功,点击确定跳转登陆');window.location.href='/login.php';</script>");
		}else{
			exit("<script language='javascript'>alert('注册失败');history.go(-1);</script>");
		}
	}
}
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <title><?=C("webname")?> - 用户注册</title>
    
    <!--[if lt IE 8]>
    <meta http-equiv="refresh" content="0;ie.html" />
    <![endif]-->
    
	<link href="/style/user/css/bootstrap.min.css?v=3.4.0" rel="stylesheet">
    <link href="/style/user/font-awesome/css/font-awesome.css?v=4.3.0" rel="stylesheet">
    <link href="/style/user/css/animate.css" rel="stylesheet">
    <link href="/style/user/css/style.css?v=2.2.0" rel="stylesheet">
	
</head>
<body class="gray-bg">

    <div class="middle-box" align="center">

                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        账号注册
                                    </div>
                                    <div class="panel-body">
            <h3><?=C("webname")?></h3>
           <form action="?" method="post" class="form-signin">
		   <input type="hidden" name="do" value="reg">
			<div class="form-group">
                    <input type="text" class="form-control" name="user" placeholder="请输入用户账号" required="">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="pwd" placeholder="请输入用户密码" required="">
                </div>
				<div class="form-group">
                    <input type="text" class="form-control" name="qq" placeholder="请输入您的QQ账号" required="">
                </div>
				<div class="form-group">
                    <input type="text" name="code" class="form-control" style="width: 210px;display:-webkit-inline-box;" placeholder="请输入5位验证码" required>&nbsp;
					<img title="点击刷新" src="/other/code.php" onclick="this.src='/other/code.php?'+Math.random();" class="img-rounded">
                </div>
                <button type="submit" class="btn btn-primary block full-width">马上注册</button>
            </form>
			<hr/>
			<a class="btn btn-success btn-rounded btn-block" href="/login.php"><i class="fa fa-male"></i> 已有账号? - 立即登陆</a>
                                    </div>
                                </div>
        </div>
    <script src="/style/user/js/jquery.min.js?v=2.1.1"></script>
    <script src="/style/user/js/bootstrap.min.js?v=3.4.0"></script>
</body>

</html>