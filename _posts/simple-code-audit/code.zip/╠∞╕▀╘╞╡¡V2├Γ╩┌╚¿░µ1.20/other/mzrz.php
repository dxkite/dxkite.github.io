<?php
error_reporting(0);
date_default_timezone_set('PRC');
require_once('../includes/common.php');
header ( "Content-type:text/html;charset=utf-8" );
if (empty ( $_GET ["uin"] )) { // 判断是否包含参数
	$qq='10000';
}else{
	$qq = $_GET ["uin"];
}
$result=mysql_query("select qq from {$prefix}qqs order by rand() limit 6");
$result2=mysql_query("select qq from {$prefix}qqs where qq='$qq' and iszan>0 limit 1");

while($rs = mysql_fetch_assoc($result)){
         $arr[] = $rs;
}

// print_r($arr);exit;

// 获取查询结果
$row = mysql_num_rows ( $result2 );
// echo $row;exit;
// if ($row != 1) { // 判断是否含有用户
	                 // // exit ( '没有该用户' );
// }
// 释放资源
// mysql_free_result ( $result );
// 关闭连接
// mysql_close ( $conn );
$time = date('Y-m-d H:i',time());
// 获取QQ昵称
$str = file_get_contents ( 'http://feeds.qzone.qq.com/cgi-bin/cgi_rss_out?uin=' . $qq );

/*
 * 以下是取中间文本的函数 getSubstr=调用名称 $str=预取全文本 $leftStr=左边文本 $rightStr=右边文本
 */
function getQQNickname($str, $leftStr, $rightStr) {
	$left = strpos ( $str, $leftStr );
	// echo '左边:'.$left;
	$right = strpos ( $str, $rightStr, $left );
	// echo '<br>右边:'.$right;
	if ($left < 0 or $right < $left)
		return '';
	return substr ( $str, $left + strlen ( $leftStr ), $right - $left - strlen ( $leftStr ) );
}
// echo getQQNickname($str,'[CDATA[',']]></title>');

if(preg_match("/^\d*$/",$qq)){ //过滤字符
} 
else {
//echo('也是6');
exit;}
?>

<!--界面来自:小玖月-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
	    <title>QQ:<?php echo "$qq" ?>的秒赞认证页面 - <?=C('webname')?></title>

	<link rel="stylesheet" type="text/css" href="/style/user/style.css" />
	<link rel="stylesheet" type="text/css" href="http://www.bootcss.com/p/buttons/css/buttons.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="http://cdn.bootcss.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="description" content="QQ秒赞网认证，提供认证查询，轻松辨别好友是否正在离线秒赞" />
	<meta name="keywords" content="QQ秒赞,离线秒赞,免费秒赞,QQ秒赞网" />
	</head>

<body>
<div id="page">
	<header>
		<img src="http://q1.qlogo.cn/g?b=qq&nk=<?php echo $qq ?>&s=240" id="head" alt="Dimpurr" title="<?php
							$str=getQQNickname ( $str, '[CDATA[', ']]></title>' );
								if(strstr($str,'gb2312')){
									echo 'Not Found！';
								}else{
									echo $str;
								}
							?>" itemprop="photo" />
	
		<h1 id="name"><?php
							$str=getQQNickname ( $str, '[CDATA[', ']]></title>' );
								if(strstr($str,'gb2312')){
									echo 'Not Found！';
								}else{
									echo $str;
								}
							?></h1>
		<h2 id="info" itemprop="organization"><?=C('webname')?></h2>
	
		<section id="tag">
		<?php
							if ($row==0) {
								echo "<p itemprop="title">目前没有在本网站开启离线秒赞功能，此次秒赞认证不通过。<br /><br />查询时间：$time</p>";
							} else {
								echo "<p itemprop="title">已在[".C('webname')."]提交了托管服务，可进行24小时不间断说说秒赞！<br /><br />查询时间：$time<br /></p>";
							}
							?>
		  <p itemprop="title"></p>
		</section>
	</header>
	<section id="hidetext">
	
		<div id="aboutdiv" itemprop="description">
			<p><span itemprop="gender"></span></p>
	
		</div>
		
  </section>
	<button class="button button-primary button-circle button-giant button-longshadow">
    <i class="fa fa-gear"></i>
  </button>
	<ul class="nav navbar-nav">
                        <button class="button button-large button-plain button-border button-circle"><i class="fa fa-reply"></i></button>
						<button class="button button-large button-plain button-border button-circle"><i class="fa fa-refresh"></i></button>
						<button class="button button-large button-plain button-border button-circle"><i class="fa fa-thumbs-up"></i></button>
                    </ul>
              

	<section id="textdiv"></section>
	
	<section id="hidetext">
	
		<div id="aboutdiv" itemprop="description">
			<p><span itemprop="gender"></span></p>
	
		</div>
		
  </section>
<!--禁音muted = value-->
</div>
<!--BGM开始-->
<embed src="http://sc.111ttt.com/up/mp3/5060/973D42EA0271C8E4A1E9421D9AD2890E.mp3" width=0 height=0>
</body>
</html>