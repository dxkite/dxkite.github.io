<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="RichSunfire">
    <link rel="shortcut icon" href="Template/2014/img/favicon.ico">
    <title><?=C('webtitle')?> - <?=C('webname')?> - <?=C('webkey')?></title>
    <!-- Bootstrap core CSS -->
	<link href="/style/user/css/bootstrap.min.css?v=3.4.0" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Morris -->
    <link href="/style/user/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
    <!-- Gritter -->
	<link href="/style/user/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="/style/user/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">
    <link href="/style/user/css/animate.css" rel="stylesheet">
    <link href="/style/user/css/style.css?v=2.2.0" rel="stylesheet">
  </head>

<body id="body">
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation" style="position:fixed;top:0;left:0;">
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
							<span><img alt="image" class="img-circle" src="http://q1.qlogo.cn/g?b=qq&nk=<?=$userrow[qq]?>&s=160" style="width:60px;" /></span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?=$userrow[user]?></strong></span>
							<span class="text-muted text-xs block"><?php if(get_isvip($userrow[vip],$userrow[vipend])){ echo "VIP用户";}else{echo"免费用户";}?> UID：<?=$userrow[uid]?><b class="caret"></b></span> </span>
                            </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="uset.php">个人资料</a></li>
								<li><a href="uset.php">修改密码</a></li>
                                <li><a href="shop.php">开通VIP</a></li>
                                <li class="divider"></li>
                                <li><a href="logout.php">安全退出</a></li>
                            </ul>
                        </div>
                    </li>
                    <li <?php if(C('pageid')=='user'){ echo'class="active"';}?>>
                        <a href="/mgmt"><i class="fa fa-home"></i> <span class="nav-label">用户中心</span></a>
                    </li>
					<?php if($userrow[active]==9){echo'<li>
                      <a href="/admin">
                          <i class="fa fa-cogs" style="width:20px;"></i>
                          <span>后台管理</span>
                      </a>
                  </li>';}?>
				  <?php if($userrow[daili]){echo'<li>
                      <a href="daili.php">
                          <i class="fa fa-globe" style="width:20px;"></i>
                          <span>代理专区</span>
                      </a>
                  </li>';}?>
			<?php if($userrow[fuzhan]){echo'<li>
                      <a href="/deputy">
                          <i class="fa fa-th" style="width:20px;"></i>
                          <span>副站专区</span>
                      </a>
                  </li>';}?>				
                    <li <?php if(C('pageid')=='qq' or C('pageid')=='add' or C('pageids')=='qid' or C('pageid')=='qqset'){ echo'class="active"';}?>>
                        <a href="javascript:;"><i class="fa fa-qq"></i> <span class="nav-label">QQ列表</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
						<?php if($rows=$db->get_results("select * from {$prefix}qqs where uid='$userrow[uid]' order by qid desc")){ foreach($rows as $row){?>
					<li <?php if(C('pageid')=='qid'.$row[qid]){ echo'class="active"';}?>><a href="qqlist.php?qid=<?=$row[qid]?>"># <?=$row[qq]?><?php if($row[skeyzt]){echo'<span class="label label-danger pull-right">失效</span>';}else{echo'<span class="label label-success pull-right">正常</span>';}?></a></li> 
					<?php }}?>
					<a class="btn btn-success btn-rounded btn-block" href="add.php">添加QQ</a>
						</ul>
                    </li>
					<li <?php if(C('pageid')=='shop' or C('pageid')=='rmb'){ echo'class="active"';}?>>
                        <a href="#"><i class="fa fa-shopping-cart"></i> <span class="nav-label">自助购买</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li <?php if(C('pageid')=='shop'){ echo'class="active"';}?>><a href="shop.php">余额购买</a></li>
                            <li <?php if(C('pageid')=='rmb'){ echo'class="active"';}?>><a href="rmb.php">会员开通</a></li>
                        </ul>
                    </li>
					<li <?php if(C('pageid')=='uset' or C('pageid')=='uindex'){ echo'class="active"';}?>>
                      <a href="javascript:;" >
                          <i class="fa fa-gift"></i>
                          <span>用户资料</span>
						  <span class="fa arrow"></span>
                      </a>
                      <ul class="nav nav-second-level">
                        <li <?php if(C('pageid')=='uset'){ echo'class="active"';}?> ><a href="uset.php">资料修改</a></li>
						<li <?php if(C('pageid')=='uindex'){ echo'class="active"';}?> ><a href="uindex.php?uid=<?=$userrow[uid]?>">我的主页</a></li>
                      </ul>
                  </li>
				  <li <?php if(C('pageid')=='daigua'){ echo'class="active"';}?>>
                        <a href="javascript:;" target="_blank"><i class="fa fa-cloud"></i> <span class="nav-label">QQ等级加速</span><span class="fa arrow"></span></a>
					<ul class="nav nav-second-level">
                        <li><a href="daigua.php">代挂列表</a></li>
						<li><a href="daigua.php?se=add">添加代挂</a></li>
                      </ul>
					</li>
					<li <?php if(C('pageid')=='qd' or C('pageid')=='reginfo' or C('pageid')=='mzlist'){ echo'class="active"';}?>>
                        <a href="#"><i class="fa fa-briefcase"></i> <span class="nav-label">其他功能</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
						<li <?php if(C('pageid')=='qd'){ echo'class="active"';}?>><a href="qd.php">每日签到</a></li>
						    <li <?php if(C('pageid')=='reginfo'){ echo'class="active"';}?>><a href="reginfo.php">邀请好友</a></li>
                            <li <?php if(C('pageid')=='mzlist'){ echo'class="active"';}?>><a href="mzlist.php">QQ秒赞墙</a></li>
                        </ul>
                    </li>
					<li>
                        <a href="logout.php" onClick="if(!confirm('确认退出登录吗？')){return false;}"><i class="fa fa-sign-out"></i> <span class="nav-label">注销登录</span></a>
                    </li>
                </ul>

            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " ><i class="fa fa-bars"></i></a>
                    </div>
                    <ul class="nav navbar-top-links navbar-right">
						<li>
                            <a href="/mgmt" title="返回首页"><i class="fa fa-home"></i>首页</a>
                        </li>
                        <li>
                            <a href="qq.php" title="QQ列表"><i class="fa fa-qq"></i>QQ管理</a>
                        </li>
						<li>
                        <a href="logout.php" onClick="if(!confirm('确认退出登录吗？')){return false;}"><i class="fa fa-sign-out"></i> <span class="nav-label">注销登录</span></a>
						</li>
                    </ul>
					
                </nav>
            </div>
		
<!-- end -->