<?php
require_once('common.php');
C('webtitle','邀请注册');
C('pageid','reginfo');
include_once 'core.head.php';
$dates=date('Y-m-d');
if($_POST['do']=='reg'){
if(get_isvip($userrow[vip],$userrow[vipend])){
	exit("<script language='javascript'>alert('您已是VIP会员,VIP用户无法参与本活动');history.go(-1);</script>");
}else{
	$num=get_count('reg',"uid='".$userrow[uid]."'",'id');
	if ($num > 4) {
				if ($userrow['vip']!=1) {
					$vipend = date('Y-m-d', strtotime('+ 3 day', strtotime($userrow['vipend'])));
					@mysql_query("update {$prefix}users set vipend='$vipend' where uid='".$userrow[uid]."'");
				} else {
					$vipstart = date('Y-m-d');
					$vipend = date('Y-m-d', strtotime('+ 3 day'));
					@mysql_query("update {$prefix}users set vip='1',vipstart='$vipstart',vipend='$vipend' where uid='".$userrow[uid]."'");
				}
				exit("<script language='javascript'>alert('恭喜本次获得VIP3日体验');history.go(-1);</script>");
	} else {
				exit("<script language='javascript'>alert('您今日的任务尚未完成,暂不能领取当然奖励哦！');history.go(-1);</script>");
	}
}
}
?>
<div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>邀请注册</h2>
            <ol class="breadcrumb">
                <li> <a href="/mgmt">主页</a>
                </li>
                <li> <strong>邀请注册</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-xs-12 col-md-6">
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <h3 class="panel-title">邀请提示</h3>
                    </div>
                    <div class="list-group-item reed">
                        <p>当天通过推广地址邀请达到<kbd>5人</kbd>注册后点击下方按钮可领取<kbd>3天</kbd>的VIP时长，被邀请好友也将获得3天VIP，每天可领取一次！</p>
						<?php
						if(get_isvip($userrow[vip],$userrow[vipend])){
							echo '<p>系统检测到您已是VIP用户,强行邀请无法领取该奖励！</p>';
						}
						?>
                        <hr/>
                        <p><code>您的专属推广地址：</code>
                        </p>
                        <p class="bg-info" style="padding: 10px;"><a href="http://<?=$domain?>/mgmt/reg.php?uid=<?=$userrow[uid]?>" target="_blank">http://<?=$domain?>/mgmt/reg.php?uid=<?=$userrow[uid]?></a>
                        </p>
                        <p>把以上链接发给您的好友、朋友圈、QQ群、贴吧邀请网友进行注册登陆使用，您将可以从中获得奖励！</p>
                        <p>被邀请注册的好友也会获取<kbd>3天</kbd>的VIP体验资格！</p>
                        <p>请让被推荐人注册帐号时在<code>邀请人</code>栏中填写您的UID号：<kbd style="font-size: 100%;"><?=$userrow[uid]?></kbd></p>
						<p><code>一经发现作弊,号码将拉入黑名单,请大家请勿作出任何作弊行为！</code></p>
						<p>注意：后台全程记录，恶意刷邀请量将作封号处理，希望大家都能遵守一下，谢谢！</p>
                    </div>
                </div>
				<div class="panel panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title">邀请推广</h3>
                    </div>
                    <div class="list-group-item list-group-item-warning"><span class="red"></span>
                    </div>
                    <div class="list-group-item list-group-item-success">
                        <form action="?" method="post">
                            <div class="formrow">
                                <input type="hidden" name="do" value="reg">
                                <input type="submit" name="submit" value="领取奖励" class="btn btn btn-block btn-success">
                            </div>
                        </form>
                        <hr/>
                        <p>推广注册记录：</p>
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td align="center"><span style="color:silver;"><b>UID</b></span>
                                    </td>
                                    <td align="center"><span style="color:silver;"><b>注册IP</b></span>
                                    </td>
                                    <td align="center"><span style="color:silver;"><b>注册时间</b></span>
                                    </td>
                                </tr>
								<?php if($rows=$db->get_results("select reguid,addtime,regip from {$prefix}reg where uid='".$userrow[uid]."' and addtime='$dates' order by uid desc limit 10")){ foreach($rows as $row){?>
                                <tr>
                                        <td align="center"><?=$row['reguid']?></td>
                                        <td align="center"><?=$row['regip']?></td>
                                        <td align="center"><?=$row['addtime']?></td>
                                </tr>
								<?php }}?>
								</tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title">邀请推广</h3>
                    </div>
                    <div class="list-group-item"> <span class="glyphicon glyphicon-th" aria-hidden="true">已邀请人数:<font color="green" size="3"><?=$userrow[yq]?></font></span>
                    <span class="glyphicon glyphicon-th" aria-hidden="true" style="margin-left:10px;">已获得VIP:<font color="green" size="3"><?=$userrow[yq]*3?>天</font></span>
					<span class="glyphicon glyphicon-th" aria-hidden="true" style="margin-left:10px;">系统实时记录已邀请人数:<font color="green" size="3"><?=get_count('reg',"uid='".$row[uid]."'",'id')?></font></span>
                    </div>
                    <div class="list-group-item list-group-item-success">
                    <p style=" text-align:center; color:#F36; font-size:20px; margin-top:15px;">★推广达人排行榜前20★</p>
					<?php if($rows=$db->get_results("select * from {$prefix}users where 1 order by yq desc limit 20")){ foreach($rows as $row){?>
					<?php $i=$i+1?>
                      <div class="list-group-item list-group-item-warning">
                	<span class="badge">邀请人数：<?=$row[yq]?>人</span>
                    <span class="glyphicon glyphicon-user" aria-hidden="true">&nbsp;排名<font color="#FF0000"><b><span style="font-size:14px; margin-left:3px;"><?=$i?></span></b></font>&nbsp;<?=$row[user]?></span>
                </div>
				<?php }}?>
				
				</div>
                </div>

            </div>
        </div>
    </div>
	  <?php
include_once 'core.foot.php';
?>