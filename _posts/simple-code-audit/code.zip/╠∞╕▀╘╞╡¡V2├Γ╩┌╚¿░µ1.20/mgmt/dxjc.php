<?php
session_start();
require_once('common.php');
//************************执行代码开始*************************
$qid=is_numeric($_GET['qid'])?$_GET['qid']:'0';
if(!$qid || !$qqrow=$db->get_row("select * from {$prefix}qqs where qid='$qid' and uid='$userrow[uid]' limit 1")){
	exit("<script language='javascript'>alert('QQ不存在！');window.location.href='/control';</script>");
}
$GTK=getGTK($qqrow['skey']);
$url = "http://m.qzone.com/friend/mfriend_list?g_tk=".$GTK."&res_uin=".$qqrow['qq']."&res_type=normal&format=json&count_per_page=10&page_index=0&page_type=0&mayknowuin=&qqmailstat=";
$json=get_curl($url,0,1,'pt2gguin=o0'.$qqrow['qq'].'; uin=o0'.$qqrow['qq'].'; skey='.$qqrow['skey'].';');
$arr=json_decode($json,true);
if($arr['code']==-3000){
	exit('<script language=\'javascript\'>alert(\'SID已过期\');history.go(-1);</script>');
}
$dxrow=$_SESSION['tgyd_dxrow']["$qqrow[qq]"];
$arr=$arr['data']['list'];


//**************************执行代码开始*******************************

C('webtitle','QQ'.$qqrow['qq'].'单项好友检测');
C('pageid','dxjc');
include_once 'core.head.php';
?>
<script src="http://libs.baidu.com/jquery/2.0.0/jquery.min.js"></script>
<script>
$(document).ready(function() {
	$('#startcheck').click(function(){
		self=$(this);
		if (self.attr("data-lock") === "true") return;
			else self.attr("data-lock", "true");
		$('#load').html('检测中<img src="/style/user/images/load.gif" height=25>');
		var url="/api/dx.php";
		xiha.postData(url,'uin=<?=$qqrow['qq']?>&skey=<?=$qqrow['skey']?>', function(d) {
			if(d.code ==0){
				$('#load').html('这一组检测完成，3秒后进行下一组，请稍等！');
				$('#count').html(d.count);
				$('#dxcount').html(d.dxcount);
				if(d.dxrow){
					$.each(d.dxrow, function(i, item){
						$("#content").append('<tr><td><input name="uins" type="checkbox" class="uins" id="uins" value="'+item.uin+'">'+item.uin+'</td><td>'+item.nick+'</td><td>'+item.remark+'</td><td align="center"><button class="btn btn-large btn-block qqdel del'+item.uin+'" uin="'+item.uin+'">删除</button></td></tr>'); 
					});  
				}
				if(d.finish==1){
					$('#load').html('好友全部检测完毕！');
				}else{
					 setTimeout(function () {
						$('#startcheck').click()
					 }, 3000);
					//$('#startcheck').click();
				}
			}else{
				alert(d.msg);
			}
				});
		self.attr("data-lock", "false");
	});
	$(document).on("click",".qqdel",function(){
		var checkself=$(this),
			touin=checkself.attr('uin');
		checkself.html('<Iframe src="/api/qqdel.php?uin=<?=$qqrow['qq']?>&skey=<?=$qqrow['skey']?>&p_skey=<?=$qqrow['p_skey']?>&touin='+touin+'" width="50px" height="30px" scrolling="no" frameborder="0"></iframe>');
	});
	$('.alldel').click(function(){
		var uin;
		$("input[name=uins]").each(function(){
			if($(this)[0].checked){
				uin=$(this).val();
				$('.del'+uin).html('<Iframe src="/api/qqdel.php?uin=<?=$qqrow['qq']?>&skey=<?=$qqrow['skey']?>&p_skey=<?=$qqrow['p_skey']?>&touin='+uin+'" width="50px" height="30px" scrolling="no" frameborder="0"></iframe>');
			}
		});
	});
});
var xiha={
	postData: function(url, parameter, callback, dataType, ajaxType) {
		if(!dataType) dataType='json';
		$.ajax({
			type: "POST",
			url: url,
			async: true,
			dataType: dataType,
			json: "callback",
			data: parameter,
			success: function(data) {
				if (callback == null) {
					return;
				} 
				callback(data);
			},
			error: function(error) {
				alert('创建连接失败');
			}
		});
	}
}
</script>
<block name="head">
	<script src="/Style/bootstrap/js/jquery.min.js"></script>
	<script src="/Style/bootstrap/js/bootstrap.min.js"></script>
	<script src="/Style/js/default.js"></script>
<script type="text/javascript">
function SelectAll(chkAll) {
	var items = $('.uins');
	for (i = 0; i < items.length; i++) {
		if (items[i].id.indexOf("uins") != -1) {
			if (items[i].type == "checkbox") {
				items[i].checked = chkAll.checked;
			}
		}
	}
}
$(document).ready(function(){
	$('#startcheck').click(function(){
		self=$(this);
		if (self.attr("data-lock") === "true") return;
			else self.attr("data-lock", "true");
		self.html('检测中<img src="/style/user/images/load.gif" style="height: 15px;">');
		var url="/api/dx.php";
		xiha.postData(url,'uin=<?=$qqrow['qq']?>&skey=<?=$qqrow['skey']?>', function(d) {
			if(d.code ==0){
				self.html('这一组检测完成，3秒后进行下一组，请稍等！');
				$('#count').html(d.count);
				$('#dxcount').html(d.dxcount);
				if(d.dxrow){
					$.each(d.dxrow, function(i, item){
						$("#content").append('<tr><td><input name="uins" type="checkbox" class="uins" id="uins" value="'+item.uin+'">'+item.uin+'</td><td>'+item.nick+'</td><td>'+item.remark+'</td><td align="center"><button class="btn btn-large btn-block qqdel del'+item.uin+'" uin="'+item.uin+'">删除</button></td></tr>'); 
					});  
				}
				if(d.finish==1){
					self.html('好友全部检测完毕！');
				}else{
					 setTimeout(function () {
						$('#startcheck').click()
					 }, 3000);
					//$('#startcheck').click();
				}
			}else{
				alert(d.msg);
			}
				});
		self.attr("data-lock", "false");
	});
	$(document).on("click",".qqdel",function(){
		var checkself=$(this),
			touin=checkself.attr('uin');
		checkself.html('<Iframe src="/api/qqdel.php?uin=<?=$qqrow['qq']?>&skey=<?=$qqrow['skey']?>&p_skey=<?=$qqrow['p_skey']?>&touin='+touin+'" width="50px" height="30px" scrolling="no" frameborder="0"></iframe>');
	});
	$('.alldel').click(function(){
		var uin;
		$("input[name=uins]").each(function(){
			if($(this)[0].checked){
				uin=$(this).val();
				$('.del'+uin).html('<Iframe src="/api/qqdel.php?uin=<?=$qqrow['qq']?>&skey=<?=$qqrow['skey']?>&p_skey=<?=$qqrow['p_skey']?>&touin='+uin+'" width="50px" height="30px" scrolling="no" frameborder="0"></iframe>');
			}
		});
	});
});
</script>
 <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>单向好友检测</h2>
            <ol class="breadcrumb">
                <li>
                    <a href="/mgmt">主页</a>
                </li>
				<li>
                    <a href="qqlist.php?qid=<?=$qqrow['qid']?>">QQ配置</a>
                </li>
                <li>
                    <strong>其他功能</strong>
                </li>
            </ol>
        </div>
    </div>

<div class="wrapper wrapper-content">
	<div class="row">
	    <div class="col-md-8">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title" align="center">提示</h3>
        </div>
        <div class="panel-body" align="left">
          <p>1、本功能展示的结果仅作参考，具体以实际数据为准</p>
          <p>2、新添加的QQ好友可能会被误判为单向好友</p>
          <p>3、该功能需要大量运算,手机使用会卡顿,可使用电脑进行检测</p>
        </div>
      </div>
    </div>
	<div class="col-md-8">
            <div class="panel panel-primary checkbtn">
	<div class="panel-body w h">
		<center><span class="btn btn-large btn-success" id="startcheck">点此开始单项检测</span>&nbsp;<br/>
        <table class="table table-bordered box" style="margin-top:20px;">
        <tbody>
        <tr>
		<td align="center"><span id="load" class="biank tanchu" style="color: #CF2525;">等待检测</span></center></td>
        <tr><td colspan="4" align="center">总共<span id="hyall"><?=count($arr)?><span>个好友,其中<span id="hydx"><?=count($dxrow)?></span>个单项，已检测<span id="hydel"><?=count($_SESSION["o".$qqrow[qq]])?></span>个！</td></tr>            </tbody>
	</table>
	</div>
</div>

		<div class="panel panel-info">
			<div class="panel-collapse collapse in">
				<div class="panel-body">
					<table class="table  table-bordered" style="table-layout: fixed;">
					<tbody id="content">
					<tr><td align="center"><input type="checkbox" onclick="SelectAll(this)" />全选</td><td class="mzwidthtd" align="center"">昵称</td><td class="mzwidthtd" align="center">备注</td><td align="center">删除</td></tr>
					<?php
				if($dxrow){
				foreach($dxrow as $k=>$row){
					if(stripos($json,"uin\":".$row[uin])){
					echo"<tr><td><label><input name='uins' type='checkbox' class='uins' id='uins' value='{$row[uin]}'>{$row[uin]}</label></td><td class='mztd'>{$row[nick]}</td><td class='mztd'>{$row[remark]}</td><td align='center'><button class='btn btn-large btn-block qqdel del{$row[uin]}' uin='{$row[uin]}'>删除</button></td></tr>";
					}else{
					unset($_SESSION['tgyd_dxrow']["$qqrow[qq]"][$k-1]);
					}
				}	
				}	
				?>
					</tbody>
					</table>
				</div>
			</div>
		</div>
		<div class="panel panel-info">
			<div class="panel-title">
				<div class="panel-title">
					<div class="input-group">
						<div class="input-group-addon btn">全选<input type="checkbox" onclick="SelectAll(this)" /></div>
						<div class="input-group-addon btn alldel">删除选择好友</div>

					</div>
				</div>
			</div>
		</div>
		
	</div>
</div>
</div>
              <!-- page end-->

	<script src="/style/user/assets/jquery-knob/js/jquery.knob.js"></script>
</section>
      </section>
	  <?php
include_once 'core.foot.php';
?>
  </section>