<?php
require_once('common.php');
C('webtitle','QQ秒赞墙');
C('pageid','mzlist');
include_once 'core.head.php';
?>
      <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>QQ秒赞墙</h2>
            <ol class="breadcrumb">
                <li> <a href="/mgmt">主页</a>
                </li>
                <li> <strong>其他功能</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>
    <style type="text/css">
        .table-bordered > thead > tr > th, .table-bordered > thead > tr > td {
    line-height: 30px;
}
    </style>
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">秒赞墙提示</h3>
                </div>
				<div class="panel-body" align="left">
					<p>本页面展示最近更新SKEY的100个秒赞QQ号</p>
					<p>提示：手机用户点击按钮无效请手动复制QQ号进行添加好友~</p>
				</div>
            </div>
        </div>


        <div class="col-xs-12">
            <div>
                <div class='tab-content'>
                    <div class='tab-pane active' id='tab'>
                        <table class="table table-bordered panel">
                            <tbody>
                                <tr>
								<td width="10%" align="center"><span style="color:silver;"><b>头像</b></span>
                                    </td>
                                    <td width="10%" align="center"><span style="color:silver;"><b>QQ</b></span>
                                    </td>
                                    <td width="15%" align="center"><span style="color:silver;"><b>状态</b></span>
                                    </td>
                                    <td width="10%" align="center"><span style="color:silver;"><b>操作</b></span>
                                    </td>
                                </tr>
								<?php if($rows=$db->get_results("select * from {$prefix}qqs where iszan=1 or iszan=2 order by qid desc limit 100")){ foreach($rows as $row){?>
					<tr>
                                                <td align="center"><img alt="image" class="img-circle" src="http://q1.qlogo.cn/g?b=qq&nk=<?=$row[qq]?>&s=160" style="width:60px;" /></td>
                                                <td align="center"><?=$row[qq]?></td>
												<td align="center">模式:<?php if($row[iszan]==1) echo '[CP]';?><?php if($row[iszan]==2) echo '[PC]';?> time:<?=$row[addtime]?></td>
												<td align="center"><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?=$row[qq]?>&site=&menu=yes" class="btn btn-block btn-primary"><i class="fa fa-plus"></i> 加为好友</a>
                                                </td>
                                    </tr><tr>
				<?php }}?>
                                
                                      </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
	  <?php
include_once 'core.foot.php';
?>