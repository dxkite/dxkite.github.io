<?php
/*QQ彩票图标点亮
*Author:龙魂
*/
date_default_timezone_set('PRC');
header("Content-type:text/html;charset=utf-8");
error_reporting(0);
function get_curl($url, $post=0, $referer=0, $cookie=0, $header=0, $ua=0, $nobaody=0)
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	if ($post) {
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	}
	if ($header) {
		curl_setopt($ch, CURLOPT_HEADER, true);
	}
	if ($cookie) {
		curl_setopt($ch, CURLOPT_COOKIE, $cookie);
	}
	if ($referer) {
		curl_setopt($ch, CURLOPT_REFERER, $referer);
	}
	if ($ua) {
		curl_setopt($ch, CURLOPT_USERAGENT, $ua);
	}
	else {
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0");
	}
	if ($nobaody) {
		curl_setopt($ch, CURLOPT_NOBODY, 1);
	}
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$ret = curl_exec($ch);
	curl_close($ch);
	return $ret;
}
$cookie='';
$uin=$_GET['qq'];
$sid=$_GET['sid'];
$qid=$_GET['qid'];
$url = "http://ebook.3g.qq.com/user/v3/normalLevel/recieveMonthGifts?sid=" . $sid . "&g_ut=1";
$rs=get_curl($url);
				if(strstr($rs,"领取成功") or strstr($rs,"您本月已经领取过礼包")){
					$rs2=get_curl("http://ebook.3g.qq.com/user/usecard?sid=" . $sid . "&g_ut=2");
					if (strstr($rs2, '使用成功')){
						echo "<script>alert('图书VIP领取成功');window.location.href='/mgmt/qqlist.php?qid=$qid';</script>";
					}elseif (strstr($rs2, '本月已经领取')) {
						echo "<script>alert('图书VIP领取失败,原因：本月您已领取过');window.location.href='/mgmt/qqlist.php?qid=$qid';</script>";
					}elseif (strstr($rs2, '您已经是包月VIP')) {
						echo "<script>alert('您已拥有图书VIP 不能领取');window.location.href='/mgmt/qqlist.php?qid=$qid';</script>";
					}else{
						echo "<script>alert('图书VIP领取失败,原因：0');window.location.href='/mgmt/qqlist.php?qid=$qid';</script>";
					}
				}else{
						echo "<script>alert('图书VIP领取失败,原因：本月您已领取过');window.location.href='/mgmt/qqlist.php?qid=$qid';</script>";
				}
?>