<?php
//  卡密链接：http://www.917ka.com/list/qFzc
require_once('common.php');
C('pageid','daigua');
C('webtitle','代挂列表');
include_once 'core.head.php';
function getkey($len=16){
	$str ='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	$strlen = strlen($str);
	$randstr = '';
	for ($n = 0; $i<$len; $i++){
		$randstr .= $str[mt_rand(0, $strlen-1)];
	}
	return $randstr;
}
if(!file_exists('key.php')){
	$key="<?php
function keys(){
	return '".getkey()."';
}
";
	if(!file_put_contents('key.php',$key)){//生成的KEY文件要妥善保存，这文件丢失所有用户添加的QQ都看不到了
		exit('<script language=\'javascript\'>alert(\'初始化失败，请检查网站是否有写入权限！\');history.go(-1);</script>');
	}
}
$hera='http://www.917ka.com/list/qFzc';//购卡链接，参数可以放到数据库去
include_once "key.php";
$key=keys();//KEY为网站识别参数，每个网站必须是唯一的
$data2=get_curl('http://api.52daigua.com/api/gg.php?buid=1.3');
$arrl=json_decode($data2,true);
$buid=$arrl['buid'];
$gg=$arrl['gg'];
$uid=$userrow['uid'];
$times = date('Y-m-d H:i:s');
$times2 = date('Y-m-d');
if($_GET['se']=='qq'){
	$qq=is_numeric($_GET['qq'])?$_GET['qq']:'0';
	$data=get_curl('http://api.52daigua.com/api/tgapi.php?do=getqq&key='.$key.'&uid='.$uid.'&uin='.$qq);
	$arr=json_decode($data,true);
	if($arr['code']==1) {
		$dew=explode(',',$arr['data']);
		$bgtime=$arr['bgtime'];
	}elseif(array_key_exists('msg',$arr)){
		exit ("<script> alert('".$arr['msg']."');history.go(-1); </script>");
	}else{
		exit ("<script> alert('".$data."');history.go(-1); </script>");
	}
	if($_GET['xz']){
		$datas=get_curl('http://api.52daigua.com/api/tgapi.php?do=update&key='.$key.'&uid='.$uid.'&uin='.$qq.'&xz='.$_GET['xz']);
		$arrs=json_decode($datas,true);
		if($arrs['code']==1) {
			$dew=explode(',',$arrs['data']);
			if(array_key_exists('bgtime',$arrs)) $bgtime=$arrs['bgtime'];
		}elseif(array_key_exists('msg',$arrs)){
			exit ("<script> alert('".$arrs['msg']."');history.go(-1); </script>");
		}else{
			exit ("<script> alert('".$datas."');history.go(-1); </script>");
		}
	}
}
if($_POST['do']=='add'){
	if(!$_POST['qq']) echo "<script> alert('你还没有输入QQ号！');history.go(-1); </script>";
	if(!$_POST['pwd']) echo "<script> alert('你还没有输入密码！');history.go(-1); </script>";
	if(!$_POST['km']) echo "<script> alert('你还没有输入卡密！');history.go(-1); </script>";
	$data=get_curl('http://api.52daigua.com/api/tgapi.php?do=add&key='.$key.'&uid='.$uid.'&uin='.$_POST['qq'].'&pwd='.$_POST['pwd'].'&km='.$_POST['km']);
	$arr=json_decode($data,true);
	if($arr['code']==1) {
		$msg=$arr['msg'].'<strong><a href="?se=qq&qq='.$arr['qq'].'" >点此进入设置</a></strong>';
	}elseif(array_key_exists('msg',$arr)){
		$msg=$arr['msg'];
	}else{
		$msg=$data;
	}
}elseif($_GET['se']=='xu' || $_GET['se']=='gm'){
	$qq=is_numeric($_GET['qq'])?$_GET['qq']:'0';
	if($_POST['do']=='xadd'){
		if($_GET['se']=='xu'){
			if(!$_POST['km']) echo "<script> alert('你还没有输入卡密！');history.go(-1); </script>";
		}elseif($_GET['se']=='gm'){
			if(!$_POST['pwd']) echo "<script> alert('你还没有输入密码！');history.go(-1); </script>";
		}
		$data=get_curl('http://api.52daigua.com/api/tgapi.php?do='.$_GET['se'].'&key='.$key.'&uid='.$uid.'&uin='.$qq.'&km='.$_POST['km'].'&pwd='.$_POST['pwd']);
		$arr=json_decode($data,true);
		if($arr['code']==1) {
			$msg=$arr['msg'].'<strong><a href="?se=qq&qq='.$arr['qq'].'" >点此进入设置</a></strong>';
		}elseif(array_key_exists('msg',$arr)){
			$msg=$arr['msg'];
		}else{
			$msg=$data;
		}
	}
}
?>
<div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>代挂设置</h2>
            <ol class="breadcrumb">
                <li><a href="/mgmt">主页</a>
                </li>
                <li><a href="#">我的代挂</a>
                </li>
                <li><strong>代挂列表</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
    <div class="modal inmodal fade" id="myModal5" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title">代挂提示</h4>
                </div>
                <div class="modal-body">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion" href="#1">
                            <h4 class="panel-title">
                            问：代挂里包含了哪些项目？
                            </h4>
                            </a>
                        </div>
                        <div id="1" class="panel-collapse collapse">
                            <div class="panel-body">
                                答：<br />
                                &nbsp;&nbsp;包含手机QQ在线每天加速1.0天<br />
                                &nbsp;&nbsp;电脑QQ在线每天加速0.5天<br />
                                &nbsp;&nbsp;非隐身在线2小时每天加速0.2天<br />
                                &nbsp;&nbsp;点亮QQ勋章墙每天加速0.2天<br />
                                &nbsp;&nbsp;QQ音乐听歌每天加速0.5天<br />
                                &nbsp;&nbsp;QQ钱包每天签到加速0.2天<br />
                                &nbsp;&nbsp;管家在线30分钟每天加速1.0天<br />
                                &nbsp;&nbsp;QQ手机游戏中心每天加速0.2天<br />
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion" href="#2">
                            <h4 class="panel-title">
                            问：代挂项目的登陆时间？
                            </h4>
                            </a>
                        </div>
                        <div id="2" class="panel-collapse collapse">
                            <div class="panel-body">
                                答：本站代挂每天定时登陆两次，凌晨0点后执行第一次登陆操作，登陆所有功能进行代挂，若出现登陆保护/帐号冻结/密码错误或其他错误，会在晚上的20点后进行第二次重试。（第二次重试不包含手机QQ在线，当天添加的QQ也是在晚上20点进行挂机任务）
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion" href="#3">
                            <h4 class="panel-title">
                            问：帐号状态出现非正常状态怎么办？
                            </h4>
                            </a>
                        </div>
                        <div id="3" class="panel-collapse collapse">
                            <div class="panel-body">
                                答：当帐号的状态被系统改为非正常状态时，将不会运行代挂任务，请在解决对应问题后，在本站更新一次QQ密码即可恢复正常状态！
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion" href="#4">
                            <h4 class="panel-title">
                            问：提交代挂后，提示异地登陆/异常操作冻结帐号，怎么回事？
                            </h4>
                            </a>
                        </div>
                        <div id="4" class="panel-collapse collapse">
                            <div class="panel-body">
                                答：因为你QQ的登陆地区与我们的代挂服务器地区不一致，导致出现异地登陆，腾讯方面为了保护你 的帐号会出现以上提示，冻结后修改密码即可，建议大家在QQ安全中心里的登陆记录中“确认本人登陆”，这样挂出常用地点后就不会有这样的提示了。
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion" href="#5">
                            <h4 class="panel-title">
                            问：被提示帐号有被盗风险，发送恶意信息或广告，能给个解释吗？
                            </h4>
                            </a>
                        </div>
                        <div id="5" class="panel-collapse collapse">
                            <div class="panel-body">
                                答：这是安全中心的默认提示，实际上是不存在这个问题的，QQ帐号都有漫游聊天记录，可以自己查证一下，放心即可！密码本站绝不会泄漏，也不会去盗取你的帐号！
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion" href="#6">
                            <h4 class="panel-title">
                            问：在哪里关闭登陆保护，设备锁等？
                            </h4>
                            </a>
                        </div>
                        <div id="6" class="panel-collapse collapse">
                            <div class="panel-body">
                                答：登陆 <a href="https://aq.qq.com/cn2/safe_service/device_lock" target="_blank">https://aq.qq.com/cn2/safe_service/device_lock</a> 这个页面，即可关闭所有的登陆保护，确保正常代挂不受影响。
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion" href="#7">
                            <h4 class="panel-title">
                            问：提交代挂需要注意一些什么问题吗？
                            </h4>
                            </a>
                        </div>
                        <div id="7" class="panel-collapse collapse">
                            <div class="panel-body">
                                答：首先，请将您宝贵的帐号绑定上各种密保，开启QB消费验证，以免代挂期间产生不必要的误会，毕竟有些用户的素质很低，反咬一口污蔑本站也说不清，所以提交代挂即代表您自愿将帐号交给我们进行托管代挂，并同意本站协议。
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion" href="#9">
                            <h4 class="panel-title">
                            问：代挂每天能加速多少？
                            </h4>
                            </a>
                        </div>
                        <div id="9" class="panel-collapse collapse">
                            <div class="panel-body">
                                答：非会员每天固定加速3.8天，QQ会员用户根据会员加速倍数计算公式为：会员加速倍数×1.7+2.1 ，例如SVIP8级加速是3.0倍的计算为3×1.7+2.1=7.2天。
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion" href="#10">
                            <h4 class="panel-title">
                            问：为什么我添加了代挂却没有给我挂呢？
                            </h4>
                            </a>
                        </div>
                        <div id="10" class="panel-collapse collapse">
                            <div class="panel-body">
                                答：代挂前两三天由于异地登录容易冻结QQ，这样就让一些项目漏挂了，当天解冻后会给予补挂。如果QQ没有被冻结过，却没有任何一个项目加速的就是你密码给错了，基本密码错误的都会在状态中显示出来，但不排除个别QQ状态更新不及时还显示正常的情况，因此出现上述情况更新下你的密码即可，请确保密码是正确的！
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a data-toggle="collapse" data-parent="#accordion" href="#11">
                            <h4 class="panel-title">
                            问：为什么电脑QQ或勋章墙总是没挂呢？
                            </h4>
                            </a>
                        </div>
                        <div id="11" class="panel-collapse collapse">
                            <div class="panel-body">
                                答：勋章墙的登录类型与电脑QQ一样，受登录保护影响，目前平台QQ状态中不提示登录保护，登陆 <a href="https://aq.qq.com/cn2/safe_service/device_lock" target="_blank">https://aq.qq.com/cn2/safe_service/device_lock</a> 这个页面，关闭登录保护即可正常代挂！
                            </div>
                        </div>
                    </div>
                </div>
  
                <div class="modal-footer">
                    <button type="button" class="btn btn-white" data-dismiss="modal">关闭</button>
                </div>
            </div>
        </div>
    </div>
	<div class="wrapper wrapper-content animated fadeInRight">
		<div class="container">
			<div class="row">
			    <div class="col-md-12" style="margin-bottom:20px;">
                    <div class="ibox-content">
					<a href="daigua.php" class="btn btn-warning" style="margin:5px;">代挂列表</a>
				        <a href="?se=add" class="btn btn-primary" style="margin:5px;">添加代挂</a>
                        <button type="button" id="ssss" class="btn btn-primary" data-toggle="modal" data-target="#myModal5">代挂说明</button>      
                    </div>
                </div>
				<?php if($gg){?>
				<div class="col-md-12">
					<div class="alert alert-danger">
						<?=$gg?>
					</div>
				</div>
				<?php }
				if($_GET['se']=='xu'){?>
				<div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>代挂续费</h5><a href="<?=$hera?>" class="pull-right btn btn-success btn-xs">购买卡密</a>
                        </div>
                        <div class="ibox-content">
                            <form action="?se=xu&qq=<?=$qq?>" role="form" class="form-horizontal" method="post">
                            <input type="hidden" name="do" value="xadd">
                            <?php if($msg){echo '<div class="list-group-item red" style="color:#F36">'.$msg.'</div>';
								}else{ echo '
                                <div class="list-group-item red" style="color:#F36">
                                    你正在为QQ:'.$qq.'进行续费操作，请输入新的代挂卡密。
                                </div>';}?>
                                <div class="list-group-item">
                                    <div class="input-group">
                                        <div class="input-group-addon">输入卡密</div>
                                        <input type="text" class="form-control" name="km" id="km" placeholder="请输入代挂卡密" value="">
                                    </div>
                                </div>
                                
                                <div class="list-group-item">
                                    <input type="submit" name="submit" value="确定" class="btn btn-primary btn-block">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
				<?php }elseif($_GET['se']=='gm'){ ?>
				<div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>更新密码</h5>
                        </div>
                        <div class="ibox-content">
                            <form action="?se=gm&qq=<?=$qq?>" role="form" class="form-horizontal" method="post" name="form2">
                            <input type="hidden" name="do" value="xadd">
                                <?php if($msg){echo '<div class="list-group-item red" style="color:#F36">'.$msg.'</div>';
								}else{ echo '
                                <div class="list-group-item red" style="color:#F36">
                                    你正在为QQ:'.$qq.'更新密码，请输入你的新密码。
                                </div>';}?>
                                <div class="list-group-item">
                                    <div class="input-group">
                                        <div class="input-group-addon">密&nbsp;&nbsp;码</div>
                                        <input type="text" class="form-control" name="pwd" id="pwd" placeholder="输入QQ密码" value="">
                                    </div>
                                </div>
                                
                                <div class="list-group-item">
                                    <input type="button" name="Submit"  onclick="adds();"  value="确定更新" class="btn btn-primary btn-block">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
				<?php }elseif($_GET['se']=='add'){ ?>
				<div class="col-md-12">
					<div class="panel panel-primary">
						<div class="panel-heading">
							<h3 class="panel-title">添加QQ进行代挂</h3>
						</div>
						
						<div class="list-group-item"><a href="<?=$hera?>" class="pull-right btn btn-success btn-xs">购买卡密</a>
                        <?php if($msg) {echo'<span style="size:14px; color:#F36">&nbsp;'.$msg.'</span>';
						}else{ echo'<span style="size:14px; color:#F36">&nbsp;添加QQ后可进行详细设置，添加前请看上方的代挂说明，购买卡密请联系QQ:'.$config['webqq'].'</span>';}?>
						</div>
						<div class="list-group-item">
							<form name="form1" action="" method="POST" role="form">
							<input type="hidden" name="do" value="add">
							<div class="input-group" style="padding-bottom:15px;">
								<div class="input-group-addon">Q&nbsp;&nbsp;Q</div>
								<input type="text" class="form-control" name="qq" id="qq" placeholder="请输入QQ号" value="">
							</div>
							<div class="input-group" style="padding-bottom:15px;">
								<div class="input-group-addon">密&nbsp;&nbsp;码</div>
								<input type="password" class="form-control" name="pwd" id="pwd" placeholder="请输入QQ密码" value="">
							</div>
							<div class="input-group" style="padding-bottom:15px;">
								<div class="input-group-addon">代挂卡密</div>
								<input type="text" class="form-control" name="km" id="km" placeholder="请输入卡密" value="">
							</div>
							<input type="button" name="Submit" onclick="add();" value="添加代挂" class="btn btn-primary btn-block">
							</form>  
						</div>
					</div>
				</div>
				<?php }elseif($_GET['se']=='qq'){ ?>
                <div class="col-lg-4">
                    <div class="widget white-bg p-sm">
                        <div class="m-b-xs">
                            <h3 class="font-bold no-margins" style=" padding-bottom:12px;">提示！提示！提示！</h3>
                            <small>代挂时间：每天的凌晨统一登陆，下午4点后进行补挂一次（例如凌晨密码错误的），因异地登陆可能会导致QQ被冻结(从而加速失败)，可登陆<a href="http://aq.qq.com/007" target="_blank">aq.qq.com</a>进行解冻！</small>
                        </div>
                    </div>
                    <div class="widget blue-bg p-sm">
                        <div class="m-b-xs">
                            <h3 class="font-bold no-margins" style=" padding-bottom:12px;">温馨提醒：</h3>
                            <small>代挂期间修改了QQ的密码，记得来这里更新，否则登录不上无法代挂！！！</small>
                            <a class="btn btn-warning" href="?se=gm&qq=<?=$qq?>">点此更新密码</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="widget white-bg p-sm" style="overflow:hidden;">
                        <div class="m-b-xs">
                            <dl class="dl-horizontal">
                                <dt style="margin-top:-10px;"><img alt="image" class="img-circle m-t-xs" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$qq?>&spec=100" style="width:100px;"></dt>
                                <dd style="margin-left:110px; margin-top:10px;">
                                    <h3><strong># <?=$qq?></strong></h3>
                                    <h4><strong>状态：<?php if($arr['qqzt']==2){ echo '已过期&nbsp;&nbsp;<a class="btn btn-success btn-xs" href="?se=xu&qq='.$uin.'">续费</a>';}elseif($arr['qqzt']==3){ echo '密码错误';}else{ echo '正常';}?></strong></h4>
                                    <hr>
                                    添加时间:<?=$arr['addtime']?><br>
                                    到期时间:<?=$arr['endtime']?>
                                    <br/>
                                </dd>
                            </dl>
                        </div>
                        <div class="table-responsive">
                            <div class="tooltip-demo">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th width="20%" height="50px" valign="center">#</th>
                                            <th width="40%" valign="center">加速项目</th>
                                            <th valign="center">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th class="text-nowrap"><i class="fa fa-circle text-navy"></i></th>
                                            <td><strong data-toggle="tooltip" data-placement="top" title="登陆电脑管家代挂30分钟，领取1.0天成长值">电脑管家&nbsp;<i class="fa fa-question-circle"></i></strong></td>
                                            <td><a class="btn btn-block <?php if($dew[0]){echo 'btn-primary';}else{echo 'btn-danger';}?>" href="?se=qq&xz=gj&qq=<?=$qq?>"><?php if($dew[0]){echo '已开启';}else{echo '已关闭';}?></a></td>
                                        </tr>
                                        
                                        <tr>
                                            <th class="text-nowrap"><i class="fa fa-circle text-danger"></i></th>
                                            <td><strong data-toggle="tooltip" data-placement="top" title="登陆QQ音乐秒领0.5天成长值">QQ音乐&nbsp;<i class="fa fa-question-circle"></i></strong></td>
                                            <td><a class="btn btn-block <?php if($dew[1]){echo 'btn-primary';}else{echo 'btn-danger';}?>" href="?se=qq&xz=yy&qq=<?=$qq?>"><?php if($dew[1]){echo '已开启';}else{echo '已关闭';}?></a></td>
                                        </tr>
                                        
                                        <tr>
                                            <th class="text-nowrap"><i class="fa fa-circle text-primary"></i></th>
                                            <td><strong data-toggle="tooltip" data-placement="top" title="登陆PCQQ点亮勋章墙图标，领取0.2天成长值(会临时顶掉你的电脑QQ一次！)">勋章墙&nbsp;<i class="fa fa-question-circle"></i></strong></td>
                                            <td><a class="btn btn-block <?php if($dew[2]){echo 'btn-primary';}else{echo 'btn-danger';}?>" href="?se=qq&xz=xzq&qq=<?=$qq?>"><?php if($dew[2]){echo '已开启';}else{echo '已关闭';}?></a></td>
                                        </tr>
                                        
                                        <tr>
                                            <th class="text-nowrap"><i class="fa fa-circle text-info"></i></th>
                                            <td><strong data-toggle="tooltip" data-placement="top" title="登陆爱消除App进行签到，领取0.2天成长值(请提前在天天爱消除建好游戏角色！)">QQ手游&nbsp;<i class="fa fa-question-circle"></i></strong></td>
                                            <td><a class="btn btn-block <?php if($dew[3]){echo 'btn-primary';}else{echo 'btn-danger';}?>" href="?se=qq&xz=yx&qq=<?=$qq?>"><?php if($dew[3]){echo '已开启';}else{echo '已关闭';}?></a></td>
                                        </tr>
                                        
                                        <tr>
                                            <th class="text-nowrap"><i class="fa fa-circle text-warning"></i></th>
                                            <td><strong data-toggle="tooltip" data-placement="top" title="登陆QQ钱包进行签到，领取0.2天成长值">QQ钱包&nbsp;<i class="fa fa-question-circle"></i></strong></td>
                                            <td><a class="btn btn-block <?php if($dew[4]){echo 'btn-primary';}else{echo 'btn-danger';}?>" href="?se=qq&xz=qb&qq=<?=$qq?>"><?php if($dew[4]){echo '已开启';}else{echo '已关闭';}?></a></td>
                                        </tr>
                                        
                                        <tr>
                                            <th class="text-nowrap"><i class="fa fa-circle text-danger"></i></th>
                                            <td><strong data-toggle="tooltip" data-placement="top" title="每天0点登陆PcQQ进行登陆挂机2小时，领取0.5天成长值(会挤掉你自己的电脑QQ，介意者请勿开启！)">电脑QQ&nbsp;<i class="fa fa-question-circle"></i></strong></td>
                                            <td><a class="btn btn-block <?php if($dew[5]){echo 'btn-primary';}else{echo 'btn-danger';}?>" href="?se=qq&xz=pcqq&qq=<?=$qq?>"><?php if($dew[5]){echo '已开启';}else{echo '已关闭';}?></a></td>
                                        </tr>
                                        
                                        <tr>
                                            <th class="text-nowrap"><i class="fa fa-circle text-navy"></i></th>
                                            <td><strong data-toggle="tooltip" data-placement="top" title="每天0点登陆手机QQ6小时，领取1.0天成长值(会挤掉你自己的手机QQ，介意者请勿开启！)">手机QQ&nbsp;<i class="fa fa-question-circle"></i></strong></td>
                                            <td><a class="btn btn-block <?php if($dew[6]){echo 'btn-primary';}else{echo 'btn-danger';}?>" href="?se=qq&xz=mqq&qq=<?=$qq?>"><?php if($dew[6]){echo '已开启';}else{echo '已关闭';}?></a></td>
                                        </tr>
                                        <tr>
                                            <th colspan="2"><a class="btn btn-block btn-info" href="?se=qq&xz=bugua&qq=<?=$qq?>"><?php if($bgtime==date("Y-m-d")){ echo '已加入补挂列队';}else{ echo '点此申请补挂';} ?></a></th>
                                            <td><a class="btn btn-block btn-success" href="?se=xu&qq=<?=$qq?>">续费</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }else{?>
				<div class="col-md-4" style="margin:7px auto;">
                    <div class="ibox-content text-center">
                        <div class="m-b-sm">
                            <img alt="image" class="img-circle" src="//q4.qlogo.cn/headimg_dl?dst_uin=10000&spec=100" width="100" height="100">
                        </div>
                        <h2 class="text-success">虚拟占位</h2>
                        <h3 class="text-warning">点击下方按钮添加代挂QQ</h3>
                        <hr>
                        <div style="width:100%; height:3px;"></div>
                        <div class="text-center">
                            <a class="btn btn-w-m btn-info" href="?se=add">添加QQ</a>
                        </div>
                    </div>
                </div>	
				<?php 
					$data=get_curl("http://api.52daigua.com/api/tgapi.php?do=list&key=".$key."&uid=".$uid);
					$date=json_decode($data,true);
					$dates=$date['qqlist'];
					if($dates)foreach($dates as $arr){
					?>
                    <div class="col-md-4" style="margin:7px auto;">
                    <div class="ibox-content text-center">
                        <div class="m-b-sm">
                            <img alt="image" class="img-circle" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?=$arr['qq']?>&spec=100" width="100" height="100">
                        </div>
                        <h2 class="text-success"># <?=$arr['qq']?></h2>
                        <h3 class="text-warning">状态：<?php if($arr['qqzt']==2){ echo '已过期';}elseif($arr['qqzt']==3){ echo '密码错误';}else{ echo '正常';}?></h3>
                        <hr>
                        <div style="width:100%; height:3px;"></div>
                        <div class="text-center">
                            <a class="btn btn-outline btn-success" href="?se=gm&qq=<?=$arr['qq']?>">更新密码</a>
                            <a class="btn btn-outline btn-info" href="?se=xu&qq=<?=$arr['qq']?>">续费</a>
                            <a class="btn btn-outline btn-warning" href="?se=qq&qq=<?=$arr['qq']?>">设置</a>
                        </div>
                    </div>
                </div>
                <?php }
                }?>
	</div></div></div></div>
<script language="JavaScript">
function add(){
	var pwd= document.getElementById("pwd").value;
	var qq= document.getElementById("qq").value;
	var km= document.getElementById("km").value;
	if(!qq){
		alert("你还没有填QQ号码呢");
	}else if(!pwd){
		alert("你还没有填QQ密码呢");
	}else if(!km){
		alert("你还没有填写卡密呢");
	}else if (confirm("你确定密码是：" + pwd)){
		document.form1.submit()
	}
}
</script>
<script language="JavaScript">
function adds(){
	var pwd= document.getElementById("pwd").value;
	if(!pwd){
		alert("你还没有填QQ密码呢");
	}else if (confirm("你确定密码是：" + pwd)){
		document.form2.submit()
	}
}
</script>

 <?php
include_once 'core.foot.php';
?>