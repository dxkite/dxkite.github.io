<?php
require_once('common.php');
//************************执行代码开始*************************
$qid=is_numeric($_GET['qid'])?$_GET['qid']:'0';
$now=date("Y-m-d-H:i:s");
if($qid=='0'){
$rows=$db->get_results("select * from {$prefix}qqs where 1 order by qid desc limit 1");
foreach($rows as $row){
$qid=$row[qid];
}
}
if(!$qid || !$qqrow=$db->get_row("select * from {$prefix}qqs where qid='$qid' and uid='$userrow[uid]' limit 1")){
	exit("<script language='javascript'>alert('QQ不存在！');window.location.href='/mgmt';</script>");
}
if($_GET['do']=='change'){
	if(!C('webfree') && !get_isvip($userrow[vip],$userrow[vipend])){
		echo"<script language='javascript'>alert('对不起，你不是VIP,无法开启功能！');</script>";
	}else{
		$the=$_GET['the'];
		$is=is_numeric($_GET['is'])?$_GET['is']:'0';
			$db->query("update {$prefix}qqs set is{$the}='$is' where qid='$qid'");
			$qqrow=$db->get_row("select * from {$prefix}qqs where qid='$qid' and uid='$userrow[uid]' limit 1");
			$db->query("update {$prefix}qqs set next{$the}='$now' where qid='$qid'");
	}
}elseif($_GET['do']=='del'){
	$db->query("delete from {$prefix}qqs where qid='$qid'");
	exit("<script language='javascript'>alert('删除成功！');window.location.href='/mgmt';</script>");
}



//**************************执行代码开始*******************************

C('webtitle','QQ'.$qqrow['qq']);
C('pageid','qid'.$qqrow['qid']);
C('pageids','qid');
include_once 'core.head.php';
?>
<div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>QQ：<?=$qqrow['qq']?></h2>
            <ol class="breadcrumb">
                <li>
                    <a href="/mgmt">主页</a>
                </li>
                <li>
                    QQ列表
                </li>
				<li>
                    <strong>QQ配置</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2">
        </div>
    </div>
    <div class="wrapper wrapper-content">
        <div class="row animated fadeInRight">
            <div class="col-md-6">
                <div class="ibox float-e-margins">
                    <div>
                        <div class="ibox-content no-padding border-left-right" style="background: url(/style/user/img/profile_big.jpg);text-align: center;background-size: cover;">
                            <img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$qqrow['qq']?>&s=240" class="img-circle circle-border m-b-md" alt="QQ:<?=$qqrow['qq']?>的头像" style="margin-top: 20px;width: 150px;">
                        </div>
                        <div class="ibox-content profile-content">
                            <h4><strong># <?=$qqrow['qq']?></strong><span style="float:right;margin-top: -6px;"><a type="button" class="btn btn-danger" href="?do=del&p=<?=$p?>&qid=<?=$qqrow[qid]?>" onClick="if(!confirm('确认删除QQ：<?=$qqrow['qq']?>吗？')){return false;}">删除</a> <a href="add.php?uin=<?=$qqrow[qq]?>" type="button" class="btn btn-warning">更新</a></span></h4>
                            <hr/>
                            <p>SK码：<?php if($qqrow[skeyzt]){echo'<span class="red" aria-hidden="true">&nbsp;[过期请<a href="add.php?uin='.$qqorw[qq].'">更新</a>]</span>';}else{echo'<span class="green" aria-hidden="true">&nbsp;[正常]</span>';}?>
                             —— SD码：<?php if($qqrow[sidzt]){echo'<span class="red" aria-hidden="true">&nbsp;[过期请<a href="add.php?uin='.$qqorw[qq].'">更新</a>]</span>';}else{echo'<span class="green" aria-hidden="true">&nbsp;[正常]</span>';}?>                            </p>
							<p>以上状态码若有非正常的请及时更新防止功能失效！</p>
                            <h5>
                                    <hr/>
                                </h5>
                            <p>添加时间：<?=$qqrow['addtime']?></p>
                            <p>更多操作：<a class="btn btn-xs btn-primary" href="/other/mzrz.php?uin=<?=$qqrow['qq']?>" target="_blank">秒赞认证</a>&nbsp;|&nbsp;<a class="btn btn-xs btn-primary" href="/api/tbook.php?sid=<?=$qqrow['sid']?>" >领取图书VIP</a>&nbsp;|&nbsp;<a class="btn btn-xs btn-primary" href="http://kf.qq.com/touch/qzone/qzone_status.html" >空间异常查询</a>
							
                            </p>
                            <div class="user-button">
                                <div class="row">
                                    <div class="col-xs-6">
                                        <a href="dxjc.php?qid=<?=$qqrow['qid']?>" class="btn btn-success btn-sm btn-block"><i class="fa fa-users"></i> 单向好友检测</a>
                                    </div>
                                    <div class="col-xs-6">
                                        <a href="mzjc.php?qid=<?=$qqrow['qid']?>" class="btn btn-success btn-sm btn-block"><i class="fa fa-male"></i> 秒赞好友检测</a>
                                    </div>
                                    <div class="col-xs-6">
                                        <a href="daigua.php" target="_blank" class="btn btn-success btn-sm btn-block"><i class="fa fa-cloud"></i> QQ 等级代挂</a>
                                    </div>
									<div class="col-xs-6">
                                        <a href="group.php?qid=<?=$qqrow['qid']?>" class="btn btn-success btn-sm btn-block"><i class="fa fa-users"></i> 群成员提取</a>
                                    </div>
									<div class="col-xs-6">
                                        <a href="quanz.php?qid=<?=$qqrow['qid']?>&qq=<?=$qqrow['qq']?>" class="btn btn-success btn-sm btn-block"><i class="fa fa-circle"></i> 一键拉圈圈</a>
                                    </div>
									<div class="col-xs-6">
                                        <a href="/api/bmw.php?qid=<?=$qqrow['qid']?>&qq=<?=$qqrow['qq']?>&skey=<?=$qqrow['skey']?>" class="btn btn-success btn-sm btn-block"><i class="fa fa-circle"></i> 一键卡BMW宝马在线</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>已开启的功能</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                        </div>
                    </div>
					<div class="ibox-content">
                        <div>
                            <div class="feed-activity-list">
							<div class="feed-element"><a href="#" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isauto.png"></a><div class="media-body">
							<small class="pull-right"><a href="#" class="btn btn-success">已锁定</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="状态失效时自动更新功能将自动激活">自动更新 <i class="fa fa-question-circle"></i></strong> <img alt="image" src="/style/user/img/free.png" style="width: 30px;"><br>
							<small class="text-muted"><?php if(!$msg){echo zhtime($qqrow['lastauto']);}else{echo "[".zhtime($qqrow['lastauto'])."]".$msg;}?></small></div></div>
							<?php if(getzts($qqrow[iszan])){}else{ ?>
							<div class="feed-element"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=zan#zan" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/iszan.png"></a><div class="media-body">
							<small class="pull-right"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=zan#zan" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="为好友的说说点赞">说说秒赞 <i class="fa fa-question-circle"></i></strong> <img alt="image" src="/style/user/img/free.png" style="width: 30px;"><br>
							<small class="text-muted"><?=zhtime($qqrow['lastzan'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isreply])){}else{ ?>
							<div class="feed-element"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=reply#reply" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isreply.png">
							</a><div class="media-body"><small class="pull-right"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=reply#reply" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="评论好友的说说动态">说说秒评 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastreply'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[iszf])){}else{ ?>
							<div class="feed-element"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=zf#zf" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/iszf.png">
							</a><div class="media-body"><small class="pull-right"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=zf#zf" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="转发指定好友的说说">说说转发 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastzf'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqt])){}else{ ?>
							<div class="feed-element"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=qt#qt" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isqt.png">
							</a><div class="media-body"><small class="pull-right"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=qt#qt" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="在好友的图文说说中@自己">说说圈图 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqt'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isshuo])){}else{ ?>
							<div class="feed-element"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=shuo#shuo" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isshuo.png">
							</a><div class="media-body"><small class="pull-right"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=shuo#shuo" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="定时发随机或指定的说说">自动说说 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastshuo'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isdel])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=del&is=<?php if($qqrow['isdel']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdel.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=del&is=<?php if($qqrow['isdel']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="定时删除随机的说说">删除说说 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastdel'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isdell])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=dell&is=<?php if($qqrow['isdell']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdelly.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=dell&is=<?php if($qqrow['isdell']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="定时删除随机的留言">删除留言 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastdell'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isht])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=ht&is=<?php if($qqrow['isht']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isht.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=ht&is=<?php if($qqrow['isht']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="每日花藤浇花 可供空间等级加速">花藤浇花 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastht'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[islw])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=lw&is=<?php if($qqrow['islw']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/islw.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=lw&is=<?php if($qqrow['islw']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="空间互相送礼物">礼物互送 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastlw'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isly])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=ly&is=<?php if($qqrow['isly']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isly.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=ly&is=<?php if($qqrow['isly']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="空间互相留言">留言互刷 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastly'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isrq])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=rq&is=<?php if($qqrow['isrq']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isrq.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=rq&is=<?php if($qqrow['isrq']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="空间互相访问留痕">空间互访 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastrq'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[iszyzan])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=zyzan&is=<?php if($qqrow['iszyzan']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/iszyzan.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=zyzan&is=<?php if($qqrow['iszyzan']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ空间V8主页赞互刷">互赞主页 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastzyzan'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isvipqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=vipqd&is=<?php if($qqrow['isvipqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isvipqd.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=vipqd&is=<?php if($qqrow['isvipqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQVIP会员签到">会员签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastvipqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqb])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qb&is=<?php if($qqrow['isqb']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isqb.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qb&is=<?php if($qqrow['isqb']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ钱包签到助于QQ等级加速">钱包签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqb'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[ists])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=ts&is=<?php if($qqrow['ists']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/ists.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=ts&is=<?php if($qqrow['ists']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="图书3G签到">图书签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastts'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[islq])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=ts&is=<?php if($qqrow['islq']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/islz.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=lq&is=<?php if($qqrow['islq']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ绿钻签到">绿钻签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastlq'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isgameqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=gameqd&is=<?php if($qqrow['isgameqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/islz.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=gameqd&is=<?php if($qqrow['isgameqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ蓝钻签到">蓝钻签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastgameqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isnc])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=nc&is=<?php if($qqrow['isnc']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=nc&is=<?php if($qqrow['isnc']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ空间农场牧场签到">农牧签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastnc'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qd&is=<?php if($qqrow['isqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qd&is=<?php if($qqrow['isqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ空间签到">空间签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[ismqqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=mqqd&is=<?php if($qqrow['ismqqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=group&is=<?php if($qqrow['ismqqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="超级QQ签到">超Q签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastmqqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[iscwqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=cwqd&is=<?php if($qqrow['cwqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=cwqd&is=<?php if($qqrow['cwqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ宠物签到">宠物签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastcwqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[ishlwqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=hlwqd&is=<?php if($qqrow['hlwqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=hlwqd&is=<?php if($qqrow['hlwqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ好莱坞会员签到">好莱坞签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lasthlwqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isdldqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=dldqd&is=<?php if($qqrow['dldqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=dldqd&is=<?php if($qqrow['dldqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ大乐斗每日签到">大乐斗签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastdldqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isslqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=slqd&is=<?php if($qqrow['slqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=slqd&is=<?php if($qqrow['slqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="3366小游戏每日签到">3366签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastslqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[iswyqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=wyqd&is=<?php if($qqrow['wyqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=wyqd&is=<?php if($qqrow['wyqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ微云签到">微云签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastwyqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isgjqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=gjqd&is=<?php if($qqrow['gjqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=gjqd&is=<?php if($qqrow['gjqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ管家每日签到">管家签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastgjqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isyyqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=yyqd&is=<?php if($qqrow['yyqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=yyqd&is=<?php if($qqrow['yyqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ空间应用每日签到">应用签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastyyqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqlqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qlqd&is=<?php if($qqrow['qlqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qlqd&is=<?php if($qqrow['qlqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ空间情侣签到用于增加亲密度">情侣签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqlqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isblqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=blqdis=<?php if($qqrow['blqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=blqd&is=<?php if($qqrow['blqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ兴趣部落每日签到">部落签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastblqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isdtqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=dtqdis=<?php if($qqrow['dtqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=dtqd&is=<?php if($qqrow['dtqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ游戏大厅签到">大厅签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastdtqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqqllqqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qqllqqdis=<?php if($qqrow['qqllqqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qqllqqd&is=<?php if($qqrow['qqllqqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ浏览器积分每日签到">QQ浏览器积分签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqqllqqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qqd&is=<?php if($qqrow['isqqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isqunqd.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qqd&is=<?php if($qqrow['isqqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ用户群每日签到">Q群签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqwqd])){}else{ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qwqd&is=<?php if($qqrow['isqwqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isqunqd.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qwqd&is=<?php if($qqrow['isqwqd']){echo 0;}else{echo 2;}?>" class="btn btn-success">点击关闭</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ用户群群问问每日10点签到">群问签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqwqd'])?></small></div></div>
							<?php } ?>
                            </div>
                </div>
			</div>
		</div>
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>未开启的功能</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <div>
                            <div class="feed-activity-list">
							<?php if(getzts($qqrow[iszan])){ ?>
							<div class="feed-element"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=zan#zan" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/iszan.png"></a><div class="media-body">
							<small class="pull-right"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=zan#zan" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="为好友的说说点赞">说说秒赞 <i class="fa fa-question-circle"></i></strong> <img alt="image" src="/style/user/img/free.png" style="width: 30px;"><br>
							<small class="text-muted"><?=zhtime($qqrow['lastzan'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isreply])){ ?>
							<div class="feed-element"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=reply#reply" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isreply.png">
							</a><div class="media-body"><small class="pull-right"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=reply#reply" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="评论好友的说说动态">说说秒评 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastreply'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[iszf])){ ?>
							<div class="feed-element"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=zf#zf" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/iszf.png">
							</a><div class="media-body"><small class="pull-right"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=zf#zf" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="转发指定好友的说说">说说转发 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastzf'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqt])){ ?>
							<div class="feed-element"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=qt#qt" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isqt.png">
							</a><div class="media-body"><small class="pull-right"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=qt#qt" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="在好友的图文说说中@自己">说说圈图 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqt'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isshuo])){ ?>
							<div class="feed-element"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=shuo#shuo" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isshuo.png">
							</a><div class="media-body"><small class="pull-right"><a href="qqset.php?qid=<?=$qqrow[qid]?>&xz=shuo#shuo" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="定时发随机或指定的说说">自动说说 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastshuo'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isdel])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=del&is=<?php if($qqrow['isdel']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdel.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=del&is=<?php if($qqrow['isdel']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="定时删除随机的说说">删除说说 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastdel'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isdell])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=dell&is=<?php if($qqrow['isdell']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdelly.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=dell&is=<?php if($qqrow['isdell']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="定时删除随机的留言">删除留言 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastdell'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isht])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=ht&is=<?php if($qqrow['isht']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isht.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=ht&is=<?php if($qqrow['isht']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="每日花藤浇花 可供空间等级加速">花藤浇花 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastht'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[islw])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=lw&is=<?php if($qqrow['islw']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/islw.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=lw&is=<?php if($qqrow['islw']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="空间互相送礼物">礼物互送 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastlw'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isly])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=ly&is=<?php if($qqrow['isly']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isly.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=ly&is=<?php if($qqrow['isly']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="空间互相留言">留言互刷 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastly'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isrq])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=rq&is=<?php if($qqrow['isrq']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isrq.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=rq&is=<?php if($qqrow['isrq']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="空间互相访问留痕">空间互访 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastrq'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[iszyzan])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=zyzan&is=<?php if($qqrow['iszyzan']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/iszyzan.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=zyzan&is=<?php if($qqrow['iszyzan']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ空间V8主页赞互刷">互赞主页 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastzyzan'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isvipqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=vipqd&is=<?php if($qqrow['isvipqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isvipqd.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=vipqd&is=<?php if($qqrow['isvipqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQVIP会员签到">会员签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastvipqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqb])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qb&is=<?php if($qqrow['isqb']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isqb.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qb&is=<?php if($qqrow['isqb']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ钱包签到助于QQ等级加速">钱包签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqb'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[ists])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=ts&is=<?php if($qqrow['ists']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/ists.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=ts&is=<?php if($qqrow['ists']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="图书3G签到">图书签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastts'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[islq])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=ts&is=<?php if($qqrow['islq']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/islz.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=lq&is=<?php if($qqrow['islq']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ绿钻签到">绿钻签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastlq'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isgameqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=gameqd&is=<?php if($qqrow['isgameqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/islz.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=gameqd&is=<?php if($qqrow['isgameqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ蓝钻签到">蓝钻签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastgameqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isnc])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=nc&is=<?php if($qqrow['isnc']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=nc&is=<?php if($qqrow['isnc']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ空间农场牧场签到">农牧签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastnc'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qd&is=<?php if($qqrow['isqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qd&is=<?php if($qqrow['isqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ空间签到">空间签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[ismqqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=mqqd&is=<?php if($qqrow['ismqqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=group&is=<?php if($qqrow['ismqqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="超级QQ签到">超Q签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastmqqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[iscwqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=cwqd&is=<?php if($qqrow['cwqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=cwqd&is=<?php if($qqrow['cwqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ宠物签到">宠物签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastcwqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[ishlwqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=hlwqd&is=<?php if($qqrow['hlwqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=hlwqd&is=<?php if($qqrow['hlwqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ好莱坞会员签到">好莱坞签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lasthlwqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isdldqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=dldqd&is=<?php if($qqrow['dldqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=dldqd&is=<?php if($qqrow['dldqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ大乐斗每日签到">大乐斗签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastdldqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isslqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=slqd&is=<?php if($qqrow['slqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=slqd&is=<?php if($qqrow['slqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="3366小游戏每日签到">3366签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastslqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[iswyqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=wyqd&is=<?php if($qqrow['wyqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=wyqd&is=<?php if($qqrow['wyqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ微云签到">微云签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastwyqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isgjqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=gjqd&is=<?php if($qqrow['gjqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=gjqd&is=<?php if($qqrow['gjqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ管家每日签到">管家签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastgjqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isyyqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=yyqd&is=<?php if($qqrow['yyqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=yyqd&is=<?php if($qqrow['yyqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ空间应用每日签到">应用签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastyyqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqlqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qlqd&is=<?php if($qqrow['qlqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qlqd&is=<?php if($qqrow['qlqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ空间情侣签到用于增加亲密度">情侣签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqlqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isblqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=blqdis=<?php if($qqrow['blqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=blqd&is=<?php if($qqrow['blqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ兴趣部落每日签到">部落签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastblqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isdtqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=dtqdis=<?php if($qqrow['dtqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=dtqd&is=<?php if($qqrow['dtqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ游戏大厅签到">大厅签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastdtqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqqllqqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qqllqqdis=<?php if($qqrow['qqllqqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isdld.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qqllqqd&is=<?php if($qqrow['qqllqqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ浏览器积分每日签到">QQ浏览器积分签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqqllqqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qqd&is=<?php if($qqrow['isqqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isqunqd.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qqd&is=<?php if($qqrow['isqqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ用户群每日签到">Q群签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqqd'])?></small></div></div>
							<?php } ?>
							<?php if(getzts($qqrow[isqwqd])){ ?>
							<div class="feed-element"><a href="?qid=<?=$qid?>&do=change&the=qwqd&is=<?php if($qqrow['isqwqd']){echo 0;}else{echo 2;}?>" class="pull-left"><img alt="image" class="img-circle" src="/style/user/img/isqunqd.png">
							</a><div class="media-body"><small class="pull-right"><a href="?qid=<?=$qid?>&do=change&the=qwqd&is=<?php if($qqrow['isqwqd']){echo 0;}else{echo 2;}?>" class="btn btn-danger">点击开启</a></small>
							<strong data-toggle="tooltip" data-placement="top" title="QQ用户群群问问每日10点签到">群问签到 <i class="fa fa-question-circle"></i></strong><br>
							<small class="text-muted"><?=zhtime($qqrow['lastqwqd'])?></small></div></div>
							<?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php
include_once 'core.foot.php';
?>