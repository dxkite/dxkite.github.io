<?php
// +------------------------PC 登录协议------------------------------------
// | Copyright (c) 2015 http://www.9i18.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: 云上的影子 && 龙魂
// +----------------------------------------------------------------------
// | QQ: 8711973
// +----------------------------------------------------------------------
// | 如需修改和引用，请保留此头部信息！

class Qqlogin {
	public $json;

	public function __construct($uin,$pwd,$code=0,$sig=0){
		$this->login_sig = $this->login_sig();
		$this->uin=$uin;
		$this->pwd=$pwd;
		$this->code=$code;
		$this->sig=$sig;
		
		if($code){
			$this->dovc();
		}else{
			$this->checkvc();
		}
	}
	public function login_sig(){
	
		$url="http://xui.ptlogin2.qq.com/cgi-bin/xlogin?proxy_url=http%3A//qzs.qq.com/qzone/v6/portal/proxy.html&daid=5&pt_qzone_sig=1&hide_title_bar=1&low_login=0&qlogin_auto_login=1&no_verifyimg=1&link_target=blank&appid=549000912&style=22&target=self&s_url=http%3A//qzs.qq.com/qzone/v5/loginsucc.html?para=izone&pt_qr_app=手机QQ空间&pt_qr_link=http%3A//z.qzone.com/download.html&self_regurl=http%3A//qzs.qq.com/qzone/v6/reg/index.html&pt_qr_help_link=http%3A//z.qzone.com/download.html";
		$ret = $this->get_curl($url,0,1,0,1);
		preg_match('/pt_login_sig=(.*?);/',$ret,$skey);
		return $skey[1];
	
	}
	public function getsid($url,$do=0){
		$do++;
		if($ret = $this->get_curl($url)){
			$ret = preg_replace('/([\x80-\xff]*)/i','',$ret);
			if(preg_match('/sid=(.{24})&/iU', $ret,$sid)){
				return $sid[1];
			}else{
				if($do<5){
					return $this->getsid3($url,$do);
				}else{
					$this->sidcode=2;
					return false;
				}
			}
		}else{
			$this->sidcode=1;
			return false;
		}
	}
	public function login(){
		if(strpos('s'.$this->code,'!')){
			$v1=0;
		}else{
			$v1=1;
		}
		$p=$this->getp();
		$url = "http://ptlogin2.qq.com/login?u=".$this->uin."&verifycode=".$this->code."&pt_vcode_v1=".$v1."&pt_verifysession_v1=".$this->sig."&p=".$p."&pt_randsalt=0&u1=http%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=4-6-1441545995792&js_ver=10132&js_type=1&login_sig=".$this->login_sig."&pt_uistyle=32&aid=549000912&daid=5&pt_qzone_sig=1&";
		$sidurl = 'http://ptlogin2.qzone.com/login?verifycode='.$this->code.'&u='.$this->uin.'&p='.$p.'&pt_randsalt=0&ptlang=2052&low_login_enable=0&u1=http%3A%2F%2Fsqq2.3g.qq.com%2Fhtml5%2Fsqq2vip%2Findex.jsp&from_ui=1&fp=loginerroralert&device=2&aid=549000912&pt_ttype=1&daid=147&pt_3rd_aid=0&ptredirect=1&h=1&g=1&pt_uistyle=9&pt_vcode_v1='.$v1.'&pt_verifysession_v1='.$this->sig.'&';

		$ret = $this->get_curl($url,0,0,0,1,0,0,1);
		$sidret = $this->get_curl($sidurl,0,0,0,1,"'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0");
		if(preg_match("/ptuiCB\('(.*?)'\);/", $ret, $arr) && preg_match("/ptuiCB\('(.*?)'\);/", $sidret, $sidarr)){
			$r=explode("','",str_replace("', '","','",$arr[1]));
			$sr=explode("','",str_replace("', '","','",$sidarr[1]));
			if($r[0]==0){
				$cookie='';
				preg_match_all('/Set-Cookie: (.*);/iU',$ret,$matchs);
				foreach ($matchs[1] as $val) {
					$cookie.=$val.'; ';
				}
				preg_match('/skey=@(.{9});/',$ret,$skey);
				preg_match('/ptsig=(.{44})/',$r[2],$ptsig);
				$p_skey=$this->get_pskey($ptsig[1],$cookie);
				$data=$this->get_curl($sr[2],0,0,0,1,"'Mozilla/5.0 (Linux; U; Android 4.0.4; es-mx; HTC_One_X Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0");
				if($data) {
					preg_match("/p_skey=(.*?);/", $data, $matchs);
					$p_skey2 = $matchs[1];
					preg_match("/Location: (.*?)\r\n/iU", $data, $matchs);
					$sid=$this->getsid($matchs[1]);
				}
				if($sid && $p_skey){
					$this->json='{"code":0,"uin":"'.$this->uin.'","sid":"'.$sid.'","skey":"@'.$skey[1].'","p_skey":"'.$p_skey.'","p_skey2":"'.$p_skey2.'","ptsig":"'.$ptsig[1].'"}';
				}else{
					$this->json='{"code":-1,"uin":"'.$this->uin.'","msg":"登录成功，获取对应信息失败！"}';
				}
			}elseif($r[0]==4){
				$this->json='{"code":-3,"msg":"验证码错误!"}';
				$this->checkvc();
			}elseif($r[0]==3){
				$this->json='{"code":-3,"msg":"密码错误！"}';
			}elseif($r[0]==19){
				$this->json='{"code":-3,"msg":"您的帐号暂时无法登录，请到 http://aq.qq.com/007 恢复正常使用！"}';
			}else{
				$this->json='{"code":-3,"msg":"'.str_replace('"','\'',$r[4]).'"}';
			}
		}else{
			$this->json='{"code":-3,"msg":"'.$ret.'"}';
		}
	}
	public function get_pskey($ptsig,$cookie){
		$url = "http://user.qzone.qq.com/".$this->uin."?ptsig=".$ptsig;
		$ret = $this->get_curl($url,0,0,$cookie,1);
		if(preg_match("/p_skey=(.*?);/", $ret, $arr)){
			$p_skey = $arr[1];
			return $p_skey;
		}else return false;
	}
	public function getp(){
		$url="http://qqapp.aliapp.com/?uin=".$this->uin."&pwd=".strtoupper($this->pwd)."&vcode=".strtoupper($this->code);
		$getp=$this->get_curl($url);
		if($getp){
			return $getp;
		}else{
			exit("<script language='javascript'>alert('获取P值失败，请稍候重试！');history.go(-1);</script>");
		}
	}
	public function dovc(){
		$url='http://captcha.qq.com/cap_union_verify?aid=549000912&uin='.$this->uin.'"&captype=2&ans='.$this->code.'&sig='.$this->sig.'&0.960725'.time();
		$data=$this->get_curl($url,0,1);
		if(preg_match("/cap\_InnerCBVerify\((.*?)\);/", $data, $json)){
			$json=str_replace(array('{',':',','),array('{"','":',',"'),$json[1]);
			$arr=json_decode($json,true);
			$randstr=$arr['randstr'];
			$sig=$arr['sig'];
		}
		if($randstr){
			$this->code=$randstr;
			$this->sig=$sig;
			$this->login();
		}else{
			$this->getvc($this->sig);
		}
	}
	public function checkvc(){
		$url='http://check.ptlogin2.qq.com/check?regmaster=&pt_tea=1&pt_vcode=1&uin='.$this->uin.'&appid=549000912&js_ver=10132&js_type=1&login_sig='.$this->login_sig.'&u1=http%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&r=0.3827968'.time();
		$data=$this->get_curl($url,0,1);
		if(preg_match("/ptui_checkVC\('(.*?)'\);/", $data, $arr)){
			$r=explode("','",$arr[1]);
			if($r[0]==1){
				$this->json='{"code":-2,"sig":"'.$r[1].'"}';
				$this->getvc($r[1]);
			}else{
				$this->code=$r[1];
				$this->sig=$r[3];
				$this->login();
			}
		}else{
			exit("<script language='javascript'>alert('判断是否有验证码失败，请稍候重试！');history.go(-1);</script>");
		}
	}
	
	public function getvc($sig){
		if(strlen($sig)==56){
			$url='http://captcha.qq.com/cap_union_show?captype=3&aid=549000912&uin='.$this->uin.'&cap_cd='.$sig.'&v=0.0672220'.time();
			$data=$this->get_curl($url);
			if(preg_match("/g\_click\_cap\_sig=\"(.*?)\";/", $data, $arr)){
				$this->json='{"code":-1,"sig":"'.$arr[1].'"}';
			}else{
				exit("<script language='javascript'>alert('获取验证码失败，请稍候重试！');history.go(-1);</script>");
			}
		}else{
			$url='http://captcha.qq.com/getQueSig?aid=549000912&uin='.$this->uin.'&captype=8&sig='.$sig.'&0.819966'.time();
			$data=$this->get_curl($url);
			if(preg_match("/cap_getCapBySig\(\"(.*?)\"\);/", $data, $arr)){
				$this->json='{"code":-1,"sig":"'.$arr[1].'"}';
			}else{
				exit("<script language='javascript'>alert('获取验证码失败，请稍候重试！');history.go(-1);</script>");
			}
		}
	}

	private function get_curl($url,$post=0,$referer=0,$cookie=0,$header=0,$ua=0,$nobaody=0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		$klsf[] = "Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"; 
		$klsf[] = "Accept-Encoding:gzip,deflate,sdch"; 
		$klsf[] = "Accept-Language:zh-CN,zh;q=0.8"; 
		$klsf[] = "Connection:close"; 
		curl_setopt($ch, CURLOPT_HTTPHEADER, $klsf);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			if($referer==1){
				curl_setopt($ch, CURLOPT_REFERER, "http://m.qzone.com/infocenter?g_f=");
			}else{
				curl_setopt($ch, CURLOPT_REFERER, $referer);
			}
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);
		}
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		return $ret;
	}

}