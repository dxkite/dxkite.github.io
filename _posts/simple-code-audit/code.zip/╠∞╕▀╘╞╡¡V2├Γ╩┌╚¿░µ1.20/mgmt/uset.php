<?php
$aq=1;
require_once('common.php');
//************************执行代码开始*************************
if($do=$_POST['do']){
	if($do=='update'){
		$qq=safestr($_POST['qq']);
		$aqproblem=safestr($_POST['aqproblem']);
		$aqanswer=safestr($_POST['aqanswer']);
		if($aqproblem=='' or $aqanswer=='')exit("<script language='javascript'>alert('安全问题不能为空！');history.go(-1);</script>");
		$set="qq='{$qq}',aqproblem='{$aqproblem}',aqanswer='{$aqanswer}'";
		if($_POST['pwd']){
			$pwd=md5(md5($_POST['pwd']).md5('1340176819'));
			$set.=",pwd='{$pwd}'";
		}
		if($db->get_row("select * from {$prefix}users where qq='{$qq}' and uid!='{$userrow['uid']}' limit 1")){
			echo"<script language='javascript'>alert('QQ号已存在！');history.go(-1);</script>";
		}else{
			$db->query("update {$prefix}users set {$set} where uid='{$userrow['uid']}'");
			echo"<script language='javascript'>alert('修改成功');history.go(-1);</script>";
		}
	}
}


//**************************执行代码开始*******************************

C('webtitle',$userrow[user].'-用户修改');
C('pageid','uset');
include_once 'core.head.php';

?>
<div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>资料修改</h2>
            <ol class="breadcrumb">
                <li> <a href="/mgmt">主页</a>
                </li>
                <li> <strong>用户资料</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
			<div class="col-lg-6">
                        <div class="widget-head-color-box navy-bg p-lg text-center">
                            <div class="m-b-md">
                                <h2 class="font-bold no-margins">
                                <?=$userrow['user']?>                            </h2>
                                <small></small>
                            </div>
                            <img src="http://q1.qlogo.cn/g?b=qq&nk=<?=$userrow[qq]?>&s=160" class="img-circle circle-border m-b-md" alt="profile">
                            <div>
                                <span><?php if(get_isvip($userrow[vip],$userrow[vipend])){ echo "VIP用户";}else{echo"免费用户";}?></span>
                            </div>
                        </div>
                        <div class="widget-text-box">
                            <p>* 剩余余额：<?=$userrow[peie]?>元</p>
                            <p>* 配额：已用<font color=green><?=get_count('qqs',"uid='$userrow[uid]'",'qid')?></font>个，共有<?=$userrow[peie]?>个</p>
                        </div>
            </div>
            <div class="col-lg-6">
                                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>资料修改</h5>
                    </div>
                    <div class="ibox-content">
                        <form action="?" role="form" class="form-horizontal" method="post">
						<input type="hidden" name="do" value="update">
                            <div class="form-group">
                                <label class="col-lg-3 control-label">UID：</label>
                                <div class="col-lg-8">
                                    <input type="text" class="form-control" value="<?=$userrow[uid]?>" disabled="disabled">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-3 control-label">用户名：</label>
                                <div class="col-lg-8">
                                    <input type="text" class="form-control" value="<?=$userrow[user]?>" disabled="disabled">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-3 control-label">绑定QQ：</label>
                                <div class="col-lg-8">
                                    <input type="text" class="form-control" maxlength="12" name="qq" value="<?=$userrow[qq]?>">	<span class="help-block m-b-none">所有信息都与此QQ进行绑定，填写后可显示对应头像以及用来找回密码，加入Vip售后群时将以此QQ号进行验证</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-3 control-label">新密码：</label>
                                <div class="col-lg-8">
                                    <input type="text" class="form-control" name="pwd" placeholder="不修改请留空">
                                </div>
                            </div>
							<div class="form-group">
									<label class="col-lg-3 control-label">密保问题：</label>
									<div class="col-lg-8">
										<input class="form-control" type="text" name="aqproblem" placeholder="此处必填" value="<?=$userrow[aqproblem]?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-3 control-label">密保答案：</label>
									<div class="col-lg-8">
										<input class="form-control" type="text" name="aqanswer" placeholder="此处必填" value="<?=$userrow[aqanswer]?>">
									</div>
								</div>
                            <div class="form-group">
                                <div class="col-lg-offset-3 col-lg-8">
                                    <button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit" name="submit" value="1">保存修改</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
	  <?php
include_once 'core.foot.php';
?>