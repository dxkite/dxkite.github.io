<?php
require_once('common.php');
C('webtitle','QQ列表');
C('pageid','qq');
include_once 'core.head.php';
$p=is_numeric($_GET['p'])?$_GET['p']:'1';
$pp=$p+8;
$pagesize=10;
$start=($p-1)*$pagesize;

if($_GET['do']=='search' && $s=safestr($_GET['s'])){
	$pagedo='seach';
	$qqs=$db->get_results("select * from {$prefix}qqs where qq='{$s}' or user like'%{$s}%' order by (case when qq='{$s}' then 8 else 0 end) desc limit 20");
}else{
	$pages=ceil(get_count('qqs','1=1','qid')/$pagesize);
	$qqs=$db->get_results("select * from {$prefix}qqs where uid=".$userrow[uid]." order by qid desc limit $start,$pagesize");
}
if($pp>$pages) $pp=$pages;
if($p==1){
	$prev=1;
}else{
	$prev=$p-1;
}
if($p==$pages){
	$next=$p;
}else{
	$next=$p+1;
}
?>
<div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>QQ管理</h2>
            <ol class="breadcrumb">
                <li> <a href="/mgmt">主页</a>
                </li>
                <li> <strong>QQ列表</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>
    <div class="wrapper wrapper-content  animated fadeInRight">
        <div class="row">
<div class="col-sm-12">
                <div class="ibox">
                    <div class="ibox-content">
                        <span class="text-muted small pull-right">最后更新：<i class="fa fa-clock-o"></i> <?=date('Y-m-d H:i:s')?></span>
                        <h2>QQ搜索</h2>
                        <div class="input-group">
                            <input type="text" placeholder="查找我的账号" class="input form-control">
                            <span class="input-group-btn">
                                        <button type="button" class="btn btn btn-primary"> <i class="fa fa-search"></i> 搜索</button>
                                </span>
                        </div>
                        <div class="clients-list">
                            <div class="tab-content">
                                <div id="tab" class="tab-pane active">
                                    <div class="full-height-scroll">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover">
                                                <tbody>
												<?php if($qqs){foreach($qqs as $qq){?>
				<tr>
					<td>qid:<?=$qq[qid]?></td>
					<td><?=$qq[qq]?></td>
					<td><?php if($qq[skeyzt]){echo"<font color='red'>状态失效</font>";}else{echo"<font color='green'>状态正常</font>";}?></td>
					<td><?=$qq[addtime]?></td>
					<td><a href="qqlist.php?do=del&p=<?=$p?>&qid=<?=$qq[qid]?>" class="btn btn-danger" onClick="if(!confirm('确认删除？')){return false;}">删除</a>&nbsp;<a href="qqlist.php?qid=<?=$qq[qid]?>" class="btn btn-success">管理</a></td>
				</tr>
				<?php }}?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
<div class="row" style="text-align:center;">
				<ul class="pagination pagination-lg">
					<li <?php if($p==1){echo'class="disabled"';}?>><a href="?p=1">首页</a></li>
					<li <?php if($prev==$p){echo'class="disabled"';}?>><a href="?p=<?=$prev?>"><i class="fa fa-chevron-left"></i></a></li>
					<?php for($i=$p;$i<=$pp;$i++){?>
					<li <?php if($i==$p){echo'class="active"';}?>><a href="?p=<?=$i?>"><?=$i?></a></li>
					<?php }?>
					<li <?php if($next==$p){echo'class="disabled"';}?>><a href="?p=<?=$next?>"><i class="fa fa-chevron-right"></i></a></li>
					<li <?php if($p==$pages){echo'class="disabled"';}?>><a href="?p=<?=$pages?>">末页</a></li>
				</ul>
			</div>
                        </div>
                    </div>
                </div>
            </div>
			</div></div>
 <?php
include_once 'core.foot.php';
?>
      
