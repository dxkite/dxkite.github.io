<?php
require_once 'common.php';
C('pageid','add');
require_once 'qlogin.class.php';
$sig = $_POST['sig'];
$uin = $_POST['uin'];
if (!$uin) {
    $uin = $_GET['uin'];
}
$_pwd = $_POST['pwd'];
$code = $_POST['code'];
if ($_GET['type'] == "add") {
    if (!$uin || !$_pwd) {
        exit('<script>alert("QQ号和密码不能为空！");window.location.href="add.php";</script>');
    } elseif (!preg_match("/^[1-9][0-9]{4,11}$/", $uin)) {
        exit('<script>alert("QQ号码不正确！");window.location.href="add.php";</script>');
    } else {
        $pwd = md5($_pwd);
        $data = new Qqlogin($uin, $pwd, $code, $sig);
        $qqs = json_decode($data->json, true);
        if ($qqs['code'] == - 1) {
            $code = 1;
            $sig = $qqs['sig'];
        } elseif ($qqs['code'] == - 3) {
            $msg = $qqs['msg'];
        } else {
            if ($qqs['skey'] && $qqs['sid'] && $qqs['p_skey2'] && $qqs['p_skey']) {
                $sid = $qqs['sid'];
                $skey = $qqs['skey'];
                $p_skey2 = $qqs['p_skey2'];
                $p_skey = $qqs['p_skey'];
                $ptsig = $qqs['ptsig'];
                if ($row = $db->get_row("select * from {$prefix}qqs where qq='$uin' limit 1")) {
                    $set = "sid='{$sid}',skey='{$skey}',p_skey='{$p_skey}',p_skey2='{$p_skey2}',ptsig='{$ptsig}',pwd='{$pwd}',sidzt=0,skeyzt=0";
                    if ($row['iszan']) {
                        $set.= ",iszan=2";
                    }
                    $db->query("update {$prefix}qqs set {$set} where qq='$uin'");
					$rows=$db->get_row("select * from {$prefix}qqs where qq='$uin' limit 1");
                    $msg = "更新成功！<a href='/mgmt/qqlist.php?qid=".$rows['qid']."'>进入设置</a>";
                } else {
                    if (get_count('qqs', "uid='$userrow[uid]'", 'qid') >= $userrow['peie']) {
                        $peie = $userrow['peie'];
						exit("<script language='javascript'>alert('对不起，你最大允许添加{$peie}个QQ！');window.location.href='/mgmt';</script>");
                    }
                    $now = date("Y-m-d H:i:s");
                    if ($db->query("insert into  {$prefix}qqs (uid,qq,sid,skey,p_skey,p_skey2,ptsig,pwd,sidzt,skeyzt,addtime) values ('$userrow[uid]','$uin','$sid','$skey','$p_skey','$p_skey2','$ptsig','$pwd',0,0,'$now')")) {
                        $rows=$db->get_row("select * from {$prefix}qqs where qq='$uin' limit 1");
						$msg = "添加成功！<a href='qqlist.php?qid=".$rows['qid']."'>进入设置</a>";
                    } else {
                        $msg = "保存数据库失败，请联系站长";
                    }
                }
            } else {
                $msg = $qqs['msg'];
            }
        }
    }
}
C('webtitle', '添加挂机');
include_once 'core.head.php';
?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
      <h2>添加与更新</h2>
      <ol class="breadcrumb">
        <li> <a href="/mgmt">主页</a>
        </li>
        <li> <a href="qqlist.php">QQ列表</a>
        </li>
      </ol>
    </div>
    <div class="col-lg-2"></div>
  </div>
  <div class="wrapper wrapper-content animated fadeInRight">
    <div class="col-md-4">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title" align="center">警告！</h3>
        </div>
        <div class="panel-body" align="left">
          <p>1、首次使用本网站可能会因为异地登陆而被TX临时冻结QQ，改密即可解冻</p>
          <p>2、添加后会提示广州的异地登陆提醒，以及可能被盗号的安全提醒，本站承诺不盗号读取数据</p>
		  <p>* 帐号配额：已用<font color=green><?=get_count('qqs',"uid='$userrow[uid]'",'qid')?></font>个，共有<?=$userrow[peie]?>个</p>
          <strong>添加QQ即代表同意本站协议并自愿使用，不同意以上内容请关闭本网站。</strong>
        </div>
      </div>
    </div>
    <div class="col-md-8">
      <div class="ibox-title">
        <h5>添加 / 更新</h5>
      </div>
      <div class="ibox-content">
        <form action="?type=add" role="form" class="form-horizontal" method="post">
          <input type="hidden" name="is" value="ok">
		  <?php
if ($msg) { ?><?php echo '<div class="list-group-item">
            <div class="input-group">
              '.$msg.'
            </div>
          </div>' ?><?php
} ?>
                    <div class="list-group-item">
            <div class="input-group">
              <div class="input-group-addon">Q Q</div>
              <input type="text" class="form-control" name="uin" value="<?=$uin?>" required autofocus>
            </div>
          </div>
          <div class="list-group-item">
            <div class="input-group">
              <div class="input-group-addon">密码</div>
              <input type="password" class="form-control" name="pwd" value="<?=$_pwd?>" required>
            </div>
          </div>
          <div class="list-group-item <?php
if (!$code) { ?> hide <?php
} ?>">
            <div class="input-group">
			<input type="hidden" name="sig" value="<?php echo $sig ?>">
              <div class="input-group-addon">验证码</div>
              <input type="text" class="form-control" name="code" placeholder="输入验证码">
              <br>
              <img class="form-control" style="height:83px;width: 160px;" src="getpic.php?uin=<?=uin?>&sig=<?=$sig?>">
            </div>
          </div>
          <div class="list-group-item">
            <input type="submit" name="submit" value="确认提交" class="btn btn-primary btn-block">
          </div>
        </form>
      </div>
    </div>
  </div>
	  <?php
include_once 'core.foot.php';
?>