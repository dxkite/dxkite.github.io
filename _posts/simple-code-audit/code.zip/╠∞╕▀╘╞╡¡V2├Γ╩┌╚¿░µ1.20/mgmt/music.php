<?php
require_once('common.php');
C('webtitle','音乐查询');
include_once 'core.head.php';
$qq=$_POST['qq'];
?>
<div id="content">
<div class="container">
          <div class="crumbs">
            <ul id="breadcrumbs" class="breadcrumb">
              <li>
                <i class="icon-home">
                </i>
                <a href="/mgmt">
                  用户中心
                </a>
              </li>
              <li class="current">
                <a href="/shop.php" title="">
                  音乐查询
                </a>
              </li>
            </ul>
            <ul class="crumb-buttons">
              <li class="dropdown">
                <a href="#" title="" data-toggle="dropdown">
                  <i class="icon-signal">
                  </i>
                  <span>
                    全站统计
                    <strong>
                    </strong>
                  </span>
                  <i class="icon-angle-down left-padding">
                  </i>
                </a>
                <ul class="dropdown-menu pull-right">
                  <li>
				  <a href="#" title="" data-toggle="dropdown">
                      <i class="icon-user">
                      </i>
                      用户:<?=get_count('users',"uid")?>人
					  </a>
                  </li>
                  <li>
				  <a href="#" title="" data-toggle="dropdown">
                      <i class="icon-user">
                      </i>
                      挂机:<?=get_count('qqs',"uid")?>个
					  </a>
                  </li>
                </ul>
              </li>
              <li class="range">
                <a href="#">
                  <i class="icon-calendar">
                  </i>
                  <span>
                  </span>
                  <i class="icon-angle-down">
                  </i>
                </a>
              </li>
            </ul>
          </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-content">
                        <div class="panel-body">
							<form action="?" class="form-horizontal" method="post">
								<input type="hidden" name="do" value="1">
								<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">QQ号码</label>
									<div class="col-sm-3">
										<input class="form-control" type="text" name="qq" value="<?php echo $qq;?>">
									</div>
									<div class="col-sm-3">
										<input type="submit" name="submit" value="查询" class="btn btn-primary">
									</div><br>
									<?php
									if($_POST['do']=='1'){
										echo '<br><div class="panel-body" align="center">
  <div class="panel-collapse collapse in">
    <div class="panel-body">
      <section id="dropdowns">
                <table class="table  table-bordered" style="table-layout: fixed;">
          <thead>
            <tr>
              <td class="mzwidthtd" align="center"">歌曲名字</td>
              <td class="mzwidthtd" align="center"">下载链接</td>
              
            </tr>
          </thead>


               ';



	 $qqurl='http://qzone-music.qq.com/fcg-bin/cgi_playlist_xml.fcg?json=1&uin='.$qq.'&g_tk=5381';
	 $url = get_curl($qqurl);
 $url = mb_convert_encoding($url, "UTF-8", "GB2312");
							  preg_match_all('@xsong_name\:\"(.*)\"@Ui',$url,$arr);
							  preg_match_all('@xqusic_id:(.*),xctype:(.*),xexpire_time@Ui',$url,$xqusic);
							  preg_match_all('@xsong_url\:\'(.*)\'@Ui',$url,$arrurl);
							  preg_match_all('@xsinger_name\:\"(.*)\"@Ui',$url,$singger);
							  $n = count($arr[1]);
for($i=0;$i<$n;$i++){
echo '<thead>
            <tr>
              <td align="center" valign="middle">'.$arr[1][$i] .'-'. $singger[1][$i].'</td>'.'<td align="center" valign="middle"><a href="http://ws.stream.qqmusic.qq.com/'.$xqusic[1][$i].'.m4a?fromtag=6">下载</a></td></tr>
          </thead>';
}
}									?>
</table>
		</div>
	</div>
	</div>
	</div>
								</div>
							</form>
                        </div>
                    </div>
                </div>
            </div>
            </div>
			</div>
			</div>
			</div>

<?php
include_once 'core.foot.php';
?>