<?php
require_once('common.php');
//************************执行代码开始*************************
if($_POST['do']=='rmb'){
	$km=safestr($_POST['km']);
	if(!$row=$db->get_row("select * from {$prefix}kms where km='$km' limit 1")){
		echo"<script language='javascript'>alert('充值卡卡密不存在！');</script>";
	}elseif($row['isuse']){
		echo"<script language='javascript'>alert('该充值卡卡密已使用！');</script>";
	}else{
		$now=date("Y-m-d H:i:s");
		$db->query("update {$prefix}kms set isuse=1,uid='{$userrow[uid]}',usetime='$now' where kid='{$row['kid']}'");
		$db->query("update {$prefix}users set rmb=rmb+$row[ms] where uid='{$userrow[uid]}'");
		$userrow['rmb']=$userrow['rmb']+$row[ms];
		echo"<script language='javascript'>alert('成功充值{$row['ms']}元！');</script>";
	}
}


//**************************执行代码开始*******************************

C('webtitle','在线充值');
C('pageid','rmb');
include_once 'core.head.php';
?>
<div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>会员开通</h2>
            <ol class="breadcrumb">
                <li><a href="/mgmt">主页</a>
                </li>
                <li><strong>会员开通</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
		<div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-content">
                        <h2>支付提示：</h2>
<?=stripslashes(C('web_rmb_gg'))?>
                    </div>
                </div>
           </div>
            
            
            <div class="col-lg-6">
                <div class="panel">
                    <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>秒赞网VIP会员开通</h5>
                    </div>
                    <div class="ibox-content">

                    <div class="panel-body">
                            <b>付款方式选择：</b>
							<a data-toggle="modal" href="#Registration" class="btn btn-danger btn-block">发卡平台</a>
                    </div>
                </div>
            </div>
</div></div>
            <div class="col-lg-6">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>卡密方式</h5>
                    </div>
                    <div class="ibox-content">
                        <form action="?" role="form" class="form-horizontal" method="post">
                            <input type="hidden" name="do" value="rmb">
                                                        <div class="list-group-item red"><span>购买的VIP卡密在此输入确认使用即可开通平台VIP会员，使用卡密续费也在这里</span></div>
                            <div class="list-group-item">
                                <div class="input-group">
                                    <div class="input-group-addon">卡密</div>
                                    <input type="text" class="form-control" name="km" placeholder="输入VIP卡卡密" value="">
                                </div>
                            </div>
                            <div class="list-group-item">
                                <input type="submit" name="submit" value="确认使用" class="btn btn-primary btn-block">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    </div></div>
</section>
              <!-- page end-->
			  <!-- Registration -->
          <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="Registration" class="modal fade">
              <div class="modal-dialog">
                 <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">关闭</span>
                </button> <i class="fa fa-info-circle modal-title"></i> 订单信息
            </div>
            <div class="modal-body" id="showInfo2"><p>购买物品：秒赞网会员卡密购买</p><p>卡密购买地址：<a href="<?=C('kmurl')?>" target="_blank"><?=C('kmurl')?></a></p><p>（支持微信扫码、QQ扫码、支付宝、财付通等各种付款方式）</p><p>付款后自动发货，卡密直接在网页显示，请复制下来在此页面选择卡密方式使用即可！</p></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">关闭</button>
            </div>
        </div>
              </div>
          </div>
          <!-- Registration -->


	<script src="/style/user/assets/jquery-knob/js/jquery.knob.js"></script>
</section>
      </section>
	  <?php
include_once 'core.foot.php';
?>
  </section>