<?php
require_once('common.php');
C('webtitle','每日签到');
C('pageid','qd');
include_once 'core.head.php';
$dates=date('Y-m-d');
if($_POST['do']=='qd'){
if(get_isvip($userrow[vip],$userrow[vipend])){
	exit("<script language='javascript'>alert('您已是VIP会员,VIP用户无法参与本活动');history.go(-1);</script>");
}
$qq=$_POST['uin'];
if (!$qq) {
exit("<script language='javascript'>alert('请先选择要用于发布签到信息的QQ！');history.go(-1);</script>");
} elseif ($db->get_row("select * from {$prefix}qds where uid='$userrow[uid]' and adddate='".date('Y-m-d')."' limit 1")) {
exit("<script language='javascript'>alert('您今天已经签到,请勿重复签到！');history.go(-1);</script>");
} else {
	if (!$qqrow=$db->get_row("select * from {$prefix}qqs where qq='$qq' and uid='$userrow[uid]' limit 1")) {
		exit("<script language='javascript'>alert('此QQ不存在！');history.go(-1);</script>");
	} else {
		include_once "../cron/qzone.class.php";
		$qzone = new qzone($qqrow['qq'], $qqrow['sid'], $qqrow['skey'], $qqrow['p_skey'], $qqrow['p_skey2']);
		$qdgg = C('qdgg');
		if(!$qdgg)$qdgg=get_con();
		$qzone->shuo('pc', $qdgg, 0);
$times = date('Y-m-d', strtotime('- 1 days', time()));
$msg="签到成功,获得1余额！";
if ($qqrows=$db->get_row("select * from {$prefix}qds where uid='".$userrow[uid]."' and adddate='$times' limit 1")) {
$lx = $qqrows['lx']+1;
$addtime = date('Y-m-d H:i:s');
$adddate = date('Y-m-d');
$rmb=$userrow[rmb]+1;
@mysql_query("update {$prefix}users set rmb='$rmb' where uid='".$userrow[uid]."'");
@mysql_query("insert into {$prefix}qds (uid,lx,adddate,addtime) values ('".$userrow[uid]."',$lx,'$adddate','$addtime')");
}else{
$addtime = date('Y-m-d H:i:s');
$adddate = date('Y-m-d');
$rmb=$userrow[rmb]+2;
@mysql_query("update {$prefix}users set rmb='$rmb' where uid='".$userrow[uid]."'");
@mysql_query("insert into {$prefix}qds (uid,lx,adddate,addtime) values ('".$userrow[uid]."',1,'$adddate','$addtime')");
$msg="首次签到成功,获得2余额！";
}
}
}
}
$rowss = $db->get_row("select * from {$prefix}qds where uid ='".$userrow[uid]."' limit 1");
?>
<div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>签到</h2>
            <ol class="breadcrumb">
                <li> <a href="/mgmt">主页</a>
                </li>
                <li> <strong>签到活动</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2"></div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
        <div class="col-xs-12 col-md-6">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">签到提示</h3>
                </div>
				<div class="list-group-item reed"><span>每日签到可获取1余额。</span></div>
				<div class="list-group-item reed"><span>余额可开通VIP资格和余额奖励。</span></div>
				<div class="list-group-item reed"><span>当前已连续签到活跃<strong><?php if($rowss['lx']==''){echo '0';}else{ echo $rowss['lx'];}?>天！</strong>，总签到<strong><?=get_count('qds',"uid='".$row[uid]."'",'id')?>天！</strong></span></div>
			</div>
        </div>
        <div class="col-xs-12 col-md-6">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">最新签到</h3>
                </div>
				<?php if($msg){ ?><div class="list-group-item"><span class="glyphicon glyphicon-th" aria-hidden="true"> <font color="red"><?=$msg?></font></span>
				</div><?php } ?>
                    <div class="list-group-item"><span class="glyphicon glyphicon-th" aria-hidden="true">&nbsp;可用余额：<font color="green" size="3"><?=$userrow[rmb]?></font></span>
            </div>
                <div class="list-group-item list-group-item-success">
                    <form action="#" role="form" class="form-horizontal" method="post">
                        <input type="hidden" name="do" value="qd">
                        <div class="list-group-item">
                            <div class="input-group">
                                <div class="input-group-addon">选择QQ</div>
                                <select name="uin" class="form-control">
									<?php if($rows=$db->get_results("select * from {$prefix}qqs where uid='$userrow[uid]' order by qid desc")){ foreach($rows as $row){?>
					<option value="<?=$row[qq]?>"><?=$row[qq]?></option>
					<?php }}?>
					</select>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <input type="submit" name="submit" value="同意签到" onClick="this.value='提交中...'" class="btn btn-primary btn-block">
                        </div>
                    </form>
                </div>
				
				<?php if($rows=$db->get_results("select * from {$prefix}qds where 1 order by lx desc limit 10")){ foreach($rows as $row){?>
				<?php $user = $db->get_row("select * from {$prefix}users where uid ='".$row[uid]."' limit 1");?>
				<div class="list-group-item list-group-item-warning">
				<span class="badge">连续<?=$row[lx]?>天</span>
                        <span class="glyphicon glyphicon-user" aria-hidden="true">&nbsp;<?=$user[user]?>[UID:<?=$user[uid]?>]于[<?=$row[addtime]?>]签到！</span>
						</div>
					<?php }}?>
    </div></div></div>
    </div>
	  <?php
include_once 'core.foot.php';
function get_con(){
	$row=file('../other/content.txt');
	shuffle($row);
	return $row[0];
}
function getMonthNum( $date1, $date2, $tags='-' ){
  $date1 = explode($tags,$date1);
  $date2 = explode($tags,$date2);
  return abs($date1[0] - $date2[0]) * 12 + abs($date1[1] - $date2[1]);
 }
?>