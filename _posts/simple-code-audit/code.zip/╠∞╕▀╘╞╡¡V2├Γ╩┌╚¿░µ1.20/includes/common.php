<?php
error_reporting(0);
@date_default_timezone_set('PRC');
if (!file_exists(dirname(__FILE__) . '/db.php')) {
    @header("Location:/install");
    exit();
}
define('VERSION', '1003');
require_once "360_safe3.php";
include_once "functions.php";
include_once "sql/ez_sql_core.php";
include_once "sql/ez_sql_mysql.php";
$mysql = require ("db.php");
C($mysql); //加载数据库信息
$PATH = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
$sitepath = substr($PATH, 0, strrpos($PATH, '/'));
$siteurl = ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $sitepath . '/';
$domain = $_SERVER['HTTP_HOST'];
$db = new ezSQL_mysql(C('DB_USER') , C('DB_PWD') , C('DB_NAME') , C('DB_HOST') . ':' . C('DB_PORT')); //链接数据库
$db->query("set names utf8"); //转为UTF8编码
//加载配置
if ($separate = $db->get_row("select * from tgyd_separate where urls='$domain' limit 1")) {
	if (!$separate['zt']) exit("该站已被禁！");
	$prefix = $separate['prefix'] . "_";
	$endtime = $separate['endtime'];
	$now = date("Y-m-d");
	if ($endtime <= $now) exit("该站已经过期！");
	$isdomain = 1;
} else {
	$prefix=$mysql['DB_PREFIX'];
}
if ($rows = $db->get_results('select * from ' . $prefix . 'webconfigs')) {
	foreach ($rows as $row) {
		$webconfig[$row['vkey']] = $row['value'];
	}
	C($webconfig);
}
//判断是否登录
$cookiesid = $_COOKIE['tgyd_sid'];
if ($cookiesid && $userrow = $db->get_row("select * from {$prefix}users where sid ='$cookiesid' limit 1")) {
    C('loginuser', $userrow['user']);
    C('loginuid', $userrow['uid']);
} 
@header('Content-Type: text/html; charset=UTF-8');