<?php
require_once('common.php');
C('webtitle','分站列表');
C('pageid','adminfz');
include_once 'common.head.php';
if($isdomain)exit("<script language='javascript'>alert('您没有总站权限');window.location.href='/admin';</script>");
//代码开始执行
function get_dzt($zt){
	if($zt==1)return "开放";else return "禁止";
}

$p=is_numeric($_GET['p'])?$_GET['p']:'1';
$pp=$p+8;
$pagesize=10;
$start=($p-1)*$pagesize;
$pages=ceil(get_count('separate','1=1','fid')/$pagesize);
if(!$pages) $pages=1;
if($pp>$pages) $pp=$pages;
if($p==1){
	$prev=1;
}else{
	$prev=$p-1;
}
if($p==$pages){
	$next=$p;
}else{
	$next=$p+1;
}
$rows=$db->get_results("select * from tgyd_separate where 1=1 order by fid desc limit $start,$pagesize");
$fid=is_numeric($_GET['fid'])?$_GET['fid']:'0';
if($_GET['do']=='zt'){
	if($fid && $row=$db->get_row("select zt from tgyd_separate where fid='$fid'")){
		if($row['zt']){
			$db->query("update tgyd_separate set zt=0 where fid='{$fid}'");
			echo "<script language='javascript'>alert('网站封禁成功！');window.location.href='fzlist.php';</script>";
		}else{
			$db->query("update tgyd_separate set zt=1 where fid='{$fid}'");
			echo "<script language='javascript'>alert('网站激活功！');window.location.href='fzlist.php';</script>";
		}
	}
}
$title = "分站管理";
?>
<div class="animated fadeInRight">
        <div class="row  border-bottom white-bg dashboard-header">
		<div class="col-sm-12">
			<section class="panel">
                          <div class="panel-body progress-panel">
                              <div class="task-progress">
                                  <h1>分站列表</h1>
                              </div>
                          </div>
			<div class="table-responsive">
				<table class="table table-striped">
                    <thead>
				<tr>
					<th>名称</th>
					<th>网址</th>
                    <th>QQ</th>
                    <th>状态</th>
                    <th>到期时间</th>
					<th>管理</th>
				</tr>
				</thead>
				<tbody>
                <?php if($rows){foreach($rows as $ds){?>
                
				<tr>
					<td><?=$ds['name']?></td>
					<td><?=$ds['urls']?></td>
                    <td><?=$ds['kfqq']?></td>
                    <td><?=get_dzt($ds['zt'])?><a href="?do=zt&p=<?=$p?>&fid=<?=$ds[fid]?>" onClick="if(!confirm('确认更改？')){return false;}" class="badge <?php if($ds[zt]){echo'bg-danger';}else{echo'bg-success';}?>"><?php if($ds[zt]){echo'封禁';}else{echo'激活';}?></a></td>
                    <td><?=$ds['endtime']?></td>
					<td><a href="fzset.php?type=del&url=<?=$ds['urls']?>" >删除</a>&nbsp;&nbsp;&nbsp;<a href="fzset.php?url=<?=$ds['urls']?>">修改</a></td>
				</tr>
                <?php }}?>
				</tbody>
				</table>
			</div>
			<div class="row" style="text-align:center;">
				<ul class="pagination pagination-lg">
					<li <?php if($p==1){echo'class="disabled"';}?>><a href="?p=1">首页</a></li>
					<li <?php if($prev==$p){echo'class="disabled"';}?>><a href="?p=<?=$prev?>">&laquo;</a></li>
					<?php for($i=$p;$i<=$pp;$i++){?>
					<li <?php if($i==$p){echo'class="active"';}?>><a href="?p=<?=$i?>"><?=$i?></a></li>
					<?php }?>
					<li <?php if($next==$p){echo'class="disabled"';}?>><a href="?p=<?=$next?>">&raquo;</a></li>
					<li <?php if($p==$pages){echo'class="disabled"';}?>><a href="?p=<?=$pages?>">末页</a></li>
				</ul>
			</div>
		</div></div></div>

	  <?php
include_once 'common.foot.php';
?>
