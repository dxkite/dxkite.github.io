<?php
require_once('common.php');
//************************执行代码开始*************************

if($do=$_POST['do']){
	foreach($_POST as $k=> $value){
		if(safestr($k)=='web_separate_gg' && $isdomain){
		exit("<script language='javascript'>alert('保存失败！您不能修改分站公告');window.location.href='set.php';</script>");
		}
		$db->query("insert into {$prefix}webconfigs set vkey='".safestr($k)."',value='".safestr($value)."' on duplicate key update value='".safestr($value)."'");
	}
	if($rows=$db->get_results("select * from {$prefix}webconfigs")){
		foreach($rows as $row){
			$webconfig[$row['vkey']]=$row['value'];
		}
		C($webconfig);
	}

	echo"<script language='javascript'>alert('保存成功！');window.location.href='set.php';</script>";
}

//**************************执行代码开始*******************************
if($_GET['xz']=='gg'){
	C('webtitle','公告设置');
	C('pageid','admingg');
}elseif($_GET['xz']=='mail'){
	C('webtitle','邮箱设置');
	C('pageid','adminmail');
}elseif($_GET['xz']=='price'){
	C('webtitle','价格设置');
	C('pageid','adminprice');
}elseif($_GET['xz']=='set'){
	C('webtitle','系统设置');
	C('pageid','adminset');
}else{
	C('webtitle','网站设置');
}
C('pageid','adminset');
include_once 'common.head.php';
?>
		<div class="animated fadeInRight">
        <div class="row  border-bottom white-bg dashboard-header">
              <!-- page start--><!-- 网站设置 -->
				<div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              网站设置
                          </header>
						<div class="panel-body">
							<form action="?xz=set" class="form-horizontal tasi-form" method="post">
								<input type="hidden" name="do" value="set">
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">网站名称</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="webname" value="<?=C('webname')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">网站介绍</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="webkey" value="<?=C('webkey')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">网站域名</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="webdomain" value="<?=C('webdomain')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">站长QQ</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="webqq" value="<?=C('webqq')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">注册默认配额</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="regpeie" value="<?=C('regpeie')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">注册赠送余额</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="regrmb" value="<?=C('regrmb')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">秒赞服务器数量</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="zannet" value="<?=C('zannet')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">每个服务器最多QQ数</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="netnum" value="<?=C('netnum')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">不是VIP也可以使用所有功能</label>
									<div class="col-sm-9">
										<p>
											<label class="radio-inline">
												<input type="radio" name="webfree" value="0" checked="">No
											</label>
											<label class="radio-inline">
												<input type="radio" name="webfree" value="1" <?php if(C('webfree')==1) echo 'checked=""';?>>
												<font color="green">Yes</font>
											</label>
										</p>
										<p>(所有功能除自动说说与秒赞外)</p>
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">监控识别码</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="cronrand" value="<?=C('cronrand')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">卡密购买发卡平台地址</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="kmurl" value="<?=C('kmurl')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-xs-8 "></label>
									<div class=="col-xs-4"><input type="submit" name="submit" value="确认修改" class="btn btn-primary"></div>
								</div>
							</form>
						</div>
					</div>
				<div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              网站公告
                          </header>
                          <div class="panel-body">
							<form action="?xz=gg" class="form-horizontal tasi-form" method="post">
								<input type="hidden" name="do" value="gg">
								<?php if($isdomain){}else{?>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">分站用户中心公告</label>
									<div class="col-sm-9">
										<textarea class="form-control" name="web_separate_gg" rows="5"><?=stripslashes(C('web_separate_gg'))?></textarea>
									</div>
								</div>
								<?php } ?>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">用户中心公告</label>
									<div class="col-sm-9">
										<textarea class="form-control" name="web_control_gg" rows="5"><?=stripslashes(C('web_control_gg'))?></textarea>
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">购买页说明</label>
									<div class="col-sm-9">
										<textarea class="form-control" name="web_shop_gg" rows="5"><?=stripslashes(C('web_shop_gg'))?></textarea>
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">充值页公告(用于展示购买卡密地址)</label>
									<div class="col-sm-9">
										<textarea class="form-control" name="web_rmb_gg" rows="5"><?=stripslashes(C('web_rmb_gg'))?></textarea>
									</div>
								</div>
								
								<div class="form-group">
									<label class="col-xs-8 "></label>
									<div class=="col-xs-4"><input type="submit" name="submit" value="确认修改" class="btn btn-primary"></div>
								</div>
							</form>
						</div>
					</div>
					<div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              广告设定
                          </header>
                          <div class="panel-body">
							<form action="?xz=wb" class="form-horizontal tasi-form" method="post">
								<input type="hidden" name="do" value="wb">
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">免费用户说说尾巴广告</label>
									<div class="col-sm-9">
										<textarea class="form-control" name="shuogg" rows="5"><?=stripslashes(C('shuogg'))?></textarea>
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">每日签到广告内容</label>
									<div class="col-sm-9">
										<textarea class="form-control" name="qdgg" rows="5"><?=stripslashes(C('qdgg'))?></textarea>
									</div>
								</div>
								<div class="form-group">
									<label class="col-xs-8 "></label>
									<div class=="col-xs-4"><input type="submit" name="submit" value="确认修改" class="btn btn-primary"></div>
								</div>
							</form>
						</div>
					</div>
			<div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              价格设置
                          </header>
                          <div class="panel-body">
							<form action="?xz=price" class="form-horizontal" method="post">
								<input type="hidden" name="do" value="pricet">
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">1天VIP</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="price_1dvip" value="<?=C('price_1dvip')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">1月VIP</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="price_1vip" value="<?=C('price_1vip')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">3月VIP</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="price_3vip" value="<?=C('price_3vip')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">6月VIP</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="price_6vip" value="<?=C('price_6vip')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">12月VIP</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="price_12vip" value="<?=C('price_12vip')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">1个配额</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="price_1peie" value="<?=C('price_1peie')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">3个配额</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="price_3peie" value="<?=C('price_3peie')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">5个配额</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="price_5peie" value="<?=C('price_5peie')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">10个配额</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="price_10peie" value="<?=C('price_10peie')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-xs-8 "></label>
									<div class=="col-xs-4"><input type="submit" name="submit" value="确认保存" class="btn btn-primary"></div>
								</div>
							</form>
						</div>
					</div>
					
				
				<div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              圈圈接口设置
                          </header>
                          <div class="panel-body">
							<form action="?xz=quanquan" class="form-horizontal" method="post">
								<input type="hidden" name="do" value="quanquan">
								<div class="form-group">
									<label class="col-lg-2 control-label" for="field-2">圈圈接口：</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" name="web_quanquanjk" value="<?=C('web_quanquanjk')?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-xs-8 "></label>
									<div class=="col-xs-4"><input type="submit" name="submit" value="确认保存" class="btn btn-primary"></div>
								</div>
							</form>
						</div>
				</div>
</div></div>
	  <?php
include_once 'common.foot.php';
?>