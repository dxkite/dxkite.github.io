    <!-- Mainly scripts -->
    <script src="/style/user/js/jquery-2.1.1.min.js"></script>
    <script src="/style/user/js/bootstrap.min.js?v=3.4.0"></script>
    <script src="/style/user/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <!-- Custom and plugin javascript -->
    <script src="/style/user/js/hplus.js?v=2.2.0"></script>
    <!-- iCheck -->
    <script src="/style/user/js/plugins/iCheck/icheck.min.js"></script>
    <script src="/style/user/js/plugins/pace/pace.min.js"></script>
	<script>
        $(document).ready(function () {
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
        });
    </script>
    <script src="/style/user/js/plugins/pace/pace.min.js"></script>

<div class="footer">
    <div class="pull-right"><a href="http://wpa.qq.com/msgrd?v=3&uin=<?=C('webqq')?>&site=qq&menu=yes" target="_banlk">站长QQ：<?=C('webqq')?></a></div>
    <div><strong>Copyright</strong> <?=C('name')?>(<?=$domain?>) &copy; 2016</div>
</div>
		</div>
	</div>
</body>

</html>