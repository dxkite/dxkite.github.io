<?php
require_once('common.php');
	$query=file_get_contents("http://qqjs.wx.jaeapp.com/checkver.php?url=".$domain."&authcode=".$authcode."&ver=".VERSION);
	if($query=json_decode($query,true)) {
		$upcode = $query['code'];
		$upmsg = $query['msg'];
		$upmsgs = $query['uplog'];
	}
	
//************************执行代码开始*************************
if($_POST['type']=='update'){
	if($_POST['submit']=="返回首页") header("Location: /"); 
	$url = $query['file'];
	$RemoteFile = $url;
	$ZipFile = "update.zip";
	copy($RemoteFile,$ZipFile) or showmsg("无法下载更新包文件{$url}",false,"",true);
	if (zipExtract($ZipFile,$_SERVER['DOCUMENT_ROOT'])) {
		$upcode = 0;
		unlink($ZipFile);
		$upmsg = "升级完成";
	}
	else {
		$upmsg = "无法解压文件";
		$upcode = 0;
	if (file_exists($ZipFile))
	unlink($ZipFile);
	}
	
}
function zipExtract ($src, $dest)
{
$zip = new ZipArchive();
if ($zip->open($src)===true)
{
$zip->extractTo($dest);
$zip->close();
return true;
}
return false;
}
//************************执行代码结束**************************

C('webtitle','网站升级');
include_once 'common.head.php';
?>
<div class="animated fadeInRight">
        <div class="row  border-bottom white-bg dashboard-header">
<div class="col-sm-12">
			<div id="collapseset" class="panel-body collapse-xs">
							<form action="?" class="form-horizontal" method="post">
                            <input type="hidden" value="update" name="type" >
							<hr>
							<label class="control-label"><?php if($upcode){echo $upmsgs;}?></label><hr/>
                            <?=$upmsg?>
									<div class="form-group text-right"><input type="submit" name="submit" value="<?php if($upcode){echo '确定升级';}else{echo '返回首页';}?>" class="btn btn-danger"></div>
							</form>
			</div>
			
	</div>
</div>
</div>
	  <?php
include_once 'common.foot.php';
?>