<?php
require_once('common.php');
C('webtitle','监控说明');
C('pageid','admincron');
include_once 'common.head.php';
?>
<div class="animated fadeInRight">
        <div class="row  border-bottom white-bg dashboard-header">
              <div class="row">
                  <div class="col-lg-12">
                      <!--work progress start-->
                      <section class="panel">
                          <div class="panel-body progress-panel">
                              <div class="task-progress">
                                  <h1>监控列表</h1>
                              </div>
                          </div>
                          <table class="table table-hover">
                          <thead>
				<tr>
					<th>监控项目</th>
					<th>监控频率</th>
					<th>监控地址</th>
				</tr>
				</thead>
                              <tbody>
				<tr>
					<td>集成监控</td>
					<td>1分钟</td>
					<td>http://<?=$_SERVER['HTTP_HOST']?>/jk.php?cron=<?=C('cronrand')?></td>
				</tr>
				</tbody>
                          </table>
</div></div></div></div>
	  <?php
include_once 'common.foot.php';
?>