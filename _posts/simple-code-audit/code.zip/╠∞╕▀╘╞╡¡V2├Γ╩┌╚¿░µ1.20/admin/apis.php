<?php
require_once('common.php');
//************************执行代码开始*************************

if($do=$_POST['type']){
	foreach($_POST as $k=> $value){
		$DB->query("insert into {$prefix}webconfigs set vkey='".safestr($k)."',value='".safestr($value)."' on duplicate key update value='".safestr($value)."'");
	}
	if($rows=$DB->get_results("select * from {$prefix}webconfigs")){
		foreach($rows as $row){
			$webconfig[$row['vkey']]=$row['value'];
		}
		C($webconfig);
	}

	echo"<script>alert('保存成功！');</script>";
}
//**************************执行代码开始*******************************
C('pageid','adminapis');
include_once 'common.head.php';
?>
		<div class="animated fadeInRight">
        <div class="row  border-bottom white-bg dashboard-header">
              <!-- page start--><!-- 网站设置 -->
				 <div class="col-lg-12">
                          <div class="panel-body">
                          <form action="?" class="form-horizontal tasi-form" method="post">
								<input type="hidden" name="type" value="dgapi">
                                  <div class="form-group">
                                  <label class="col-lg-2 control-label">代挂接口</label>
									<div class="col-lg-10">
										<select class="form-control" name="webdgapi">
										<option value="0" <?php if(C('webdgapi')==0)echo 'selected="selected"'; ?>>0_默认小柯代挂</option>
										<option value="1" <?php if(C('webdgapi')==1)echo 'selected="selected"'; ?>>1_鱼儿飞代挂</option>
										</select>
                                  </div>
</div>
                                  <div class="form-group">
									<label class="col-xs-8 "></label>
									<div class=="col-xs-4"><input type="submit" name="submit" value="确认保存" class="btn btn-danger"></div>
								</div>
                              </form>
                          </div>
                  </div> </div>
</div>
	  <?php
include_once 'common.foot.php';
?>