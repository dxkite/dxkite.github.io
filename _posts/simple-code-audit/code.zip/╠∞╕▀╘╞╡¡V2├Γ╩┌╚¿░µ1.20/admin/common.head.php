<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="RichSunfire">
    <link rel="shortcut icon" href="Template/2014/img/favicon.ico">
    <title><?=C('webtitle')?> - <?=C('webname')?> - <?=C('webkey')?></title>
    <!-- Bootstrap core CSS -->
	<link href="/style/user/css/bootstrap.min.css?v=3.4.0" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Morris -->
    <link href="/style/user/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
    <!-- Gritter -->
	<link href="/style/user/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="/style/user/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">
    <link href="/style/user/css/animate.css" rel="stylesheet">
    <link href="/style/user/css/style.css?v=2.2.0" rel="stylesheet">
  </head>

<body id="body">
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation" style="position:fixed;top:0;left:0;">
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
							<span><img alt="image" class="img-circle" src="http://q1.qlogo.cn/g?b=qq&nk=<?=$userrow[qq]?>&s=160" style="width:60px;" /></span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?=$userrow[user]?></strong></span>
							<span class="text-muted text-xs block"><?php if(get_isvip($userrow[vip],$userrow[vipend])){ echo "VIP用户";}else{echo"免费用户";}?> UID：<?=$userrow[uid]?><b class="caret"></b></span> </span>
                            </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="set.php">系统设置</a></li>
								<li><a href="km.php">卡密列表</a></li>
                                <li><a href="jk.php">监控列表</a></li>
                                <li class="divider"></li>
                                <li><a href="/mgmt/logout.php">安全退出</a></li>
                            </ul>
                        </div>
                    </li>
					<li <?php if(C('pageid')=='index'){ echo'class="active"';}?>>
                      <a href="/admin">
                          <i class="fa fa-cogs" style="width:20px;"></i>
                          <span>后台首页</span>
                      </a>
                  </li>
					
				  <li <?php if(C('pageid')=='km'){ echo'class="active"';}?>>
                      <a href="km.php">
                          <i class="fa fa-th" style="width:20px;"></i>
                          <span>卡密生成</span>
                      </a>
                  </li>
                  <li <?php if(C('pageid')=='adminset'){ echo'class="active"';}?> reply>
                      <a href="set.php?xz=set">
                          <i class="fa fa-cog" style="width:20px;"></i>
                          <span>系统设置</span>
                      </a>
                  </li>
				  <?php if($isdomain){}else{?>
				  <li <?php if(C('pageid')=='adminfz'){ echo'class="active"';}?> reply>
					  <a href="javascript:;"><i class="fa fa-cogs"></i> <span class="nav-label">分站管理</span><span class="fa arrow"></span></a>
                       <ul class="nav nav-second-level">
                        <li><a href="fzlist.php">分站列表</a></li>
                        <li><a href="addfz.php">添加分站</a></li>
                      </ul>
                  </li>
				  <?php } ?>
                  <li reply>
                      <a <?php if(C('pageid')=='admincron'){ echo'class="active"';}?> href="jk.php" >
                          <i class="fa fa-shopping-cart" style="width:20px;"></i>
                          <span>监控说明</span>
                      </a>
                  </li>
                  <li reply>
                      <a <?php if(C('pageid')=='adminuser'){ echo'class="active"';}?> href="ulist.php" >
                          <i class="fa fa-gift" style="width:20px;"></i>
                          <span>用户列表</span>
                      </a>
                  </li>
                  <li reply>
                      <a <?php if(C('pageid')=='adminqq'){ echo'class="active"';}?> href="qlist.php" >
                          <i class="fa fa-coffee" style="width:20px;"></i>
                          <span>挂机列表</span>
                      </a>
                  </li>
				  <li reply>
                      <a <?php if(C('pageid')=='update'){ echo'class="active"';}?> href="update.php" >
                          <i class="fa fa-cloud-upload" style="width:20px;"></i>
                          <span>程序升级</span>
                      </a>
                  </li>
                  <li>
                      <a href="/mgmt/logout.php">
                          <i class="fa fa-power-off" style="width:20px;"></i>
                          <span>退出登录</span>
                      </a>
                  </li>
                </ul>

            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " ><i class="fa fa-bars"></i></a>
                    </div>
                    <ul class="nav navbar-top-links navbar-right">
						<li>
                            <a href="/mgmt" title="返回用户中心"><i class="fa fa-home"></i>用户中心</a>
                        </li>
						<li>
                        <a href="/mgmt/logout.php" onClick="if(!confirm('确认退出登录吗？')){return false;}"><i class="fa fa-sign-out"></i> <span class="nav-label">注销登录</span></a>
						</li>
                    </ul>
					
                </nav>
            </div>
		
<!-- end -->