<?php
require_once('common.php');
C('webtitle','分站信息修改');
C('pageid','adminfz');
include_once 'common.head.php';
if($isdomain)exit("<script language='javascript'>alert('您没有总站权限');window.location.href='/admin';</script>");
//代码开始执行
$d_url = $_GET['url'];
if(!$drows=$db->get_row("select * from tgyd_separate where urls='$d_url' limit 1"))exit("<script language='javascript'>alert('该分站不存在');window.location.href='fzlist.php';</script>");
$type = $_GET['type'];
if($type=='del'){
	if($db->query("delete from tgyd_separate where urls='$d_url'"))exit("<script language='javascript'>alert('分站已删除');window.location.href='fzlist.php';</script>");
}elseif($type=='set'){
	if(!$_POST['d_name'] || !$_POST['d_url'] || !$_POST['d_qq'] || !$_POST['d_user_pwd'] || !$_POST['d_end'])exit("<script language='javascript'>alert('任何一项不能为空');window.location.href='fzset.php?url=".$drows['urls']."';</script>");
	$d_name = $_POST['d_name'];
	$d_url = $_POST['d_url'];
	$d_qq = $_POST['d_qq'];
	$endtime = $_POST['d_end'];
	$d_user_pwd = $_POST['d_user_pwd'];
	$d_pwd = md5(md5($d_user_pwd).md5('1340176819'));
	$d_zt = $_POST['d_zt'];
	if($d_user_pwd!=$drows['adminpwd'])$db->query("update ".$drows['prefix']."_users set pwd='$d_pwd' where user='".$drows['adminname']."'");
	if($db->query("update tgyd_separate set name='$d_name',kfqq='$d_qq',adminpwd='$d_user_pwd',zt='$d_zt',endtime='$endtime' where urls='$d_url'"))exit("<script language='javascript'>alert('修改分站[$d_name]成功');window.location.href='fzlist.php';</script>");
//UPDATE `0rg_users` SET pwd='1111' WHERE uid='1'
	}
?>
<div class="animated fadeInRight">
        <div class="row  border-bottom white-bg dashboard-header">
    	<div class="col-lg-12">
          <section class="panel">
              <header class="panel-heading">
                    分站信息修改
              </header>
        	  <div class="panel-body">
				<form action="?type=set&url=<?=$drows['urls']?>" class="form-horizontal tasi-form" method="post">
                    <div class="form-group">
                        <label class="col-lg-2 control-label">网站地址</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_url" value="<?=$drows['urls']?>" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-2 control-label">网站名称</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_name" value="<?=$drows['name']?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-2 control-label">客服QQ</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_qq" value="<?=$drows['kfqq']?>">
                        </div>
                    </div>
					<div class="form-group">
                        <label class="col-lg-2 control-label">管理员账号</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_user_pwd" value="<?=$drows['adminname']?>" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-2 control-label">管理员密码</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_user_pwd" value="<?=$drows['adminpwd']?>">
                        </div>
                    </div>
					<div class="form-group">
                        <label class="col-lg-2 control-label">到期时间</label>
                        <div class="col-lg-10">
                            <input type="date" class="form-control" name="d_end" value="<?=$drows['endtime']?>">
                        </div>
                    </div>
					<div class="form-group">
                        <label class="col-lg-2 control-label">分站状态</label>
						<div class="col-lg-10">
                        <select class="form-control" name="d_zt">
										
										<?php if($drows['zt']==1){?>
										<option value ="1">1_开放</option>
										<option value ="0">0_禁止</option>
										<?php }else{ ?>
										<option value ="0">0_禁止</option>	
										<option value ="1">1_开放</option>
										<?php }?>
						</select>
						</div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-offset-2 col-lg-10">
                        	<a class="btn btn-default" href="fzlist.php">返回列表</a>
							<input type="submit" name="submit" value="立即修改" class="btn btn-success">
                        </div>
                    </div>
					</form>
              </div>
           </section>
         </div>
</div></div>
	  <?php
include_once 'common.foot.php';
?>