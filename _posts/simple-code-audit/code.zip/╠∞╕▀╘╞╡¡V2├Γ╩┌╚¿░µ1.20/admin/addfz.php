<?php
require_once('common.php');
C('webtitle','添加分站');
C('pageid','adminfz');
include_once 'common.head.php';
if($isdomain)exit("<script language='javascript'>alert('您没有总站权限');window.location.href='/admin';</script>");
//代码开始执行
if($_GET['type']=='add'){
	if(!$_POST['d_name'] || !$_POST['d_url'] || !$_POST['d_qq'] || !$_POST['d_user_name'] || !$_POST['d_user_pwd'] ||!$_POST['d_end']) exit("<script language='javascript'>alert('任何一项不能为空');window.location.href='addfz.php';</script>");
	$d_name = $_POST['d_name'];
	$d_url = $_POST['d_url'];
	if($d_url== $_SERVER['HTTP_HOST'])exit("<script language='javascript'>alert('分站域名不能与主站相同');window.location.href='/admin';</script>");
	$d_qq = $_POST['d_qq'];
	$d_user_name = $_POST['d_user_name'];
	$d_user_pwd = $_POST['d_user_pwd'];
	$d_pwd = md5(md5($d_user_pwd).md5('1340176819'));
	$endtime = $_POST['d_end'];
	$d_qz = $_POST['d_qz'];
	if($d_qz){
	$prefix = $d_qz;
	}else{
	$prefix = get_sz(3);
	}
	if($db->get_row("select * from tgyd_separate where name='$d_name' or urls='$d_url' limit 1"))exit("<script language='javascript'>alert('该分站已存在');window.location.href='addfz.php';</script>");
	$sqls=file_get_contents("../install/separate.sql");
	$sqls = str_replace("admin', '0', '1', null, '2020-12-30', '9999', '127', '26ff3a5be026305db95aac0adc3ca352",$d_user_name."', '0', '1', null, '2020-12-30', '9999', '127', '".$d_pwd,$sqls);
	$sqls = str_replace("tgyd_",$prefix."_",$sqls);
	$sqls = str_replace("天高云淡分站",$d_name,$sqls);
	$sqls = str_replace("1340176819",$d_qq,$sqls);
	$sqls = str_replace("http://qqlike.wx.jaeapp.com/",$d_url,$sqls);
	$explode = explode(";",$sqls);
	$num = count($explode);
	foreach($explode as $sql){
		if($sql=trim($sql)){
			mysql_query($sql);
		}
	}
	if(mysql_error()){
		echo'<script language=\'javascript\'>alert("导入数据表时错误，'.mysql_error().'");history.go(-1);</script>';
	}
	$now = date("Y-m-d");
	if($db->query("insert into tgyd_separate (name,urls,adminname,adminpwd,kfqq,zt,prefix,addtime,endtime) values('$d_name','$d_url','$d_user_name','$d_user_pwd','$d_qq',1,'$prefix','$now','$endtime')"))exit("<script language='javascript'>alert('添加分站[$d_name]成功');window.location.href='fzlist.php';</script>");
	}
?>
<div class="animated fadeInRight">
        <div class="row  border-bottom white-bg dashboard-header">
    	<div class="col-lg-12">
          <section class="panel">
              <header class="panel-heading">
                    新分站设置
              </header>
        	  <div class="panel-body">
				<form action="?type=add" class="form-horizontal tasi-form" method="post">
                    <div class="form-group">
                        <label class="col-lg-2 control-label">网站地址</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_url">
                          
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-2 control-label">网站名称</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-2 control-label">客服QQ</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_qq">
                        </div>
                    </div>
					<div class="form-group">
                        <label class="col-lg-2 control-label">管理员账号</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_user_name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-2 control-label">管理员密码</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_user_pwd">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-2 control-label">数据库前缀</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="d_qz">
							<p>数据库前缀不填为随机</p>
                        </div>
                    </div>
					<div class="form-group">
                        <label class="col-lg-2 control-label">到期时间</label>
                        <div class="col-lg-10">
                            <input type="date" class="form-control" name="d_end" value="<?=date("Y-m-d",time()+43200)?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-offset-2 col-lg-10">
                        	<a class="btn btn-default" href="fzlist.php">返回列表</a>
							<input type="submit" name="submit" value="添加分站" class="btn btn-success">
                        </div>
                    </div>
					</form>
              </div>
</div></div></div>
	  <?php
include_once 'common.foot.php';
?>
