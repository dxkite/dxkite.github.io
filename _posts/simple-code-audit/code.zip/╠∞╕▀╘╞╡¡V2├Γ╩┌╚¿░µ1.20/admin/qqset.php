<?php
require_once('common.php');
//************************执行代码开始*************************
$qid=is_numeric($_GET['qid'])?$_GET['qid']:'0';
if(!$qid || !$user=$db->get_row("select * from {$prefix}qqs where qid='$qid' limit 1")){
	exit("<script language='javascript'>alert('QQ不存在！');window.location.href='qlist.php';</script>");
}
$p=is_numeric($_GET['p'])?$_GET['p']:'1';
$pp=$p+8;
$pagesize=10;
$start=($p-1)*$pagesize;
$pages=ceil(get_count('qqs','1=1','qid')/$pagesize);
if($pp>$pages) $pp=$pages;
if($p==1){
	$prev=1;
}else{
	$prev=$p-1;
}
if($p==$pages){
	$next=$p;
}else{
	$next=$p+1;
}
function getkq($row){
	$str='';
	if($row[iszan]==2) $str.="赞[P],";
	if($row[iszan]==1) $str.="赞[C],";
	if($row[isreply]==2) $str.="评[P],";
	if($row[isreply]==1) $str.="评[C],";
	if($row[iszf]==2) $str.="转[P],";
	if($row[iszf]==1) $str.="转[C],";
	if($row[isshuo]==2) $str.="说[P],";
	if($row[isshuo]==1) $str.="说[C],";
	if($row[isqd]==2) $str.="签[P],";
	if($row[isqd]==1) $str.="签[C],";
	if($row[isdel]) $str.="删,";
	if($row[isvipqd]) $str.="会签,";
	if($row[ists]) $str.="图签,";
	if($row[isht]) $str.="花藤,";
	if($row[isly]) $str.="留言,";
	if($row[iszyzan]) $str.="主页赞,";
	if($row[is3gqq]) $str.="挂扣,";
	return rtrim($str,',');
}
$qqs=$db->get_row("select * from {$prefix}qqs where qid='$qid' limit 1");





//**************************执行代码开始*******************************

C('webtitle','QQ信息修改');
C('pageid','adminqq');
include_once 'common.head.php';
?>
<section id="main-content" style="height: 1136px;">
<section class="wrapper" id="Main_Box"><div class="row"><div class="col-lg-12"><ul class="breadcrumb"><li><a href="/"><i class="fa fa-home"></i> 首页</a></li><li>后台管理</li><li class="active"><?=C('webtitle')?></li><span style="float:right;cursor:pointer;">复制地址</span></ul></div></div>              <!-- page start-->
		<div class="panel row">
		<div class="col-sm-12">
			<h2 class="page-header">QQ信息-<?=$qqs[qq]?></h2>
			<div class="table-responsive">
				<div class="col-xs-12 col-md-4">
					<div class="panel panel-default">
						<div class="panel-heading" data-toggle="collapse" href="#collapseupdate">
							<h3 class="panel-title">QQ资料查看</h3>
						</div>
						<div id="collapseupdate" class="panel-body <?php if($_GET['xz'] != 'update'){echo'collapse-xs';}?>">
							<form action="?uid=<?=$uid?>&xz=update" class="form-horizontal" method="post">
								<input type="hidden" name="do" value="update">
								<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">QQID</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" placeholder="<?=$qqs[qid]?>" readonly>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">QQ账号</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" value="<?=$qqs[qq]?>">
									</div>
								</div>
<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">SID</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" value="<?=$qqs[sid]?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">SKEY</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" value="<?=$qqs[skey]?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">PC_SKEY</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" value="<?=$qqs[p_skey]?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">CP_SKEY</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" value="<?=$qqs[p_skey2]?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">GTK</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" value="<?=getGTK($qqs[skey])?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">GTK2</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" value="<?=getGTK2($qqs[skey])?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">cookie</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" value="pt2gguin=o0<?=$qqs[qq]?>; uin=o0<?=$qqs[qq]?>; skey=<?=$qqs[skey]?>; p_skey=<?=$qqs[p_skey]?>;">
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-3 control-label" for="field-2">PTSIG</label>
									<div class="col-sm-9">
										<input class="form-control" type="text" value="<?=$qqs[ptsig]?>">
									</div>
								</div>
								<div class="form-group">
								<a href="qlist.php?do=del&qid=<?=$qqs[qid]?>" class="btn btn-danger">删除</a>
									<a href="qlist.php" class="btn btn-info">返回</a>
								</div>
							</form>
						</div>
					</div>
				</div>
				
			</div>
		</div></div>
<script src="/style/user/assets/jquery-knob/js/jquery.knob.js"></script>
</section>
      </section>
	  <?php
include_once 'common.foot.php';
?>
  </section>